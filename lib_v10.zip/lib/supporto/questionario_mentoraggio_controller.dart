import 'package:flutter/foundation.dart';

import '../app/app_core.dart';
import '../app/app_session_controller.dart';
import '../dati/repository.dart';

/// Componente `QuestionarioMentoraggioController`: incapsula responsabilità specifiche del relativo modulo.
class QuestionarioMentoraggioController extends ChangeNotifier {
  QuestionarioMentoraggioController(
    this.sessione, {
    QuestionariRepository? repository,
  }) : repository = repository ?? QuestionariRepository();

  final SessioneController sessione;
  final QuestionariRepository repository;

  final List<Map<String, dynamic>> template = <Map<String, dynamic>>[];
  final List<Map<String, dynamic>> domande = <Map<String, dynamic>>[];
  final List<Map<String, dynamic>> questionari = <Map<String, dynamic>>[];

  bool caricamento = false;
  String? errore;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();
    try {
      final dati = await repository.caricaCatalogo();
      template
        ..clear()
        ..addAll(dati.template);
      domande
        ..clear()
        ..addAll(dati.domande);
      questionari
        ..clear()
        ..addAll(dati.questionari);
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i questionari di mentoraggio.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  List<Map<String, dynamic>> templatePer(String destinatario) => template
      .where(
        (riga) =>
            riga['destinatario']?.toString() == destinatario &&
            riga['attivo'] != false,
      )
      .toList(growable: false);

  List<Map<String, dynamic>> domandeTemplate(String templateId) => domande
      .where((riga) => riga['template_id']?.toString() == templateId)
      .toList(growable: false);

  Map<String, dynamic>? questionarioMentoraggio(String mentoraggioId) {
    for (final questionario in questionari) {
      if (questionario['provider']?.toString() == 'pubblico' &&
          questionario['mentoraggio_id']?.toString() == mentoraggioId) {
        return questionario;
      }
    }
    return null;
  }

  Future<String?> creaQuestionarioMentoraggio({
    required String mentoraggioId,
    required String templateId,
    required String titolo,
  }) => _esegui(() async {
    final creato = await repository.creaQuestionarioMentoraggio(
      mentoraggioId: mentoraggioId,
      templateId: templateId,
      titolo: titolo,
    );
    final token = creato['token_pubblico']?.toString().trim();
    if (token == null || token.isEmpty) {
      throw const AppException(
        'Token pubblico del questionario non restituito.',
      );
    }
    await repository.impostaLinkMentoraggio(mentoraggioId, _urlDaToken(token));
  });

  String? urlQuestionarioPubblico(Map<String, dynamic> questionario) {
    final token = questionario['token_pubblico']?.toString().trim();
    return token == null || token.isEmpty ? null : _urlDaToken(token);
  }

  Future<int> contaCompilazioni(String questionarioId) =>
      repository.contaCompilazioni(questionarioId);

  Future<String?> eliminaQuestionarioMentoraggio(
    String questionarioId,
  ) => _esegui(() async {
    if (!puoGestire) {
      throw const AppException('Operazione non autorizzata.');
    }
    if (await repository.contaCompilazioni(questionarioId) > 0) {
      throw const AppException(
        'Il questionario non può essere cancellato perché sono già presenti risposte.',
      );
    }
    final mentoraggioId = await repository.mentoraggioDelQuestionario(
      questionarioId,
    );
    await repository.eliminaQuestionario(questionarioId);
    if (mentoraggioId != null && mentoraggioId.isNotEmpty) {
      await repository.impostaLinkMentoraggio(mentoraggioId, '');
    }
  });

  String _urlDaToken(String token) {
    final configurato = AppConfig.publicAppUrl.trim();
    final base = configurato.isNotEmpty
        ? configurato.replaceFirst(RegExp(r'/$'), '')
        : Uri.base.origin;
    return '$base/q/$token';
  }

  Future<String?> _esegui(Future<void> Function() azione) async {
    try {
      await azione();
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Operazione sul questionario di mentoraggio non riuscita.',
      ).messaggio;
    }
  }
}
