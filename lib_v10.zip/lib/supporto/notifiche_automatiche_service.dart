import '../dati/repository.dart';

/// Crea e invia notifiche automatiche generate dalle funzionalità dell'app.
///
/// Il servizio contiene soltanto la regola applicativa; insert, RPC e invio
/// dell'Edge Function sono centralizzati in [NotificheRepository].
abstract final class NotificheAutomaticheService {
  static final NotificheRepository _repository = NotificheRepository();

  static Future<void> inviaAnnoAccademico({
    required String annoAccademico,
    required String titolo,
    required String messaggio,
  }) async {
    final anno = annoAccademico.trim();
    if (anno.isEmpty) return;

    await _creaEInvia(
      titolo: titolo,
      messaggio: messaggio,
      destinatari: 'anno_accademico',
      configurazione: <String, dynamic>{'anno_accademico': anno},
    );
  }

  static Future<void> inviaUtenti({
    required Iterable<String> userIds,
    required String titolo,
    required String messaggio,
  }) async {
    final ids = userIds
        .map((id) => id.trim())
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList(growable: false);
    if (ids.isEmpty) return;

    await _creaEInvia(
      titolo: titolo,
      messaggio: messaggio,
      destinatari: 'manuale',
      configurazione: <String, dynamic>{'user_ids': ids},
    );
  }

  /// Esegue il flusso atomico applicativo: creazione, destinatari e invio.
  static Future<void> _creaEInvia({
    required String titolo,
    required String messaggio,
    required String destinatari,
    required Map<String, dynamic> configurazione,
  }) async {
    final messaggioId = await _repository.creaMessaggio(<String, dynamic>{
      'regola_id': null,
      'titolo': titolo.trim(),
      'messaggio': messaggio.trim(),
      'destinatari': destinatari,
      'destinatari_configurazione': configurazione,
      'programmata_per': null,
      'stato': 'da_inviare',
      'creata_da': _repository.userIdCorrente,
    });

    await _repository.generaDestinatari(messaggioId);
    await _repository.inviaMessaggio(messaggioId);
  }
}
