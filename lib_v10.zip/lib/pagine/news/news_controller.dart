import 'package:flutter/foundation.dart';

import '../../app/app_core.dart';
import '../../dati/repository.dart';
import '../../ui/controller_crud_dinamico.dart';
import '../../ui/schema_dinamico.dart';

/// Controller della pagina News.
///
/// Mantiene stato, selezione e operazioni CRUD; la pagina contiene soltanto
/// la composizione grafica. L'accesso Supabase è delegato ai repository.
class NewsController extends ChangeNotifier {
  NewsController({required bool partecipante, required bool puoGestire})
      : _crud = ControllerElencoCrudDinamico(
          tabella: 'news',
          filtri: partecipante
              ? const <FiltroDinamico>[FiltroDinamico('attiva', true)]
              : const <FiltroDinamico>[],
          ordinamenti: const <OrdinamentoDinamico>[
            OrdinamentoDinamico('data_pubblicazione', crescente: false),
            OrdinamentoDinamico('id', crescente: false),
          ],
          puoGestire: puoGestire,
          normalizzaValori: normalizzaNews,
          messaggioErroreCaricamento: 'Impossibile caricare le news.',
          messaggioErroreSalvataggio: 'Impossibile salvare la news.',
          messaggioErroreEliminazione: 'Impossibile eliminare la news.',
        ) {
    _crud.addListener(notifyListeners);
  }

  final ControllerElencoCrudDinamico _crud;
  final RepositoryComune _repository = RepositoryComune();

  List<Map<String, dynamic>> get news => _crud.record;
  Map<String, dynamic>? get selezionata => _crud.selezionato;
  bool get caricamento => _crud.caricamento;
  bool get salvataggio => _crud.salvataggio;
  String? get errore => _crud.errore;

  /// Carica l’operazione `caricaSchemaDatabase` mantenendo separata la logica dalla UI.
  Future<SchemaDatabase> caricaSchemaDatabase() => _repository.schemaDatabase();

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() => _crud.carica();

  /// Aggiorna il record selezionato nella pagina.
  void seleziona(Map<String, dynamic> news) => _crud.seleziona(news);

  /// Valida e salva i dati richiesti dalla pagina.
  Future<Map<String, dynamic>> salva({
    Map<String, dynamic>? esistente,
    required Map<String, dynamic> valori,
  }) => _crud.salva(esistente: esistente, valori: valori);

  /// Elimina il record indicato e aggiorna lo stato locale.
  Future<void> elimina(Map<String, dynamic> news) => _crud.elimina(news);

  /// Rilascia listener e controller associati allo stato della pagina.
  @override
  void dispose() {
    _crud.removeListener(notifyListeners);
    _crud.dispose();
    super.dispose();
  }
}

/// Valida e normalizza i dati della news prima del salvataggio.
Map<String, dynamic> normalizzaNews(
  Map<String, dynamic> valori,
  Map<String, dynamic>? esistente,
) {
  final titolo = valori['titolo']?.toString().trim() ?? '';
  if (titolo.isEmpty) {
    throw const AppException('Il titolo è obbligatorio.');
  }

  final testo = valori['testo']?.toString().trim() ?? '';
  final data = DateTime.tryParse(valori['data_pubblicazione']?.toString() ?? '');
  return <String, dynamic>{
    ...valori,
    'titolo': titolo,
    'testo': testo.isEmpty ? null : testo,
    if (data != null) 'data_pubblicazione': data.toIso8601String().split('T').first,
    'attiva': valori['attiva'] ?? esistente?['attiva'] ?? true,
  };
}
