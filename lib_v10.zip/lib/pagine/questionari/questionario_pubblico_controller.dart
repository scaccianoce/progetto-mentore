import 'package:flutter/foundation.dart';
import '../../app/app_core.dart';
import '../../dati/repository.dart';

/// Controller di questionario pubblico; coordina stato e logica applicativa.
class QuestionarioPubblicoController extends ChangeNotifier {
  QuestionarioPubblicoController({QuestionariRepository? repository})
      : repository = repository ?? QuestionariRepository.pubblico();

  final QuestionariRepository repository;

  Map<String, dynamic>? dati;
  bool caricamento = true;
  bool invio = false;
  bool completato = false;
  String? errore;

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica(String token) async {
    caricamento = true;
    errore = null;
    notifyListeners();
    try {
      dati = await repository.caricaQuestionarioPubblico(token);
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Questionario non disponibile.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  /// Invia l’operazione `invia` mantenendo separata la logica dalla UI.
  Future<String?> invia(String token, Map<String, dynamic> risposte) async {
    invio = true;
    notifyListeners();
    try {
      await repository.inviaQuestionarioPubblico(token, risposte);
      completato = true;
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Invio del questionario non riuscito.',
      ).messaggio;
    } finally {
      invio = false;
      notifyListeners();
    }
  }
}
