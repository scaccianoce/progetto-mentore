import 'package:flutter/foundation.dart';

import '../../app/app_core.dart';
import '../../app/app_session_controller.dart';
import '../../dati/repository.dart';
import '../../ui/schema_dinamico.dart';

/// Modello o componente interno “PartecipazioneAnnualeProfilo” usato esclusivamente da questo file.
class PartecipazioneAnnualeProfilo {
  const PartecipazioneAnnualeProfilo({
    required this.disponibile,
    required this.annoAccademico,
    required this.stato,
    this.richiestaAt,
    this.rispostaAt,
    this.preferenzaPeriodoMentore,
    this.noteAttivitaMentore,
    this.soloMentore,
    this.valutazioneMentoriPrecedenti,
    this.cambiareMentore,
    this.noteSuiMentori,
    this.cambiareMenteeSeguiti,
    this.disponibileMentoringEsami,
    this.segnalazioniSuggerimenti,
  });

  factory PartecipazioneAnnualeProfilo.daMap(Map<String, dynamic> map) {
    return PartecipazioneAnnualeProfilo(
      disponibile: map['disponibile'] == true,
      annoAccademico: map['anno_accademico']?.toString(),
      stato: map['stato']?.toString(),
      richiestaAt: DateTime.tryParse(map['richiesta_at']?.toString() ?? ''),
      rispostaAt: DateTime.tryParse(map['risposta_at']?.toString() ?? ''),
      preferenzaPeriodoMentore: map['preferenza_periodo_mentore']?.toString(),
      noteAttivitaMentore: map['note_attivita_mentore']?.toString(),
      soloMentore: map['solo_mentore'] as bool?,
      valutazioneMentoriPrecedenti: _intNull(
        map['valutazione_mentori_precedenti'],
      ),
      cambiareMentore: map['cambiare_mentore'] as bool?,
      noteSuiMentori: map['note_sui_mentori']?.toString(),
      cambiareMenteeSeguiti: map['cambiare_mentee_seguiti']?.toString(),
      disponibileMentoringEsami: map['disponibile_mentoring_esami'] as bool?,
      segnalazioniSuggerimenti: map['segnalazioni_suggerimenti']?.toString(),
    );
  }

  final bool disponibile;
  final String? annoAccademico;
  final String? stato;
  final DateTime? richiestaAt;
  final DateTime? rispostaAt;

  final String? preferenzaPeriodoMentore;
  final String? noteAttivitaMentore;
  final bool? soloMentore;
  final int? valutazioneMentoriPrecedenti;
  final bool? cambiareMentore;
  final String? noteSuiMentori;
  final String? cambiareMenteeSeguiti;
  final bool? disponibileMentoringEsami;
  final String? segnalazioniSuggerimenti;

  bool get daConfermare => disponibile && stato == 'da_contattare';
  bool get confermata => disponibile && stato == 'confermato';
  bool get rinuncia => disponibile && stato == 'rinuncia';
  bool get nuovo => disponibile && stato == 'nuovo';
}

/// Controller di profilo; coordina stato e logica applicativa.
class ProfiloController extends ChangeNotifier {
  ProfiloController({required this.sessione, ProfiloRepository? repository})
    : _repository = repository ?? ProfiloRepository();

  final SessioneController sessione;
  final ProfiloRepository _repository;

  /// Carica lo schema usato esclusivamente dalla visualizzazione locale.
  Future<SchemaDatabase> caricaSchemaDatabase() => _repository.schemaDatabase();

  Map<String, dynamic>? _profilo;
  final List<Map<String, dynamic>> _ssd = <Map<String, dynamic>>[];
  final List<String> _anniAccademici = <String>[];
  final List<PartecipazioneAnnualeProfilo> _partecipazioniAnnuali =
      <PartecipazioneAnnualeProfilo>[];
  PartecipazioneAnnualeProfilo? _partecipazioneAnnuale;
  bool _caricamento = false;
  bool _salvataggio = false;
  bool _salvataggioPartecipazione = false;
  bool _salvataggioPassword = false;
  bool _puoModificare = false;
  String? _errore;

  Map<String, dynamic>? get profilo => _profilo;
  List<Map<String, dynamic>> get ssd => List.unmodifiable(_ssd);
  List<String> get anniAccademici => List.unmodifiable(_anniAccademici);
  List<PartecipazioneAnnualeProfilo> get partecipazioniAnnuali =>
      List.unmodifiable(_partecipazioniAnnuali);
  PartecipazioneAnnualeProfilo? get partecipazioneAnnuale =>
      _partecipazioneAnnuale;
  bool get caricamento => _caricamento;
  bool get salvataggio => _salvataggio;
  bool get salvataggioPartecipazione => _salvataggioPartecipazione;
  bool get salvataggioPassword => _salvataggioPassword;
  bool get puoModificare => _puoModificare;
  String? get errore => _errore;

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() async {
    final userId = _repository.userIdCorrente;
    if (userId == null) {
      _errore = 'Sessione assente.';
      notifyListeners();
      return;
    }

    _caricamento = true;
    _errore = null;
    notifyListeners();

    try {
      final risultati = await Future.wait<dynamic>([
        _repository.profiloCorrente(),
        _repository.ssd(),
        _repository.anniAccademici(),
        _repository.statoPartecipazioneAnnuale(),
        _repository.partecipazioniAnnuali(),
      ]);

      _profilo = risultati[0] as Map<String, dynamic>?;
      _ssd
        ..clear()
        ..addAll((risultati[1] as List).cast<Map<String, dynamic>>())
        ..sort(
          (prima, seconda) => prima['cod_ssd']
              .toString()
              .toLowerCase()
              .compareTo(seconda['cod_ssd'].toString().toLowerCase()),
        );
      _anniAccademici
        ..clear()
        ..addAll((risultati[2] as List).cast<String>());

      final righeAnnuali = (risultati[4] as List).cast<Map<String, dynamic>>();
      _partecipazioniAnnuali
        ..clear()
        ..addAll(
          righeAnnuali.map(
            (riga) => PartecipazioneAnnualeProfilo.daMap(<String, dynamic>{
              ...riga,
              'disponibile': true,
            }),
          ),
        );

      final partecipazioneRaw = risultati[3];
      if (partecipazioneRaw is Map) {
        final statoBase = Map<String, dynamic>.from(partecipazioneRaw);
        final anno = statoBase['anno_accademico']?.toString();

        if (statoBase['disponibile'] == true &&
            anno != null &&
            anno.isNotEmpty) {
          Map<String, dynamic>? rigaAnnuale;
          for (final riga in righeAnnuali) {
            if (riga['anno_accademico']?.toString() == anno) {
              rigaAnnuale = riga;
              break;
            }
          }

          if (rigaAnnuale != null) {
            statoBase.addAll(rigaAnnuale);
            statoBase['disponibile'] = true;
            statoBase['anno_accademico'] = anno;
          }
        }

        _partecipazioneAnnuale = PartecipazioneAnnualeProfilo.daMap(statoBase);
      } else {
        _partecipazioneAnnuale = null;
      }

      final annoProfilo = _profilo?['anno_prima_partecipazione']
          ?.toString()
          .trim();
      if (annoProfilo != null &&
          annoProfilo.isNotEmpty &&
          !_anniAccademici.contains(annoProfilo)) {
        _anniAccademici.add(annoProfilo);
      }

      _puoModificare = sessione.ruolo == AppRole.participant
          ? true
          : sessione.ruolo?.puoAmministrare ?? false;

      if (!_puoModificare) {
        _puoModificare = await _repository.puoModificareCorrente();
      }
    } catch (errore) {
      _errore = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile caricare il profilo.',
      ).messaggio;
    } finally {
      _caricamento = false;
      notifyListeners();
    }
  }

  /// Gestisce l’operazione `rispondiPartecipazione` specifica di questa pagina.
  Future<void> rispondiPartecipazione(bool partecipa) async {
    if (_partecipazioneAnnuale?.daConfermare != true) {
      throw const AppException(
        'Non è presente una richiesta di partecipazione da confermare.',
      );
    }

    _salvataggioPartecipazione = true;
    _errore = null;
    notifyListeners();

    try {
      final raw = await _repository.rispondiPartecipazione(partecipa);
      _partecipazioneAnnuale = PartecipazioneAnnualeProfilo.daMap(raw);
      await carica();
    } catch (errore) {
      final eccezione = AppErrorMapper.converti(
        errore,
        messaggioGenerico:
            'Impossibile registrare la conferma di partecipazione.',
      );
      _errore = eccezione.messaggio;
      throw eccezione;
    } finally {
      _salvataggioPartecipazione = false;
      notifyListeners();
    }
  }

  /// Salva l’operazione `salvaRicognizioneAnnuale` mantenendo separata la logica dalla UI.
  Future<void> salvaRicognizioneAnnuale(Map<String, dynamic> valori) async {
    final userId = _repository.userIdCorrente;
    final anno = _partecipazioneAnnuale?.annoAccademico;

    if (userId == null || anno == null || anno.isEmpty) {
      throw const AppException('Partecipazione annuale non disponibile.');
    }

    if (_partecipazioneAnnuale?.daConfermare != true) {
      throw const AppException(
        'La richiesta di partecipazione non è più in attesa di conferma.',
      );
    }

    _salvataggioPartecipazione = true;
    _errore = null;
    notifyListeners();

    try {
      await _repository.aggiornaPartecipazioneAnnuale(
        anno: anno,
        valori: <String, dynamic>{
          'preferenza_periodo_mentore': valori['preferenza_periodo_mentore'],
          'note_attivita_mentore': _testoNull(valori['note_attivita_mentore']),
          'solo_mentore': valori['solo_mentore'] == true,
          'valutazione_mentori_precedenti':
              valori['valutazione_mentori_precedenti'],
          'cambiare_mentore': valori['cambiare_mentore'],
          'note_sui_mentori': _testoNull(valori['note_sui_mentori']),
          'cambiare_mentee_seguiti': _testoNull(
            valori['cambiare_mentee_seguiti'],
          ),
          'disponibile_mentoring_esami': valori['disponibile_mentoring_esami'],
          'segnalazioni_suggerimenti': _testoNull(
            valori['segnalazioni_suggerimenti'],
          ),
        },
      );

      await _repository.rispondiPartecipazione(true);

      await carica();
    } catch (errore) {
      final eccezione = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile salvare la ricognizione annuale.',
      );
      _errore = eccezione.messaggio;
      throw eccezione;
    } finally {
      _salvataggioPartecipazione = false;
      notifyListeners();
    }
  }

  /// Aggiorna l’operazione `cambiaPassword` mantenendo separata la logica dalla UI.
  Future<void> cambiaPassword(String nuovaPassword) async {
    if (nuovaPassword.length < 8) {
      throw const AppException(
        'La nuova password deve avere almeno 8 caratteri.',
      );
    }

    _salvataggioPassword = true;
    _errore = null;
    notifyListeners();

    try {
      await _repository.cambiaPassword(nuovaPassword);
    } catch (errore) {
      final AppException eccezione = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile modificare la password.',
      );
      _errore = eccezione.messaggio;
      throw eccezione;
    } finally {
      _salvataggioPassword = false;
      notifyListeners();
    }
  }

  /// Gestisce l’operazione `richiediModifica` specifica di questa pagina.
  Future<void> richiediModifica() async {
    try {
      await _repository.richiediModifica();
      _errore = null;
    } catch (errore) {
      _errore = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile inviare la richiesta.',
      ).messaggio;
      rethrow;
    } finally {
      notifyListeners();
    }
  }

  /// Valida e salva i dati richiesti dalla pagina.
  Future<void> salva(Map<String, dynamic> valori) async {
    final String? userId = _repository.userIdCorrente;
    if (userId == null || !_puoModificare) {
      throw const AppException('Modifica del profilo non autorizzata.');
    }

    _salvataggio = true;
    _errore = null;
    notifyListeners();

    try {
      final schema = await _repository.schemaDatabase();
      final tabella = schema.tabella('anagrafica');
      final valoriDatabase = <String, dynamic>{};
      for (final voce in valori.entries) {
        if (_profilo?[voce.key] == voce.value) continue;
        final campo = tabella?.campo(voce.key);
        if (campo != null &&
            (campo.chiavePrimaria ||
                campo.identita ||
                campo.generato ||
                campo.solaLettura)) {
          continue;
        }
        valoriDatabase[voce.key] = voce.value;
      }

      if (valoriDatabase.isEmpty) return;

      final Map<String, dynamic>? aggiornata = await _repository
          .aggiornaProfilo(valoriDatabase);
      if (aggiornata == null) {
        throw const AppException('Salvataggio del profilo non riuscito.');
      }
      _profilo = aggiornata;
    } catch (errore) {
      final AppException eccezione = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile salvare il profilo.',
      );
      _errore = eccezione.messaggio;
      throw eccezione;
    } finally {
      _salvataggio = false;
      notifyListeners();
    }
  }
}

String? _testoNull(Object? valore) {
  final testo = valore?.toString().trim() ?? '';
  return testo.isEmpty ? null : testo;
}

int? _intNull(Object? valore) {
  if (valore is int) return valore;
  return int.tryParse(valore?.toString() ?? '');
}
