import 'package:flutter/foundation.dart';

import '../../app/app_core.dart';
import '../../app/app_session_controller.dart';
import '../../dati/repository.dart';
import '../../ui/schema_dinamico.dart';

/// Controller di house of mentore; coordina stato e logica applicativa.
class HouseOfMentoreController extends ChangeNotifier {
  HouseOfMentoreController(
    this.sessione, {
    HouseOfMentoreRepository? repository,
  }) : _repository = repository ?? HouseOfMentoreRepository();

  final SessioneController sessione;
  final HouseOfMentoreRepository _repository;

  /// Carica lo schema usato dalla visualizzazione locale della pagina.
  Future<SchemaDatabase> caricaSchemaDatabase() => _repository.schemaDatabase();
  final eventi = <Map<String, dynamic>>[];
  final opzioniPerEvento = <String, List<Map<String, dynamic>>>{};
  final iscrizioni = <String, Map<String, dynamic>>{};
  final anniAccademici = <String>[];

  /// Iscritti visibili solo a owner/organizer, raggruppati per iniziativa.
  final Map<String, List<Map<String, dynamic>>> iscrittiPerEvento =
      <String, List<Map<String, dynamic>>>{};
  final Map<String, Map<String, dynamic>> anagraficaPerUserId =
      <String, Map<String, dynamic>>{};

  bool caricamento = false;
  String? errore;
  String? eventoSelezionatoId;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  Map<String, dynamic>? get eventoSelezionato {
    for (final evento in eventi) {
      if (evento['id']?.toString() == eventoSelezionatoId) {
        return evento;
      }
    }
    return eventi.isEmpty ? null : eventi.first;
  }

  List<Map<String, dynamic>> opzioni(String eventoId) =>
      opzioniPerEvento[eventoId] ?? const <Map<String, dynamic>>[];

  /// Gestisce l’operazione `iscrizione` specifica di questa pagina.
  Map<String, dynamic>? iscrizione(String eventoId) => iscrizioni[eventoId];

  List<Map<String, dynamic>> iscritti(String eventoId) =>
      iscrittiPerEvento[eventoId] ?? const <Map<String, dynamic>>[];

  /// Restituisce l’operazione `nomePartecipante` mantenendo separata la logica dalla UI.
  String nomePartecipante(String userId) {
    final persona = anagraficaPerUserId[userId];
    if (persona == null) return userId;
    final cognome = persona['cognome']?.toString().trim() ?? '';
    final nome = persona['nome']?.toString().trim() ?? '';
    final completo = '$cognome $nome'.trim();
    return completo.isEmpty ? userId : completo;
  }

  /// Restituisce l’operazione `descrizioneOpzione` mantenendo separata la logica dalla UI.
  String descrizioneOpzione(String eventoId, Object? opzioneId) {
    final id = opzioneId?.toString() ?? '';
    if (id.isEmpty) return '—';
    for (final opzione in opzioni(eventoId)) {
      if (opzione['id']?.toString() == id) {
        return opzione['descrizione']?.toString().trim() ?? '—';
      }
    }
    return id;
  }

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      final userId = _repository.userIdCorrente;
      if (userId == null) {
        throw const AppException('Sessione non valida.');
      }

      final risultati = await Future.wait<dynamic>([
        _repository.eventi(),
        _repository.opzioni(),
        _repository.partecipazioni(userId: userId),
        _repository.anniAccademici(),
      ]);

      eventi
        ..clear()
        ..addAll((risultati[0] as List).cast<Map<String, dynamic>>());

      opzioniPerEvento.clear();
      for (final opzione
          in (risultati[1] as List).cast<Map<String, dynamic>>()) {
        final eventoId = opzione['evento_id'].toString();
        opzioniPerEvento.putIfAbsent(eventoId, () => []).add(opzione);
      }

      iscrizioni.clear();
      for (final partecipazione
          in (risultati[2] as List).cast<Map<String, dynamic>>()) {
        iscrizioni[partecipazione['evento_id'].toString()] = partecipazione;
      }

      anniAccademici
        ..clear()
        ..addAll((risultati[3] as List).cast<String>());

      iscrittiPerEvento.clear();
      anagraficaPerUserId.clear();
      if (puoGestire) {
        final risultatiGestione = await Future.wait<dynamic>(<Future<dynamic>>[
          _repository.partecipazioni(),
          _repository.anagraficheEssenziali(),
        ]);
        for (final riga
            in (risultatiGestione[0] as List).cast<Map<String, dynamic>>()) {
          final eventoId = riga['evento_id']?.toString() ?? '';
          if (eventoId.isEmpty) continue;
          iscrittiPerEvento.putIfAbsent(eventoId, () => <Map<String, dynamic>>[]).add(riga);
        }
        for (final persona
            in (risultatiGestione[1] as List).cast<Map<String, dynamic>>()) {
          final id = persona['user_id']?.toString() ?? '';
          if (id.isNotEmpty) anagraficaPerUserId[id] = persona;
        }
      }

      if (eventi.isNotEmpty &&
          !eventi.any(
            (evento) => evento['id'].toString() == eventoSelezionatoId,
          )) {
        eventoSelezionatoId = eventi.first['id'].toString();
      }
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare House of Mentore.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  /// Aggiorna il record selezionato nella pagina.
  void seleziona(Map<String, dynamic> evento) {
    eventoSelezionatoId = evento['id'].toString();
    notifyListeners();
  }


  /// Aggiorna l’operazione `aggiornaPresenza` mantenendo separata la logica dalla UI.
  Future<String?> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) => _esegui(
    azione: () async {
      _verificaGestore();
      await _repository.aggiornaPresenza(
        eventoId: eventoId,
        partecipanteId: partecipanteId,
        presente: presente,
      );
    },
    messaggio: 'Impossibile aggiornare la presenza.',
  );

  /// Salva l’operazione `salvaEvento` mantenendo separata la logica dalla UI.
  Future<String?> salvaEvento({
    String? id,
    required Map<String, dynamic> dati,
  }) => _esegui(
    azione: () async {
      _verificaGestore();
      await _repository.salvaEvento(id: id, valori: dati);
    },
    messaggio: 'Impossibile salvare House of Mentore.',
  );

  /// Elimina l’operazione `eliminaEvento` mantenendo separata la logica dalla UI.
  Future<String?> eliminaEvento(String id) => _esegui(
    azione: () async {
      _verificaGestore();
      await _repository.eliminaEvento(id);
      eventoSelezionatoId = null;
    },
    messaggio: 'Impossibile eliminare House of Mentore.',
  );

  /// Salva l’operazione `salvaOpzione` mantenendo separata la logica dalla UI.
  Future<String?> salvaOpzione({
    String? id,
    required String eventoId,
    required String descrizione,
    required int ordine,
  }) => _esegui(
    azione: () async {
      _verificaGestore();
      final dati = <String, dynamic>{
        'evento_id': eventoId,
        'descrizione': descrizione.trim(),
        'ordine_visualizzazione': ordine,
      };
      await _repository.salvaOpzione(id: id, valori: dati);
    },
    messaggio: 'Impossibile salvare l’alternativa.',
  );

  /// Elimina l’operazione `eliminaOpzione` mantenendo separata la logica dalla UI.
  Future<String?> eliminaOpzione(String id) => _esegui(
    azione: () async {
      _verificaGestore();
      await _repository.eliminaOpzione(id);
    },
    messaggio:
        'Impossibile eliminare l’alternativa. Potrebbe essere già stata scelta.',
  );

  /// Registra l’operazione `scegliOpzione` mantenendo separata la logica dalla UI.
  Future<String?> scegliOpzione({
    required String eventoId,
    required String opzioneId,
  }) => _esegui(
    azione: () async {
      await _repository.scegliOpzione(
        eventoId: eventoId,
        opzioneId: opzioneId,
      );
    },
    messaggio: 'Impossibile registrare la scelta.',
  );

  /// Annulla l’operazione `cancellaIscrizione` mantenendo separata la logica dalla UI.
  Future<String?> cancellaIscrizione(String eventoId) => _esegui(
    azione: () async {
      await _repository.cancellaIscrizione(eventoId);
    },
    messaggio: 'Impossibile cancellare l’iscrizione.',
  );

  /// Esegue l’operazione applicativa con gestione uniforme degli errori.
  Future<String?> _esegui({
    required Future<void> Function() azione,
    required String messaggio,
  }) async {
    try {
      await azione();
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(e, messaggioGenerico: messaggio).messaggio;
    }
  }

  /// Verifica gestore.
  void _verificaGestore() {
    if (!puoGestire) {
      throw const AppException('Operazione non autorizzata.');
    }
  }
}
