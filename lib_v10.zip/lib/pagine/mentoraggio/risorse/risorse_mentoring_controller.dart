import 'package:flutter/foundation.dart';
import '../../../app/app_core.dart';
import '../../../supporto/nomi_file.dart';
import '../../../app/app_session_controller.dart';
import '../../../dati/repository.dart';

/// Controller di risorse mentoring; coordina stato e logica applicativa.
class RisorseMentoringController extends ChangeNotifier {
  RisorseMentoringController(this.sessione, {RisorseMentoringRepository? repository})
      : _repository = repository ?? RisorseMentoringRepository();

  final SessioneController sessione;
  final RisorseMentoringRepository _repository;

  static const int dimensioneMassima = 20 * 1024 * 1024;

  static const List<String> categorie = <String>[
    'Materiale di presentazione',
    "Materiale per l'attività di mentoraggio",
    'Materiale burocratico/amministrativo',
    'Altro',
  ];

  final List<Map<String, dynamic>> risorse = <Map<String, dynamic>>[];
  final List<String> anniAccademici = <String>[];

  bool caricamento = false;
  String? errore;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      final risultati = await _repository.caricaDati();

      risorse
        ..clear()
        ..addAll((risultati[0] as List).cast<Map<String, dynamic>>());

      anniAccademici
        ..clear()
        ..addAll(
          (risultati[1] as List)
              .cast<Map<String, dynamic>>()
              .map((riga) => riga['codice'].toString()),
        );
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare le risorse per il mentoring.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  List<Map<String, dynamic>> perCategoria(String categoria) => risorse
      .where((riga) => riga['categoria']?.toString() == categoria)
      .toList(growable: false);

  /// Carica l’operazione `caricaRisorsa` mantenendo separata la logica dalla UI.
  Future<String?> caricaRisorsa({
    required Uint8List bytes,
    required String nomeFile,
    required String titolo,
    required String categoria,
    String? descrizione,
    String? annoAccademico,
  }) async {
    try {
      if (!puoGestire) {
        throw const AppException('Operazione non autorizzata.');
      }
      if (titolo.trim().isEmpty) {
        throw const AppException('Titolo obbligatorio.');
      }
      if (!categorie.contains(categoria)) {
        throw const AppException('Categoria non valida.');
      }
      if (bytes.lengthInBytes > dimensioneMassima) {
        throw const AppException('Il file supera il limite massimo di 20 MB.');
      }

      final userId = _repository.userIdCorrente;
      if (userId == null) {
        throw const AppException('Sessione non valida.');
      }

      final nomeSicuro = nomeFileSicuro(nomeFile);
      final categoriaSicura = nomeFileSicuro(
        categoria,
        consentiPunto: false,
      );
      final timestamp = DateTime.now().microsecondsSinceEpoch;
      final path = '$categoriaSicura/$timestamp-$userId-$nomeSicuro';

      await _repository.creaRisorsa(
        bytes: bytes,
        path: path,
        nomeFile: nomeFile,
        titolo: titolo,
        categoria: categoria,
        descrizione: descrizione,
        annoAccademico: annoAccademico,
        userId: userId,
      );

      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare la risorsa.',
      ).messaggio;
    }
  }

  /// Gestisce l’operazione `urlDownload` specifica di questa pagina.
  Future<Uri> urlDownload(Map<String, dynamic> risorsa) async {
    final path = risorsa['storage_path']?.toString() ?? '';
    if (path.isEmpty) {
      throw const AppException('Percorso del file non disponibile.');
    }
    final url = await _repository.creaUrlDownload(path);
    return Uri.parse(url);
  }

  /// Elimina il record indicato e aggiorna lo stato locale.
  Future<String?> elimina(Map<String, dynamic> risorsa) async {
    try {
      if (!puoGestire) {
        throw const AppException('Operazione non autorizzata.');
      }
      final id = risorsa['id']?.toString();
      final path = risorsa['storage_path']?.toString();
      if (id == null || id.isEmpty) {
        throw const AppException('Risorsa non valida.');
      }

      await _repository.eliminaRisorsa(id: id, path: path);
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile eliminare la risorsa.',
      ).messaggio;
    }
  }
}
