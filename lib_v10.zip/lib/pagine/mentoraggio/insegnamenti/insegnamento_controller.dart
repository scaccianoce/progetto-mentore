import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';

import '../../../app/app_core.dart';
import '../../../app/app_session_controller.dart';
import '../../../dati/repository.dart';
import '../../../ui/schema_dinamico.dart';

/// Modello o componente interno “StatoInsegnamentoAnnuale” usato esclusivamente da questo file.
class StatoInsegnamentoAnnuale {
  const StatoInsegnamentoAnnuale({
    required this.annoAccademico,
    required this.annoCorrente,
    required this.nonRichiesto,
    required this.puoSelezionare,
    required this.puoCreare,
    required this.puoModificare,
    this.partecipazioneStato,
    this.soloMentore = false,
    this.mentoraggioId,
    this.insegnamentoId,
  });

  factory StatoInsegnamentoAnnuale.daMap(Map<String, dynamic> map) {
    return StatoInsegnamentoAnnuale(
      annoAccademico: map['anno_accademico']?.toString() ?? '',
      annoCorrente: map['anno_corrente'] == true,
      nonRichiesto: map['non_richiesto'] == true,
      puoSelezionare: map['puo_selezionare'] == true,
      puoCreare: map['puo_creare'] == true,
      puoModificare: map['puo_modificare'] == true,
      partecipazioneStato: map['partecipazione_stato']?.toString(),
      soloMentore: map['solo_mentore'] == true,
      mentoraggioId: map['mentoraggio_id']?.toString(),
      insegnamentoId: map['insegnamento_id']?.toString(),
    );
  }

  final String annoAccademico;
  final bool annoCorrente;
  final bool nonRichiesto;
  final bool puoSelezionare;
  final bool puoCreare;
  final bool puoModificare;
  final String? partecipazioneStato;
  final bool soloMentore;
  final String? mentoraggioId;
  final String? insegnamentoId;

  bool get haMentoraggio => mentoraggioId != null;
  bool get partecipazioneConfermata =>
      partecipazioneStato == null ||
      partecipazioneStato == 'confermato' ||
      partecipazioneStato == 'nuovo';
}

/// Controller di scelta insegnamento annuale; coordina stato e logica applicativa.
class SceltaInsegnamentoAnnualeController {
  SceltaInsegnamentoAnnualeController({
    InsegnamentiRepository? repository,
  }) : _repository = repository ??
            InsegnamentiRepository(RepositoryComune());

  final InsegnamentiRepository _repository;
  String? _annoGestione;

  /// Gestisce l’operazione `annoGestione` specifica di questa pagina.
  Future<String?> annoGestione() async {
    if (_annoGestione != null && _annoGestione!.isNotEmpty) {
      return _annoGestione;
    }
    _annoGestione = await _repository.annoGestione();
    return _annoGestione;
  }

  /// Carica l’operazione `caricaStato` mantenendo separata la logica dalla UI.
  Future<StatoInsegnamentoAnnuale> caricaStato() async {
    final anno = await annoGestione();

    final raw = await _repository.statoAnnuale(anno);
    if (raw == null) {
      throw StateError('Stato annuale dell’insegnamento non disponibile.');
    }

    final mappa = Map<String, dynamic>.from(raw);

    // solo_mentore appartiene alla partecipazione annuale, non
    // all'insegnamento. Lo leggiamo direttamente dalla tabella così
    // non è necessario modificare la RPC insegnamento_stato_annuale.
    if (anno != null && anno.isNotEmpty) {
      final userId = _repository.userIdCorrente;

      if (userId != null) {
        final partecipazione = await _repository.partecipazioneAnnuale(
          userId: userId,
          annoAccademico: anno,
        );

        if (partecipazione != null) {
          mappa['partecipazione_stato'] =
              partecipazione['stato']?.toString();
          mappa['solo_mentore'] =
              partecipazione['solo_mentore'] == true;
        }
      }
    }

    return StatoInsegnamentoAnnuale.daMap(mappa);
  }

  Future<List<Map<String, dynamic>>> caricaInsegnamenti() async {
    return _repository.miei();
  }

  /// Aggiorna il record selezionato nella pagina.
  Future<void> seleziona(String insegnamentoId) async {
    final anno = await annoGestione();
    await _repository.selezionaPerAnno(
      insegnamentoId: insegnamentoId,
      annoAccademico: anno,
    );
  }

  /// Crea l’operazione `crea` mantenendo separata la logica dalla UI.
  Future<void> crea(Map<String, dynamic> valori) async {
    final anno = await annoGestione();
    await _repository.creaPerAnno(
      valori: valori,
      annoAccademico: anno,
    );
  }

  /// Gestisce la modifica di l’operazione `modifica` mantenendo separata la logica dalla UI.
  Future<void> modifica(
    String insegnamentoId,
    Map<String, dynamic> valori,
  ) async {
    final anno = await annoGestione();
    await _repository.modificaAutorizzata(
      insegnamentoId: insegnamentoId,
      valori: valori,
      annoAccademico: anno,
    );
  }

  /// Gestisce l’operazione `invalidaAnno` specifica di questa pagina.
  void invalidaAnno() {
    _annoGestione = null;
  }
}

/// Controller di insegnamento; coordina stato e logica applicativa.
class InsegnamentoController extends ChangeNotifier {
  InsegnamentoController({
    required SessioneController sessione,
    MentoraggiRepository? mentoraggiRepository,
  }) : _mentoraggiRepository = mentoraggiRepository ??
            MentoraggiRepository(RepositoryComune());

  final MentoraggiRepository _mentoraggiRepository;

  final SceltaInsegnamentoAnnualeController
      _sceltaAnnualeController =
      SceltaInsegnamentoAnnualeController();

  List<InsegnamentoStorico> _insegnamenti = const [];
  int _indiceSelezionato = 0;

  bool _caricamento = false;
  bool _salvataggio = false;

  String? _errore;

  final Map<String, Map<String, dynamic>?> _risultatiQuestionari =
      <String, Map<String, dynamic>?>{};

  List<InsegnamentoStorico> get insegnamenti =>
      _insegnamenti;

  int get indiceSelezionato =>
      _indiceSelezionato;

  InsegnamentoStorico? get selezionato {
    if (_insegnamenti.isEmpty) {
      return null;
    }

    if (_indiceSelezionato < 0 ||
        _indiceSelezionato >= _insegnamenti.length) {
      return _insegnamenti.first;
    }

    return _insegnamenti[_indiceSelezionato];
  }

  bool get caricamento => _caricamento;

  bool get salvataggio => _salvataggio;

  String? get errore => _errore;

  /// Restituisce un URL apribile per la scheda di sintesi del mentoraggio.
  Future<String> urlSchedaSintesi(String valore) =>
      _mentoraggiRepository.urlSchedaSintesi(valore);

  /// Carica lo schema usato dalla pagina per la propria visualizzazione.
  Future<SchemaDatabase> caricaSchemaDatabase() =>
      _mentoraggiRepository.schemaDatabase();

  // ============================================================
  // CARICAMENTO
  // ============================================================

  Future<void> carica() async {
    _caricamento = true;
    _errore = null;
    notifyListeners();

    try {
      final userId =
          _mentoraggiRepository.userIdCorrente;

      if (userId == null) {
        throw const AppException(
          'Utente non autenticato.',
        );
      }

      final risultati =
          await Future.wait<dynamic>([
        _sceltaAnnualeController
            .caricaInsegnamenti(),

        _mentoraggiRepository.mentoraggiDelMentee(),
      ]);

      final insegnamentiRaw =
          (risultati[0] as List)
              .map(
                (e) =>
                    Map<String, dynamic>.from(
                  e as Map,
                ),
              )
              .toList();

      final mentoraggiRaw =
          (risultati[1] as List)
              .map(
                (e) =>
                    Map<String, dynamic>.from(
                  e as Map,
                ),
              )
              .toList();

      final elementi =
          <InsegnamentoStorico>[];

      for (final insegnamento
          in insegnamentiRaw) {
        final id =
            insegnamento['id']
                ?.toString();

        final mentoraggi =
            mentoraggiRaw
                .where(
                  (mentoraggio) =>
                      mentoraggio[
                                  'insegnamento_id']
                              ?.toString() ==
                          id,
                )
                .toList();

        mentoraggi.sort(
          (a, b) {
            final annoA =
                a['anno_accademico']
                        ?.toString() ??
                    '';

            final annoB =
                b['anno_accademico']
                        ?.toString() ??
                    '';

            return annoB.compareTo(annoA);
          },
        );

        elementi.add(
          InsegnamentoStorico(
            insegnamento:
                insegnamento,
            mentoraggi:
                mentoraggi,
          ),
        );
      }

      _insegnamenti =
          elementi;

      if (_insegnamenti.isEmpty) {
        _indiceSelezionato = 0;
      } else if (_indiceSelezionato >=
          _insegnamenti.length) {
        _indiceSelezionato =
            _insegnamenti.length - 1;
      }
    } on AppException catch (e) {
      _errore = e.messaggio;
    } catch (e) {
      _errore =
          AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile caricare gli insegnamenti.',
      ).messaggio;
    } finally {
      _caricamento = false;
      notifyListeners();
    }
  }

  // ============================================================
  // SELEZIONE TAB
  // ============================================================

  void seleziona(int indice) {
    if (indice < 0 ||
        indice >= _insegnamenti.length) {
      return;
    }

    if (_indiceSelezionato == indice) {
      return;
    }

    _indiceSelezionato = indice;
    notifyListeners();
  }

  // ============================================================
  // CREAZIONE
  // ============================================================

  Future<void> creaInsegnamento(
    Map<String, dynamic> valori,
  ) async {
    _salvataggio = true;
    _errore = null;
    notifyListeners();

    try {
      await _sceltaAnnualeController
          .crea(
        valori,
      );

      await carica();
    } on AppException {
      rethrow;
    } catch (e) {
      throw AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile creare l’insegnamento.',
      );
    } finally {
      _salvataggio = false;
      notifyListeners();
    }
  }

  // ============================================================
  // SELEZIONE INSEGNAMENTO PRECEDENTE
  // ============================================================

  Future<void> selezionaInsegnamento(
    String insegnamentoId,
  ) async {
    _salvataggio = true;
    _errore = null;
    notifyListeners();

    try {
      await _sceltaAnnualeController
          .seleziona(
        insegnamentoId,
      );

      await carica();
    } on AppException {
      rethrow;
    } catch (e) {
      throw AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile associare l’insegnamento all’anno accademico.',
      );
    } finally {
      _salvataggio = false;
      notifyListeners();
    }
  }

  // ============================================================
  // MODIFICA AUTORIZZATA
  // ============================================================

  Future<void> modificaInsegnamento(
    String insegnamentoId,
    Map<String, dynamic> valori,
  ) async {
    _salvataggio = true;
    _errore = null;
    notifyListeners();

    try {
      await _sceltaAnnualeController
          .modifica(
        insegnamentoId,
        valori,
      );

      await carica();
    } on AppException {
      rethrow;
    } catch (e) {
      throw AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile modificare l’insegnamento.',
      );
    } finally {
      _salvataggio = false;
      notifyListeners();
    }
  }

  // ============================================================
  // RISULTATI QUESTIONARIO STUDENTI / STORICO
  // ============================================================

  Future<Map<String, dynamic>?> risultatiMentoraggio(
    String mentoraggioId, {
    bool forza = false,
  }) async {
    if (!forza && _risultatiQuestionari.containsKey(mentoraggioId)) {
      return _risultatiQuestionari[mentoraggioId];
    }

    final risultato = await _mentoraggiRepository.risultatiQuestionario(
      mentoraggioId,
    );
    _risultatiQuestionari[mentoraggioId] = risultato;
    return risultato;
  }

  /// Gestisce l’operazione `esportaCsvQuestionarioMentoraggio` specifica di questa pagina.
  Future<String?> esportaCsvQuestionarioMentoraggio(
    String mentoraggioId,
  ) async {
    try {
      final dati = await risultatiMentoraggio(
        mentoraggioId,
        forza: true,
      );
      if (dati == null || dati['questionario_id'] == null) {
        throw const AppException(
          'Nessun questionario studenti disponibile.',
        );
      }

      final domande = (dati['domande'] as List? ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(growable: false);
      final compilazioni = (dati['compilazioni'] as List? ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(growable: false);
      final risposte = (dati['risposte'] as List? ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(growable: false);

      String csv(Object? valore) {
        final testo = valore?.toString() ?? '';
        return '"${testo.replaceAll('"', '""')}"';
      }

      final buffer = StringBuffer('data_compilazione');
      for (final domanda in domande) {
        buffer.write(',${csv(domanda['testo'])}');
      }
      buffer.writeln();

      for (final compilazione in compilazioni) {
        buffer.write(csv(compilazione['inviato_at']));
        for (final domanda in domande) {
          Object? valore;
          for (final risposta in risposte) {
            if (risposta['compilazione_id']?.toString() ==
                    compilazione['id']?.toString() &&
                risposta['domanda_id']?.toString() ==
                    domanda['id']?.toString()) {
              valore = risposta['valore'];
              break;
            }
          }
          buffer.write(',${csv(valore)}');
        }
        buffer.writeln();
      }

      await FilePicker.saveFile(
        dialogTitle: 'Esporta risultati questionario',
        fileName: 'questionario_${mentoraggioId}_risultati.csv',
        bytes: Uint8List.fromList(utf8.encode(buffer.toString())),
        mimeType: 'text/csv',
      );
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile esportare i risultati.',
      ).messaggio;
    }
  }

  // ============================================================
  // COMPATIBILITÀ CON EVENTUALE CODICE PRECEDENTE
  // ============================================================

  Future<void> salvaInsegnamento(
    Map<String, dynamic> valori, {
    String? insegnamentoId,
  }) async {
    if (insegnamentoId == null) {
      await creaInsegnamento(
        valori,
      );
    } else {
      await modificaInsegnamento(
        insegnamentoId,
        valori,
      );
    }
  }
}

/// Modello o componente interno “InsegnamentoStorico” usato esclusivamente da questo file.
class InsegnamentoStorico {
  const InsegnamentoStorico({
    required this.insegnamento,
    required this.mentoraggi,
  });

  final Map<String, dynamic> insegnamento;

  final List<Map<String, dynamic>> mentoraggi;
}
