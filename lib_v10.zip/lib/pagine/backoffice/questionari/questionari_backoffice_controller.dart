import 'package:flutter/foundation.dart';

import '../../../app/app_core.dart';
import '../../../app/app_session_controller.dart';
import '../../../dati/repository.dart';

/// Amministra esclusivamente template e domande del backoffice.
class QuestionariController extends ChangeNotifier {
  QuestionariController(this.sessione, {QuestionariRepository? repository})
    : repository = repository ?? QuestionariRepository();

  final SessioneController sessione;
  final QuestionariRepository repository;
  final List<Map<String, dynamic>> template = <Map<String, dynamic>>[];
  final List<Map<String, dynamic>> domande = <Map<String, dynamic>>[];

  bool caricamento = false;
  String? errore;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();
    try {
      final dati = await repository.caricaCatalogo(includiQuestionari: false);
      template
        ..clear()
        ..addAll(dati.template);
      domande
        ..clear()
        ..addAll(dati.domande);
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i template dei questionari.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  List<Map<String, dynamic>> domandeTemplate(String templateId) => domande
      .where((riga) => riga['template_id']?.toString() == templateId)
      .toList(growable: false);

  /// Salva l’operazione `salvaTemplate` mantenendo separata la logica dalla UI.
  Future<String?> salvaTemplate({
    String? id,
    required String titolo,
    required String destinatario,
    String? descrizione,
    bool attivo = true,
  }) => _esegui(() async {
    if (!puoGestire) throw const AppException('Operazione non autorizzata.');
    final dati = <String, dynamic>{
      'titolo': titolo.trim(),
      'destinatario': destinatario,
      'descrizione': descrizione == null || descrizione.trim().isEmpty
          ? null
          : descrizione.trim(),
      'attivo': attivo,
      'created_by': repository.userIdCorrente,
    };
    if (dati['titolo'].toString().isEmpty) {
      throw const AppException('Titolo obbligatorio.');
    }
    if (id == null) {
      await repository.inserisciTemplate(dati);
    } else {
      dati.remove('created_by');
      await repository.aggiornaTemplate(id, dati);
    }
  });

  /// Aggiunge l’operazione `aggiungiDomanda` mantenendo separata la logica dalla UI.
  Future<String?> aggiungiDomanda({
    required String templateId,
    required int ordine,
    required String testo,
    required String tipo,
    required bool obbligatoria,
    Object? opzioni,
  }) => _esegui(() async {
    if (!puoGestire) throw const AppException('Operazione non autorizzata.');
    if (testo.trim().isEmpty) {
      throw const AppException('Testo della domanda obbligatorio.');
    }
    await repository.inserisciDomanda(<String, dynamic>{
      'template_id': templateId,
      'ordine': ordine,
      'testo': testo.trim(),
      'tipo': tipo,
      'obbligatoria': obbligatoria,
      'opzioni': opzioni,
    });
  });

  /// Elimina l’operazione `eliminaDomanda` mantenendo separata la logica dalla UI.
  Future<String?> eliminaDomanda(String domandaId) => _esegui(() async {
    if (!puoGestire) throw const AppException('Operazione non autorizzata.');
    await repository.eliminaDomanda(domandaId);
  });

  /// Sposta l’operazione `spostaDomanda` mantenendo separata la logica dalla UI.
  Future<String?> spostaDomanda({
    required String templateId,
    required String domandaId,
    required bool versoAlto,
  }) => _esegui(() async {
    if (!puoGestire) throw const AppException('Operazione non autorizzata.');
    final elenco = await repository.ordiniDomande(templateId);
    final indice = elenco.indexWhere(
      (riga) => riga['id']?.toString() == domandaId,
    );
    if (indice < 0) throw const AppException('Domanda non trovata.');

    final indiceDestinazione = versoAlto ? indice - 1 : indice + 1;
    if (indiceDestinazione < 0 || indiceDestinazione >= elenco.length) return;

    final corrente = elenco[indice];
    final destinazione = elenco[indiceDestinazione];
    final ordineCorrente = int.tryParse(corrente['ordine']?.toString() ?? '');
    final ordineDestinazione = int.tryParse(
      destinazione['ordine']?.toString() ?? '',
    );
    if (ordineCorrente == null || ordineDestinazione == null) {
      throw const AppException(
        'Impossibile determinare l’ordine delle domande.',
      );
    }

    final ordineMinimo = elenco
        .map((riga) => int.tryParse(riga['ordine']?.toString() ?? '') ?? 0)
        .reduce((a, b) => a < b ? a : b);
    await repository.aggiornaOrdineDomanda(domandaId, ordineMinimo - 1000);
    try {
      await repository.aggiornaOrdineDomanda(
        destinazione['id'].toString(),
        ordineCorrente,
      );
      await repository.aggiornaOrdineDomanda(domandaId, ordineDestinazione);
    } catch (_) {
      await repository.aggiornaOrdineDomanda(
        destinazione['id'].toString(),
        ordineDestinazione,
      );
      await repository.aggiornaOrdineDomanda(domandaId, ordineCorrente);
      rethrow;
    }
  });

  /// Esegue l’operazione applicativa con gestione uniforme degli errori.
  Future<String?> _esegui(Future<void> Function() azione) async {
    try {
      await azione();
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Operazione sui template non riuscita.',
      ).messaggio;
    }
  }
}
