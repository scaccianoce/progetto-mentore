import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:prog_mentore/ui/schema_dinamico.dart';
import '../../../app/app_core.dart';
import '../../../supporto/formattazione_data.dart';
import 'notifiche_backoffice_controller.dart';

part 'notifiche_backoffice_messaggi.dart';
part 'notifiche_backoffice_destinatari_dialog.dart';
part 'notifiche_backoffice_messaggio_dialog.dart';
part 'notifiche_backoffice_regole.dart';
part 'notifiche_backoffice_regola_dialog.dart';

/// Gestione notifiche riservata a owner e organizer.
///
/// Il router/menu applicano il controllo di ruolo; le RLS DB devono mantenere
/// lo stesso vincolo lato server.
///
/// Il controller è creato qui e vive quanto la pagina: viene passato alle due
/// schede (Messaggi/Regole) e ai loro dialog invece di essere condiviso come
/// istanza globale.
class NotificheBackofficePage extends StatefulWidget {
  const NotificheBackofficePage({super.key});

  @override
  State<NotificheBackofficePage> createState() =>
      _NotificheBackofficePageState();
}

class _NotificheBackofficePageState extends State<NotificheBackofficePage> {
  late final NotificheBackofficeController controller;

  @override
  void initState() {
    super.initState();
    controller = NotificheBackofficeController();
  }

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: SafeArea(
          minimum: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              const TabBar(
                tabs: <Widget>[
                  Tab(icon: Icon(Icons.notifications_outlined), text: 'Messaggi'),
                  Tab(icon: Icon(Icons.rule_outlined), text: 'Regole'),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: TabBarView(
                  children: <Widget>[
                    NotificheMessaggiBackofficePage(controller: controller),
                    NotificheRegoleBackofficePage(controller: controller),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

