part of 'notifiche_backoffice_page.dart';

/// Modello o componente interno “RegolaDialog” usato esclusivamente da questo file.
class _RegolaDialog extends StatefulWidget {
  const _RegolaDialog({
    required this.controller,
    required this.schema,
    this.regola,
  });

  final NotificheBackofficeController controller;
  final SchemaDatabase schema;
  final Map<String, dynamic>? regola;

  @override
  State<_RegolaDialog> createState() => _RegolaDialogState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _RegolaDialogState extends State<_RegolaDialog> {
  late final TextEditingController _codice;
  late final TextEditingController _descrizione;
  late final TextEditingController _offset;
  late final TextEditingController _titolo;
  late final TextEditingController _messaggio;
  late bool _attiva;
  String? _tipo;
  String? _tabella;
  String? _campoData;
  String? _destinatari;
  DateTime? _dataProgrammata;
  Set<String> _campiMonitorati = <String>{};
  final List<_CondizioneRegola> _condizioni = <_CondizioneRegola>[];
  bool _richiedeAttiva = false;
  bool _soloAnnoCorrente = true;
  String? _campoRiferimentoDestinatari;
  String? _tabellaDestinatariRelazionale;
  String? _campoUserIdDestinatariRelazionale;
  bool _salvataggio = false;
  String? _errore;

  CampoDatabase? get _campoTipo =>
      widget.schema.tabella('notifiche_regole')?.campo('tipo_attivazione');
  CampoDatabase? get _campoDestinatari =>
      widget.schema.tabella('notifiche_regole')?.campo('destinatari');

  List<String> get _tipi => _campoTipo?.valoriScelta ?? const <String>[];
  List<String> get _destinatariDisponibili =>
      _campoDestinatari?.valoriScelta ?? const <String>[];

  List<TabellaDatabase> get _tabelle {
    final result = widget.schema.tabelle
        .where((t) => t.eTabellaBase != false)
        .where((t) => !t.nome.startsWith('notifiche_'))
        .toList();
    result.sort((a, b) => a.nome.compareTo(b.nome));
    return result;
  }

  TabellaDatabase? get _tabellaSelezionata =>
      _tabella == null ? null : widget.schema.tabella(_tabella!);

  List<CampoDatabase> get _campiData => (_tabellaSelezionata?.campi ?? const [])
      .where((c) => c.tipo == TipoCampoDinamico.data || c.tipo == TipoCampoDinamico.dataOra)
      .toList(growable: false);

  /// Gestisce l’operazione interna “campo id principale” della pagina.
  String _campoIdPrincipale(TabellaDatabase tabella) {
    for (final campo in tabella.campi) {
      if (campo.chiavePrimaria) return campo.nome;
    }
    if (tabella.campo('id') != null) return 'id';
    return tabella.campi.isEmpty ? 'id' : tabella.campi.first.nome;
  }

  /// Gestisce l’operazione interna “campi di” della pagina.
  List<CampoDatabase> _campiDi(String? nomeTabella) =>
      nomeTabella == null
          ? const <CampoDatabase>[]
          : (widget.schema.tabella(nomeTabella)?.campi ?? const <CampoDatabase>[]);

  /// Gestisce l’operazione interna “percorso verso” della pagina.
  List<_PassoRelazione> _percorsoVerso(String? destinazione) {
    final sorgente = _tabella;
    if (sorgente == null || destinazione == null || sorgente == destinazione) {
      return const <_PassoRelazione>[];
    }
    return _trovaPercorsoRelazioni(widget.schema, sorgente, destinazione) ??
        const <_PassoRelazione>[];
  }

  /// Gestisce l’operazione interna “descrivi percorso” della pagina.
  String _descriviPercorso(List<_PassoRelazione> percorso) {
    if (percorso.isEmpty) {
      return _tabella == null ? 'Nessun percorso' : 'Stessa tabella principale';
    }
    return percorso
        .map((p) => '${p.daTabella}.${p.daCampo} = ${p.aTabella}.${p.aCampo}')
        .join('  →  ');
  }

  bool get _richiedeRiferimentoDestinatari => const <String>{
        'iscritti_evento',
        'iscritti_house_of_mentore',
        'mentor',
        'senior',
        'mentee',
        'mentor_senior',
        'mentor_senior_mentee',
      }.contains(_destinatari);

  /// Inizializza lo stato della pagina e avvia le operazioni iniziali necessarie.
  @override
  void initState() {
    super.initState();
    final r = widget.regola;
    _codice = TextEditingController(text: r?['codice']?.toString() ?? '');
    _descrizione = TextEditingController(text: r?['descrizione']?.toString() ?? '');
    _offset = TextEditingController(text: (r?['offset_giorni'] ?? 0).toString());
    _titolo = TextEditingController(text: r?['titolo_template']?.toString() ?? '');
    _messaggio = TextEditingController(text: r?['messaggio_template']?.toString() ?? '');
    _attiva = r?['attiva'] != false;
    _tipo = r?['tipo_attivazione']?.toString();
    _tabella = r?['tabella']?.toString();
    _campoData = r?['campo_data']?.toString();
    _destinatari = r?['destinatari']?.toString();
    _dataProgrammata = DateTime.tryParse(r?['data_programmata']?.toString() ?? '')?.toLocal();
    final config = r?['configurazione'];
    if (config is Map) {
      if (config['campi_monitorati'] is List) {
        _campiMonitorati = (config['campi_monitorati'] as List)
            .map((e) => e.toString())
            .toSet();
      }
      _richiedeAttiva = config['richiede_attiva'] == true;
      _soloAnnoCorrente = config['solo_anno_corrente'] != false;
      _campoRiferimentoDestinatari =
          config['campo_riferimento_destinatari']?.toString();
      final destinatariRelazionali = config['destinatari_relazionali'];
      if (destinatariRelazionali is Map) {
        _tabellaDestinatariRelazionale =
            destinatariRelazionali['tabella']?.toString();
        _campoUserIdDestinatariRelazionale =
            destinatariRelazionali['campo_user_id']?.toString();
      }
      if (config['condizioni'] is List) {
        for (final raw in config['condizioni'] as List) {
          if (raw is Map) {
            _condizioni.add(
              _CondizioneRegola(
                tabella: raw['tabella']?.toString() ?? _tabella,
                campo: raw['campo']?.toString(),
                operatore: raw['operatore']?.toString() ?? 'eq',
                valore: raw['valore']?.toString(),
                percorso: (raw['percorso'] as List<dynamic>? ?? const [])
                    .whereType<Map>()
                    .map((e) => _PassoRelazione.fromJson(Map<String, dynamic>.from(e)))
                    .toList(growable: false),
              ),
            );
          }
        }
      }
    }
  }

  /// Rilascia listener e controller associati allo stato della pagina.
  @override
  void dispose() {
    _codice.dispose();
    _descrizione.dispose();
    _offset.dispose();
    _titolo.dispose();
    _messaggio.dispose();
    super.dispose();
  }

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    final programmata = _tipo == 'programmata';
    final temporale = _tipo == 'data';
    final update = _tipo == 'update';

    return AlertDialog(
      title: Text(widget.regola == null ? 'Nuova regola' : 'Modifica regola'),
      content: SizedBox(
        width: 700,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _codice,
                decoration: const InputDecoration(labelText: 'Codice'),
              ),
              TextField(
                controller: _descrizione,
                decoration: const InputDecoration(labelText: 'Descrizione'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Regola attiva'),
                value: _attiva,
                onChanged: (v) => setState(() => _attiva = v),
              ),
              DropdownButtonFormField<String>(
                initialValue: _tipi.contains(_tipo) ? _tipo : null,
                decoration: const InputDecoration(labelText: 'Tipo attivazione'),
                items: _tipi
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() {
                  _tipo = v;
                  if (v != 'data') _campoData = null;
                }),
              ),
              if (!programmata) ...<Widget>[
                DropdownButtonFormField<String>(
                  initialValue: _tabelle.any((t) => t.nome == _tabella) ? _tabella : null,
                  decoration: const InputDecoration(labelText: 'Tabella'),
                  items: _tabelle
                      .map((t) => DropdownMenuItem(value: t.nome, child: Text(t.nome)))
                      .toList(),
                  onChanged: (v) => setState(() {
                    _tabella = v;
                    _campoData = null;
                    _campiMonitorati.clear();
                    _condizioni.clear();
                    _campoRiferimentoDestinatari = null;
                    _tabellaDestinatariRelazionale = null;
                    _campoUserIdDestinatariRelazionale = null;
                  }),
                ),
              ],
              if (temporale) ...<Widget>[
                DropdownButtonFormField<String>(
                  initialValue: _campiData.any((c) => c.nome == _campoData) ? _campoData : null,
                  decoration: const InputDecoration(labelText: 'Campo data'),
                  items: _campiData
                      .map((c) => DropdownMenuItem(value: c.nome, child: Text(c.etichetta)))
                      .toList(),
                  onChanged: (v) => setState(() => _campoData = v),
                ),
                TextField(
                  controller: _offset,
                  keyboardType: const TextInputType.numberWithOptions(signed: true),
                  decoration: const InputDecoration(
                    labelText: 'Offset giorni',
                    helperText: 'Valore negativo = prima; positivo = dopo; 0 = stesso giorno.',
                  ),
                ),
              ],
              if (programmata) _selettoreDataProgrammata(),
              if (update && _tabellaSelezionata != null) _selettoreCampiMonitorati(),
              if (!programmata && _tabellaSelezionata != null) ...<Widget>[
                if ((_tabellaSelezionata?.campo('attiva')) != null &&
                    (_tipo == 'insert' || _tipo == 'update'))
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Richiedi record attivo'),
                    subtitle: const Text('La regola scatta solo se il campo attiva è true.'),
                    value: _richiedeAttiva,
                    onChanged: (v) => setState(() => _richiedeAttiva = v),
                  ),
                if (temporale)
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Solo anno accademico corrente'),
                    value: _soloAnnoCorrente,
                    onChanged: (v) => setState(() => _soloAnnoCorrente = v),
                  ),
                _selettoreCondizioni(),
              ],
              DropdownButtonFormField<String>(
                initialValue: _destinatariDisponibili.contains(_destinatari)
                    ? _destinatari
                    : null,
                decoration: const InputDecoration(labelText: 'Destinatari'),
                items: _destinatariDisponibili
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() {
                  _destinatari = v;
                  if (v != 'relazionale') {
                    _tabellaDestinatariRelazionale = null;
                    _campoUserIdDestinatariRelazionale = null;
                  }
                }),
              ),
              if (_destinatari == 'relazionale' && _tabellaSelezionata != null)
                _selettoreDestinatariRelazionali(),
              if (_richiedeRiferimentoDestinatari && _tabellaSelezionata != null)
                DropdownButtonFormField<String>(
                  initialValue: (_tabellaSelezionata?.campi ?? const <CampoDatabase>[])
                          .any((c) => c.nome == _campoRiferimentoDestinatari)
                      ? _campoRiferimentoDestinatari
                      : ((_tabellaSelezionata?.campo('id')) != null ? 'id' : null),
                  decoration: const InputDecoration(
                    labelText: 'Campo riferimento destinatari',
                    helperText: 'Campo che contiene l’ID di evento, House of Mentore o mentoraggio.',
                  ),
                  items: (_tabellaSelezionata?.campi ?? const <CampoDatabase>[])
                      .map((c) => DropdownMenuItem(value: c.nome, child: Text(c.etichetta)))
                      .toList(growable: false),
                  onChanged: (v) => setState(() => _campoRiferimentoDestinatari = v),
                ),
              TextField(
                controller: _titolo,
                decoration: const InputDecoration(labelText: 'Titolo template'),
              ),
              TextField(
                controller: _messaggio,
                minLines: 4,
                maxLines: null,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(labelText: 'Messaggio template'),
              ),
              if (_errore != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(_errore!),
                ),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: _salvataggio ? null : () => Navigator.pop(context, false),
          child: const Text('Annulla'),
        ),
        FilledButton(
          onPressed: _salvataggio ? null : _salva,
          child: const Text('Salva'),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “selettore campi monitorati” della pagina.
  Widget _selettoreCampiMonitorati() {
    final campi = _tabellaSelezionata!.campi;
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text('Campi monitorati'),
      subtitle: Text(
        _campiMonitorati.isEmpty
            ? 'Qualsiasi modifica'
            : _campiMonitorati.join(', '),
      ),
      children: campi
          .map(
            (c) => CheckboxListTile(
              dense: true,
              title: Text(c.etichetta),
              subtitle: Text(c.nome),
              value: _campiMonitorati.contains(c.nome),
              onChanged: (v) => setState(() {
                if (v == true) {
                  _campiMonitorati.add(c.nome);
                } else {
                  _campiMonitorati.remove(c.nome);
                }
              }),
            ),
          )
          .toList(growable: false),
    );
  }

  /// Gestisce l’operazione interna “selettore condizioni” della pagina.
  Widget _selettoreCondizioni() {
    const operatori = <String>[
      'is_null',
      'not_null',
      'eq',
      'neq',
      'true',
      'false',
    ];

    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text('Condizioni opzionali'),
      subtitle: Text(
        _condizioni.isEmpty
            ? 'Nessuna condizione aggiuntiva'
            : '${_condizioni.length} condizioni (tutte devono essere vere)',
      ),
      children: <Widget>[
        for (var i = 0; i < _condizioni.length; i++)
          Builder(
            builder: (context) {
              final condizione = _condizioni[i];
              final tabellaCondizione = condizione.tabella ?? _tabella;
              final campi = _campiDi(tabellaCondizione);
              final percorso = _percorsoVerso(tabellaCondizione);
              final raggiungibile = tabellaCondizione == _tabella || percorso.isNotEmpty;
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            flex: 3,
                            child: DropdownButtonFormField<String>(
                              initialValue: _tabelle.any((t) => t.nome == tabellaCondizione)
                                  ? tabellaCondizione
                                  : null,
                              decoration: const InputDecoration(labelText: 'Tabella condizione'),
                              items: _tabelle
                                  .map((t) => DropdownMenuItem(value: t.nome, child: Text(t.nome)))
                                  .toList(growable: false),
                              onChanged: (v) => setState(() {
                                condizione.tabella = v;
                                condizione.campo = null;
                                condizione.percorso = _percorsoVerso(v);
                              }),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 3,
                            child: DropdownButtonFormField<String>(
                              initialValue: campi.any((c) => c.nome == condizione.campo)
                                  ? condizione.campo
                                  : null,
                              decoration: const InputDecoration(labelText: 'Campo'),
                              items: campi
                                  .map((c) => DropdownMenuItem(value: c.nome, child: Text(c.etichetta)))
                                  .toList(growable: false),
                              onChanged: raggiungibile
                                  ? (v) => setState(() => condizione.campo = v)
                                  : null,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Rimuovi condizione',
                            onPressed: () => setState(() => _condizioni.removeAt(i)),
                            icon: const Icon(Icons.remove_circle_outline),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 6, bottom: 8),
                          child: Text(
                            raggiungibile
                                ? 'Relazione: ${_descriviPercorso(percorso)}'
                                : 'Nessuna relazione FK trovata tra ${_tabella ?? '-'} e ${tabellaCondizione ?? '-'}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ),
                      Row(
                        children: <Widget>[
                          Expanded(
                            flex: 2,
                            child: DropdownButtonFormField<String>(
                              initialValue: operatori.contains(condizione.operatore)
                                  ? condizione.operatore
                                  : 'eq',
                              decoration: const InputDecoration(labelText: 'Operatore'),
                              items: operatori
                                  .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                                  .toList(growable: false),
                              onChanged: (v) => setState(() => condizione.operatore = v ?? 'eq'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          if (!(const <String>{'is_null', 'not_null', 'true', 'false'})
                              .contains(condizione.operatore))
                            Expanded(
                              flex: 3,
                              child: TextFormField(
                                initialValue: condizione.valore,
                                decoration: const InputDecoration(labelText: 'Valore'),
                                onChanged: (v) => condizione.valore = v,
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: _tabellaSelezionata == null
                ? null
                : () => setState(() {
                    _condizioni.add(
                      _CondizioneRegola(
                        tabella: _tabella,
                        campo: _tabellaSelezionata!.campi.isEmpty
                            ? null
                            : _tabellaSelezionata!.campi.first.nome,
                        operatore: 'eq',
                        percorso: const <_PassoRelazione>[],
                      ),
                    );
                  }),
            icon: const Icon(Icons.add),
            label: const Text('Aggiungi condizione'),
          ),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “selettore destinatari relazionali” della pagina.
  Widget _selettoreDestinatariRelazionali() {
    final campi = _campiDi(_tabellaDestinatariRelazionale);
    final percorso = _percorsoVerso(_tabellaDestinatariRelazionale);
    final raggiungibile = _tabellaDestinatariRelazionale == _tabella || percorso.isNotEmpty;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Destinatari da tabella collegata', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: _tabelle.any((t) => t.nome == _tabellaDestinatariRelazionale)
                  ? _tabellaDestinatariRelazionale
                  : null,
              decoration: const InputDecoration(labelText: 'Tabella destinatari'),
              items: _tabelle
                  .map((t) => DropdownMenuItem(value: t.nome, child: Text(t.nome)))
                  .toList(growable: false),
              onChanged: (v) => setState(() {
                _tabellaDestinatariRelazionale = v;
                _campoUserIdDestinatariRelazionale = null;
              }),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: campi.any((c) => c.nome == _campoUserIdDestinatariRelazionale)
                  ? _campoUserIdDestinatariRelazionale
                  : null,
              decoration: const InputDecoration(
                labelText: 'Campo user_id destinatario',
                helperText: 'Il valore del campo deve corrispondere allo user_id dell’anagrafica.',
              ),
              items: campi
                  .map((c) => DropdownMenuItem(value: c.nome, child: Text('${c.etichetta} (${c.nome})')))
                  .toList(growable: false),
              onChanged: raggiungibile
                  ? (v) => setState(() => _campoUserIdDestinatariRelazionale = v)
                  : null,
            ),
            const SizedBox(height: 8),
            Text(
              raggiungibile
                  ? 'Percorso: ${_descriviPercorso(percorso)}'
                  : 'Nessun percorso FK trovato tra ${_tabella ?? '-'} e ${_tabellaDestinatariRelazionale ?? '-'}.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  /// Gestisce l’operazione interna “selettore data programmata” della pagina.
  Widget _selettoreDataProgrammata() {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: const Text('Data e ora programmata'),
      subtitle: Text(
        _dataProgrammata == null
            ? 'Non selezionata'
            : formattaDataOra(_dataProgrammata!),
      ),
      trailing: IconButton(
        tooltip: 'Seleziona',
        icon: const Icon(Icons.event_outlined),
        onPressed: () async {
          final data = await showDatePicker(
            context: context,
            initialDate: _dataProgrammata ?? DateTime.now(),
            firstDate: DateTime.now().subtract(const Duration(days: 1)),
            lastDate: DateTime.now().add(const Duration(days: 3650)),
          );
          if (data == null || !mounted) return;
          final ora = await showTimePicker(
            context: context,
            initialTime: TimeOfDay.fromDateTime(_dataProgrammata ?? DateTime.now()),
          );
          if (ora == null) return;
          setState(() {
            _dataProgrammata = DateTime(data.year, data.month, data.day, ora.hour, ora.minute);
          });
        },
      ),
    );
  }

  /// Gestisce l’operazione interna “salva” della pagina.
  Future<void> _salva() async {
    final codice = _codice.text.trim();
    final descrizione = _descrizione.text.trim();
    final titolo = _titolo.text.trim();
    final messaggio = _messaggio.text.trim();
    if (codice.isEmpty || descrizione.isEmpty || _tipo == null ||
        _destinatari == null || titolo.isEmpty || messaggio.isEmpty) {
      setState(() => _errore = 'Compila tutti i campi obbligatori.');
      return;
    }
    if (_tipo != 'programmata' && _tabella == null) {
      setState(() => _errore = 'Seleziona una tabella.');
      return;
    }
    if (_tipo == 'data' && _campoData == null) {
      setState(() => _errore = 'Seleziona il campo data.');
      return;
    }
    if (_tipo == 'programmata' && _dataProgrammata == null) {
      setState(() => _errore = 'Seleziona data e ora programmate.');
      return;
    }
    for (final condizione in _condizioni) {
      final tabellaCondizione = condizione.tabella ?? _tabella;
      if (tabellaCondizione == null || condizione.campo == null) {
        setState(() => _errore = 'Completa tutte le condizioni opzionali.');
        return;
      }
      final percorso = _percorsoVerso(tabellaCondizione);
      if (tabellaCondizione != _tabella && percorso.isEmpty) {
        setState(() => _errore = 'La tabella $tabellaCondizione non è collegata alla tabella principale $_tabella.');
        return;
      }
      condizione.percorso = percorso;
    }
    if (_destinatari == 'relazionale') {
      if (_tabellaDestinatariRelazionale == null ||
          _campoUserIdDestinatariRelazionale == null) {
        setState(() => _errore = 'Configura tabella e campo dei destinatari relazionali.');
        return;
      }
      final percorso = _percorsoVerso(_tabellaDestinatariRelazionale);
      if (_tabellaDestinatariRelazionale != _tabella && percorso.isEmpty) {
        setState(() => _errore = 'La tabella destinatari non è collegata alla tabella principale.');
        return;
      }
    }

    final config = <String, dynamic>{};
    if (_campiMonitorati.isNotEmpty) {
      config['campi_monitorati'] = _campiMonitorati.toList()..sort();
    }
    if (_richiedeAttiva) config['richiede_attiva'] = true;
    if (_tipo == 'data') config['solo_anno_corrente'] = _soloAnnoCorrente;
    if (_tabellaSelezionata != null) {
      config['tabella_principale'] = _tabellaSelezionata!.nome;
      config['campo_id_principale'] = _campoIdPrincipale(_tabellaSelezionata!);
    }
    if (_richiedeRiferimentoDestinatari &&
        _campoRiferimentoDestinatari != null) {
      config['campo_riferimento_destinatari'] = _campoRiferimentoDestinatari;
    }
    if (_destinatari == 'relazionale') {
      final percorso = _percorsoVerso(_tabellaDestinatariRelazionale);
      config['destinatari_relazionali'] = <String, dynamic>{
        'tabella': _tabellaDestinatariRelazionale,
        'campo_user_id': _campoUserIdDestinatariRelazionale,
        'percorso': percorso.map((p) => p.toJson()).toList(growable: false),
      };
    }
    if (_condizioni.isNotEmpty) {
      config['condizioni'] = _condizioni
          .where((c) => c.campo != null && c.tabella != null)
          .map((c) => <String, dynamic>{
                'tabella': c.tabella,
                'campo': c.campo,
                'operatore': c.operatore,
                'percorso': c.percorso.map((p) => p.toJson()).toList(growable: false),
                if (c.valore != null && c.valore!.isNotEmpty) 'valore': c.valore,
              })
          .toList(growable: false);
    }

    final payload = <String, dynamic>{
      'codice': codice,
      'descrizione': descrizione,
      'attiva': _attiva,
      'tipo_attivazione': _tipo,
      'tabella': _tipo == 'programmata' ? null : _tabella,
      'campo_data': _tipo == 'data' ? _campoData : null,
      'offset_giorni': _tipo == 'data' ? (int.tryParse(_offset.text.trim()) ?? 0) : 0,
      'destinatari': _destinatari,
      'configurazione': jsonDecode(jsonEncode(config)),
      'titolo_template': titolo,
      'messaggio_template': messaggio,
    };

    final tabellaRegole = widget.schema.tabella('notifiche_regole');
    if (tabellaRegole?.campo('data_programmata') != null) {
      payload['data_programmata'] = _tipo == 'programmata'
          ? _dataProgrammata?.toUtc().toIso8601String()
          : null;
    }

    setState(() {
      _salvataggio = true;
      _errore = null;
    });
    try {
      final id = widget.regola?['id'];
      await widget.controller.salvaRegola(id: id, valori: payload);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Salvataggio non riuscito.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _salvataggio = false);
    }
  }

}


/// Modello o componente interno “CondizioneRegola” usato esclusivamente da questo file.
class _CondizioneRegola {
  _CondizioneRegola({
    this.tabella,
    this.campo,
    this.operatore = 'eq',
    this.valore,
    this.percorso = const <_PassoRelazione>[],
  });

  String? tabella;
  String? campo;
  String operatore;
  String? valore;
  List<_PassoRelazione> percorso;
}

/// Modello o componente interno “PassoRelazione” usato esclusivamente da questo file.
class _PassoRelazione {
  const _PassoRelazione({
    required this.daTabella,
    required this.daCampo,
    required this.aTabella,
    required this.aCampo,
  });

  final String daTabella;
  final String daCampo;
  final String aTabella;
  final String aCampo;

  /// Gestisce l’operazione `toJson` specifica di questa pagina.
  Map<String, dynamic> toJson() => <String, dynamic>{
        'da_tabella': daTabella,
        'da_campo': daCampo,
        'a_tabella': aTabella,
        'a_campo': aCampo,
      };

  factory _PassoRelazione.fromJson(Map<String, dynamic> json) =>
      _PassoRelazione(
        daTabella: json['da_tabella']?.toString() ?? '',
        daCampo: json['da_campo']?.toString() ?? '',
        aTabella: json['a_tabella']?.toString() ?? '',
        aCampo: json['a_campo']?.toString() ?? '',
      );
}

List<_PassoRelazione>? _trovaPercorsoRelazioni(
  SchemaDatabase schema,
  String sorgente,
  String destinazione,
) {
  if (sorgente == destinazione) return const <_PassoRelazione>[];

  final adiacenze = <String, List<_PassoRelazione>>{};
  /// Aggiunge l’operazione `aggiungi` mantenendo separata la logica dalla UI.
  void aggiungi(_PassoRelazione passo) {
    adiacenze.putIfAbsent(passo.daTabella, () => <_PassoRelazione>[]).add(passo);
  }

  for (final tabella in schema.tabelle) {
    for (final campo in tabella.campi) {
      final relazione = campo.relazione;
      if (relazione == null) continue;
      aggiungi(
        _PassoRelazione(
          daTabella: tabella.nome,
          daCampo: campo.nome,
          aTabella: relazione.tabella,
          aCampo: relazione.colonna,
        ),
      );
      aggiungi(
        _PassoRelazione(
          daTabella: relazione.tabella,
          daCampo: relazione.colonna,
          aTabella: tabella.nome,
          aCampo: campo.nome,
        ),
      );
    }
  }

  final coda = <({String tabella, List<_PassoRelazione> percorso})>[
    (tabella: sorgente, percorso: const <_PassoRelazione>[]),
  ];
  final visitate = <String>{sorgente};

  while (coda.isNotEmpty) {
    final corrente = coda.removeAt(0);
    for (final passo in adiacenze[corrente.tabella] ?? const <_PassoRelazione>[]) {
      if (visitate.contains(passo.aTabella)) continue;
      final nuovoPercorso = <_PassoRelazione>[...corrente.percorso, passo];
      if (passo.aTabella == destinazione) return nuovoPercorso;
      visitate.add(passo.aTabella);
      coda.add((tabella: passo.aTabella, percorso: nuovoPercorso));
    }
  }

  return null;
}
