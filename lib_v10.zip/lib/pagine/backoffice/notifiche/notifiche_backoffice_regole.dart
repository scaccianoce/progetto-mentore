part of 'notifiche_backoffice_page.dart';

// ============================================================================
// REGOLE
// ============================================================================

/// Pagina dedicata a notifiche regole backoffice.
class NotificheRegoleBackofficePage extends StatefulWidget {
  const NotificheRegoleBackofficePage({super.key, required this.controller});

  final NotificheBackofficeController controller;

  @override
  State<NotificheRegoleBackofficePage> createState() =>
      _NotificheRegoleBackofficePageState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _NotificheRegoleBackofficePageState
    extends State<NotificheRegoleBackofficePage> {
  SchemaDatabase? _schema;
  List<Map<String, dynamic>> _regole = const [];
  bool _caricamento = true;
  String? _errore;

  /// Inizializza lo stato della pagina e avvia le operazioni iniziali necessarie.
  @override
  void initState() {
    super.initState();
    _carica();
  }

  /// Gestisce l’operazione interna “carica” della pagina.
  Future<void> _carica() async {
    setState(() {
      _caricamento = true;
      _errore = null;
    });
    try {
      final risultati = await Future.wait<dynamic>([
        widget.controller.caricaSchemaDatabase(),
        widget.controller.caricaRegole(),
      ]);
      if (!mounted) return;
      setState(() {
        _schema = risultati[0] as SchemaDatabase;
        _regole = (risultati[1] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(growable: false);
      });
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile caricare le regole.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _caricamento = false);
    }
  }

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Regole automatiche',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            IconButton(
              tooltip: 'Aggiorna',
              onPressed: _caricamento ? null : _carica,
              icon: const Icon(Icons.refresh),
            ),
            const SizedBox(width: 8),
            FilledButton.icon(
              onPressed: _schema == null ? null : () => _modifica(),
              icon: const Icon(Icons.add),
              label: const Text('Nuova regola'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_caricamento) const LinearProgressIndicator(),
        if (_errore != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(_errore!),
          ),
        Expanded(
          child: _regole.isEmpty && !_caricamento
              ? const Center(child: Text('Nessuna regola configurata.'))
              : ListView.separated(
                  itemCount: _regole.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final r = _regole[index];
                    return Card(
                      child: ListTile(
                        leading: Icon(
                          r['attiva'] == true
                              ? Icons.notifications_active_outlined
                              : Icons.notifications_off_outlined,
                        ),
                        title: Text(r['descrizione']?.toString() ?? r['codice'].toString()),
                        subtitle: Text(_descrizioneRegola(r)),
                        trailing: Wrap(
                          spacing: 4,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: <Widget>[
                            Switch.adaptive(
                              value: r['attiva'] == true,
                              onChanged: _caricamento
                                  ? null
                                  : (valore) => _impostaAttiva(r, valore),
                            ),
                            IconButton(
                              tooltip: 'Modifica',
                              onPressed: () => _modifica(r),
                              icon: const Icon(Icons.edit_outlined),
                            ),
                            IconButton(
                              tooltip: 'Elimina',
                              onPressed: () => _elimina(r),
                              icon: const Icon(Icons.delete_outline),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “descrizione regola” della pagina.
  String _descrizioneRegola(Map<String, dynamic> r) {
    final parti = <String>[
      r['tipo_attivazione']?.toString() ?? '',
      r['tabella']?.toString() ?? '',
    ];
    final campo = r['campo_data']?.toString();
    if (campo != null && campo.isNotEmpty) {
      final offset = (r['offset_giorni'] as num?)?.toInt() ?? 0;
      parti.add('$campo · ${offset >= 0 ? '+' : ''}$offset giorni');
    }
    final dataProgrammata = r['data_programmata']?.toString();
    if (dataProgrammata != null && dataProgrammata.isNotEmpty) {
      parti.add('invio $dataProgrammata');
    }
    parti.add('→ ${r['destinatari'] ?? ''}');
    return parti.where((v) => v.isNotEmpty).join(' · ');
  }

  /// Imposta attiva.
  Future<void> _impostaAttiva(
    Map<String, dynamic> regola,
    bool valore,
  ) async {
    final id = regola['id']?.toString();
    if (id == null || id.isEmpty) return;

    final precedente = regola['attiva'] == true;

    setState(() {
      regola['attiva'] = valore;
    });

    try {
      await widget.controller.impostaRegolaAttiva(id, valore);

      // Il trigger notifiche_regole_config_changed aggiorna automaticamente
      // la configurazione dei trigger sorgente nel database.
      await _carica();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        regola['attiva'] = precedente;
      });

      final eccezione = AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile ${valore ? 'attivare' : 'disattivare'} la regola.',
      );
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(eccezione.messaggio)));
    }
  }

  /// Gestisce l’operazione interna “modifica” della pagina.
  Future<void> _modifica([Map<String, dynamic>? regola]) async {
    final schema = _schema;
    if (schema == null) return;
    final salvata = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => _RegolaDialog(
        controller: widget.controller,
        schema: schema,
        regola: regola,
      ),
    );
    if (salvata == true) await _carica();
  }

  /// Gestisce l’operazione interna “elimina” della pagina.
  Future<void> _elimina(Map<String, dynamic> regola) async {
    final conferma = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Elimina regola'),
            content: Text('Eliminare “${regola['descrizione'] ?? regola['codice']}”?'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annulla'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Elimina'),
              ),
            ],
          ),
        ) ??
        false;
    if (!conferma) return;
    try {
      await widget.controller.eliminaRegola(regola['id']);
      await _carica();
    } catch (e) {
      if (!mounted) return;
      final eccezione = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile eliminare la regola.',
      );
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(eccezione.messaggio)));
    }
  }
}

