part of 'notifiche_backoffice_page.dart';

/// Modello o componente interno “DestinatariMessaggioDialog” usato esclusivamente da questo file.
class _DestinatariMessaggioDialog extends StatefulWidget {
  const _DestinatariMessaggioDialog({
    required this.controller,
    required this.messaggioId,
    required this.titolo,
  });

  final NotificheBackofficeController controller;
  final String messaggioId;
  final String titolo;

  @override
  State<_DestinatariMessaggioDialog> createState() =>
      _DestinatariMessaggioDialogState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _DestinatariMessaggioDialogState
    extends State<_DestinatariMessaggioDialog> {
  bool _caricamento = true;
  String? _errore;
  List<Map<String, dynamic>> _destinatari = const [];

  /// Inizializza lo stato della pagina e avvia le operazioni iniziali necessarie.
  @override
  void initState() {
    super.initState();
    _carica();
  }

  /// Gestisce l’operazione interna “carica” della pagina.
  Future<void> _carica() async {
    setState(() {
      _caricamento = true;
      _errore = null;
    });
    try {
      final destinatari =
          await widget.controller.caricaDestinatari(widget.messaggioId);
      if (!mounted) return;
      setState(() => _destinatari = destinatari);
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile caricare i destinatari.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _caricamento = false);
    }
  }

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Destinatari · ${widget.titolo}'),
      content: SizedBox(
        width: 850,
        height: 520,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (_caricamento) const LinearProgressIndicator(),
            if (_errore != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(_errore!),
              ),
            if (!_caricamento && _errore == null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text('${_destinatari.length} destinatari'),
              ),
            Expanded(
              child: _destinatari.isEmpty && !_caricamento
                  ? const Center(child: Text('Nessun destinatario.'))
                  : ListView.separated(
                      itemCount: _destinatari.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final d = _destinatari[index];
                        final nome = '${d['cognome'] ?? ''} ${d['nome'] ?? ''}'.trim();
                        final errore = d['errore']?.toString().trim();
                        return ListTile(
                          leading: CircleAvatar(child: Text('${index + 1}')),
                          title: Text(nome.isEmpty ? d['user_id']?.toString() ?? 'Utente' : nome),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              if ((d['email_unipa']?.toString() ?? '').isNotEmpty)
                                Text(d['email_unipa'].toString()),
                              Text(
                                'Stato: ${d['stato'] ?? ''}'
                                '${d['inviato_at'] == null ? '' : ' · inviato ${_formattaDataDb(d['inviato_at'])}'}'
                                '${d['letto_at'] == null ? '' : ' · letto ${_formattaDataDb(d['letto_at'])}'}',
                              ),
                              if (errore != null && errore.isNotEmpty)
                                Text('Errore: $errore'),
                            ],
                          ),
                          trailing: _iconaStato(d['stato']?.toString()),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        IconButton(
          tooltip: 'Aggiorna',
          onPressed: _caricamento ? null : _carica,
          icon: const Icon(Icons.refresh),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Chiudi'),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “icona stato” della pagina.
  Widget _iconaStato(String? stato) {
    return switch (stato) {
      'inviato' => const Icon(Icons.check_circle_outline),
      'letto' => const Icon(Icons.mark_email_read_outlined),
      'errore' => const Icon(Icons.error_outline),
      'escluso_inattivo' => const Icon(Icons.person_off_outlined),
      'senza_dispositivo' => const Icon(Icons.phonelink_erase_outlined),
      _ => const Icon(Icons.schedule_outlined),
    };
  }
}

