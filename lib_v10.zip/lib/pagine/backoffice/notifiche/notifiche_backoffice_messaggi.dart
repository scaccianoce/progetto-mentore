part of 'notifiche_backoffice_page.dart';

// ============================================================================
// MESSAGGI
// ============================================================================

/// Pagina dedicata a notifiche messaggi backoffice.
class NotificheMessaggiBackofficePage extends StatefulWidget {
  const NotificheMessaggiBackofficePage({super.key, required this.controller});

  final NotificheBackofficeController controller;

  @override
  State<NotificheMessaggiBackofficePage> createState() =>
      _NotificheMessaggiBackofficePageState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _NotificheMessaggiBackofficePageState
    extends State<NotificheMessaggiBackofficePage> {
  SchemaDatabase? _schema;
  List<Map<String, dynamic>> _messaggi = const [];
  bool _caricamento = true;
  String? _errore;

  /// Inizializza lo stato della pagina e avvia le operazioni iniziali necessarie.
  @override
  void initState() {
    super.initState();
    _carica();
  }

  /// Gestisce l’operazione interna “carica” della pagina.
  Future<void> _carica() async {
    setState(() {
      _caricamento = true;
      _errore = null;
    });
    try {
      final risultati = await Future.wait<dynamic>([
        widget.controller.caricaSchemaDatabase(),
        widget.controller.caricaMessaggi(),
      ]);
      if (!mounted) return;
      setState(() {
        _schema = risultati[0] as SchemaDatabase;
        _messaggi = (risultati[1] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(growable: false);
      });
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile caricare i messaggi.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _caricamento = false);
    }
  }

  /// Gestisce l’operazione interna “programmato modificabile” della pagina.
  bool _programmatoModificabile(Map<String, dynamic> messaggio) {
    return messaggio['stato']?.toString() == 'programmato' &&
        messaggio['inviata_at'] == null;
  }

  /// Gestisce l’operazione interna “ritentabile” della pagina.
  bool _ritentabile(Map<String, dynamic> messaggio) =>
      widget.controller.messaggioRitentabile(messaggio);

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Messaggi',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            IconButton(
              tooltip: 'Aggiorna',
              onPressed: _caricamento ? null : _carica,
              icon: const Icon(Icons.refresh),
            ),
            const SizedBox(width: 8),
            FilledButton.icon(
              onPressed: _schema == null ? null : _nuovoMessaggio,
              icon: const Icon(Icons.send_outlined),
              label: const Text('Nuova notifica'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_caricamento) const LinearProgressIndicator(),
        if (_errore != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(_errore!),
          ),
        Expanded(
          child: _messaggi.isEmpty && !_caricamento
              ? const Center(child: Text('Nessun messaggio.'))
              : ListView.separated(
                  itemCount: _messaggi.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final m = _messaggi[index];
                    final modificabile = _programmatoModificabile(m);
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.notifications_outlined),
                        title: Text(m['titolo']?.toString() ?? 'Notifica'),
                        subtitle: Text(
                          '${m['anno_accademico'] ?? ''} · ${m['destinatari'] ?? ''} · '
                          '${m['stato'] ?? ''}${m['programmata_per'] == null ? '' : ' · ${_formattaValoreData(m['programmata_per'])}'}',
                        ),
                        trailing: Wrap(
                          spacing: 2,
                          children: <Widget>[
                            IconButton(
                              tooltip: 'Stato destinatari',
                              onPressed: () => _mostraDestinatari(m),
                              icon: const Icon(Icons.people_outline),
                            ),
                            if (_ritentabile(m))
                              IconButton(
                                tooltip: 'Riprova invio',
                                onPressed: () => _ritentaInvio(m),
                                icon: const Icon(Icons.refresh_outlined),
                              ),
                            if (modificabile)
                              IconButton(
                                tooltip: 'Modifica notifica programmata',
                                onPressed: () => _modificaMessaggio(m),
                                icon: const Icon(Icons.edit_outlined),
                              ),
                            if (modificabile)
                              IconButton(
                                tooltip: 'Elimina notifica programmata',
                                onPressed: () => _eliminaMessaggio(m),
                                icon: const Icon(Icons.delete_outline),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  /// Ritenta invio.
  Future<void> _ritentaInvio(Map<String, dynamic> messaggio) async {
    final id = messaggio['id']?.toString();
    if (id == null || id.isEmpty) return;

    try {
      await widget.controller.ritentaInvio(id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nuovo tentativo di invio completato.')),
      );
      await _carica();
    } catch (e) {
      if (!mounted) return;
      final eccezione = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Nuovo tentativo non riuscito.',
      );
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(eccezione.messaggio)));
    }
  }

  /// Avvia la creazione di messaggio.
  Future<void> _nuovoMessaggio() async {
    final schema = _schema;
    if (schema == null) return;
    final salvato = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => _MessaggioManualeDialog(
        controller: widget.controller,
        schema: schema,
      ),
    );
    if (salvato == true) await _carica();
  }

  /// Gestisce la modifica di messaggio.
  Future<void> _modificaMessaggio(Map<String, dynamic> messaggio) async {
    final schema = _schema;
    if (schema == null || !_programmatoModificabile(messaggio)) return;
    final salvato = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => _MessaggioManualeDialog(
        controller: widget.controller,
        schema: schema,
        messaggioEsistente: messaggio,
      ),
    );
    if (salvato == true) await _carica();
  }

  /// Elimina messaggio.
  Future<void> _eliminaMessaggio(Map<String, dynamic> messaggio) async {
    if (!_programmatoModificabile(messaggio)) return;
    final id = messaggio['id']?.toString();
    if (id == null || id.isEmpty) return;

    final conferma = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Elimina notifica programmata'),
            content: Text(
              'Vuoi eliminare definitivamente "${messaggio['titolo'] ?? 'questa notifica'}"?\n\n'
              'Saranno eliminati anche i destinatari già associati alla notifica.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annulla'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Elimina'),
              ),
            ],
          ),
        ) ??
        false;
    if (!conferma) return;

    try {
      await widget.controller.eliminaMessaggio(id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Notifica programmata eliminata.')),
      );
      await _carica();
    } catch (e) {
      if (!mounted) return;
      final eccezione = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Eliminazione non riuscita.',
      );
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(eccezione.messaggio)));
    }
  }

  /// Mostra destinatari.
  Future<void> _mostraDestinatari(Map<String, dynamic> messaggio) async {
    final id = messaggio['id']?.toString();
    if (id == null || id.isEmpty) return;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => _DestinatariMessaggioDialog(
        controller: widget.controller,
        messaggioId: id,
        titolo: messaggio['titolo']?.toString() ?? 'Notifica',
      ),
    );
  }

  /// Gestisce l’operazione interna “formatta valore data” della pagina.
  String _formattaValoreData(Object? valore) {
    if (valore == null) return '';
    final data = DateTime.tryParse(valore.toString());
    if (data == null) return valore.toString();
    return formattaDataOra(data, valoreAssente: '', locale: true);
  }
}

