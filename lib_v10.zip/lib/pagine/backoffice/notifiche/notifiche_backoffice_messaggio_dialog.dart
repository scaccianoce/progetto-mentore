part of 'notifiche_backoffice_page.dart';

/// Modello o componente interno “MessaggioManualeDialog” usato esclusivamente da questo file.
class _MessaggioManualeDialog extends StatefulWidget {
  const _MessaggioManualeDialog({
    required this.controller,
    required this.schema,
    this.messaggioEsistente,
  });

  final NotificheBackofficeController controller;
  final SchemaDatabase schema;
  final Map<String, dynamic>? messaggioEsistente;

  @override
  State<_MessaggioManualeDialog> createState() => _MessaggioManualeDialogState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _MessaggioManualeDialogState extends State<_MessaggioManualeDialog> {
  final _titolo = TextEditingController();
  final _messaggio = TextEditingController();
  String? _destinatari;
  String? _riferimentoId;
  String? _anno;
  DateTime? _programmataPer;
  List<Map<String, dynamic>> _opzioni = const [];
  final Set<String> _utentiManuali = <String>{};
  bool _caricamentoOpzioni = false;
  bool _salvataggio = false;
  String? _errore;

  bool get _modifica => widget.messaggioEsistente != null;

  List<String> get _tipiDestinatari => widget.schema
          .tabella('notifiche_messaggi')
          ?.campo('destinatari')
          ?.valoriScelta ??
      const <String>[];

  /// Inizializza lo stato della pagina e avvia le operazioni iniziali necessarie.
  @override
  void initState() {
    super.initState();
    final esistente = widget.messaggioEsistente;
    if (esistente != null) {
      _titolo.text = esistente['titolo']?.toString() ?? '';
      _messaggio.text = esistente['messaggio']?.toString() ?? '';
      _destinatari = esistente['destinatari']?.toString();
      _programmataPer = DateTime.tryParse(
        esistente['programmata_per']?.toString() ?? '',
      )?.toLocal();

      final config = _configurazione(esistente['destinatari_configurazione']);
      _riferimentoId =
          config['evento_id']?.toString() ?? config['house_of_mentore_id']?.toString();
      _anno = config['anno_accademico']?.toString();
      final utenti = config['user_ids'];
      if (utenti is List) {
        _utentiManuali.addAll(utenti.map((e) => e.toString()));
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _caricaOpzioni(_destinatari);
      });
    }
  }

  /// Gestisce l’operazione interna “configurazione” della pagina.
  Map<String, dynamic> _configurazione(Object? valore) {
    if (valore is Map) return Map<String, dynamic>.from(valore);
    if (valore is String && valore.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(valore);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      } catch (_) {}
    }
    return <String, dynamic>{};
  }

  /// Rilascia listener e controller associati allo stato della pagina.
  @override
  void dispose() {
    _titolo.dispose();
    _messaggio.dispose();
    super.dispose();
  }

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_modifica ? 'Modifica notifica programmata' : 'Nuova notifica manuale'),
      content: SizedBox(
        width: 700,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _titolo,
                decoration: const InputDecoration(labelText: 'Titolo'),
              ),
              TextField(
                controller: _messaggio,
                minLines: 4,
                maxLines: null,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(labelText: 'Messaggio'),
              ),
              DropdownButtonFormField<String>(
                initialValue: _tipiDestinatari.contains(_destinatari) ? _destinatari : null,
                decoration: const InputDecoration(labelText: 'Destinatari'),
                items: _tipiDestinatari
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) async {
                  setState(() {
                    _destinatari = v;
                    _riferimentoId = null;
                    _anno = null;
                    _utentiManuali.clear();
                    _opzioni = const [];
                  });
                  await _caricaOpzioni(v);
                },
              ),
              if (_caricamentoOpzioni) const LinearProgressIndicator(),
              if (_destinatari == 'iscritti_evento') _dropdownRiferimento('Evento'),
              if (_destinatari == 'iscritti_house_of_mentore')
                _dropdownRiferimento('House of Mentore'),
              if (_destinatari == 'anno_accademico') _dropdownAnno(),
              if (_destinatari == 'manuale') _selezioneManuale(),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Invio'),
                subtitle: Text(
                  _programmataPer == null
                      ? 'Immediato'
                      : 'Programmato: ${formattaDataOra(_programmataPer!)}',
                ),
                trailing: Wrap(
                  children: <Widget>[
                    if (_programmataPer != null)
                      IconButton(
                        tooltip: 'Invio immediato',
                        onPressed: () => setState(() => _programmataPer = null),
                        icon: const Icon(Icons.clear),
                      ),
                    IconButton(
                      tooltip: 'Programma data e ora',
                      onPressed: _scegliDataOra,
                      icon: const Icon(Icons.schedule),
                    ),
                  ],
                ),
              ),
              if (_errore != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(_errore!),
                ),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: _salvataggio ? null : () => Navigator.pop(context, false),
          child: const Text('Annulla'),
        ),
        FilledButton(
          onPressed: _salvataggio ? null : _salva,
          child: Text(
            _modifica
                ? (_programmataPer == null ? 'Salva e invia' : 'Salva modifiche')
                : (_programmataPer == null ? 'Crea e invia' : 'Programma'),
          ),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “dropdown riferimento” della pagina.
  Widget _dropdownRiferimento(String label) {
    return DropdownButtonFormField<String>(
      initialValue: _opzioni.any((r) => r['id']?.toString() == _riferimentoId)
          ? _riferimentoId
          : null,
      decoration: InputDecoration(labelText: label),
      items: _opzioni
          .map(
            (r) => DropdownMenuItem<String>(
              value: r['id'].toString(),
              child: Text(_etichettaRecord(r)),
            ),
          )
          .toList(),
      onChanged: (v) => setState(() => _riferimentoId = v),
    );
  }

  /// Gestisce l’operazione interna “dropdown anno” della pagina.
  Widget _dropdownAnno() {
    return DropdownButtonFormField<String>(
      initialValue: _opzioni.any((r) => r['codice']?.toString() == _anno) ? _anno : null,
      decoration: const InputDecoration(labelText: 'Anno accademico'),
      items: _opzioni
          .map(
            (r) => DropdownMenuItem<String>(
              value: r['codice'].toString(),
              child: Text(r['codice'].toString()),
            ),
          )
          .toList(),
      onChanged: (v) => setState(() => _anno = v),
    );
  }

  /// Gestisce l’operazione interna “selezione manuale” della pagina.
  Widget _selezioneManuale() {
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text('Persone selezionate'),
      subtitle: Text('${_utentiManuali.length} selezionate'),
      children: _opzioni
          .map(
            (r) => CheckboxListTile(
              dense: true,
              value: _utentiManuali.contains(r['user_id']?.toString()),
              title: Text('${r['cognome'] ?? ''} ${r['nome'] ?? ''}'.trim()),
              subtitle: Text(r['email_unipa']?.toString() ?? ''),
              onChanged: (v) {
                final id = r['user_id']?.toString();
                if (id == null) return;
                setState(() {
                  if (v == true) {
                    _utentiManuali.add(id);
                  } else {
                    _utentiManuali.remove(id);
                  }
                });
              },
            ),
          )
          .toList(growable: false),
    );
  }

  /// Carica opzioni.
  Future<void> _caricaOpzioni(String? tipo) async {
    if (tipo == null) return;
    setState(() => _caricamentoOpzioni = true);
    try {
      final opzioni = await widget.controller.caricaOpzioniDestinatari(tipo);
      if (!mounted) return;
      setState(() => _opzioni = opzioni);
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile caricare le opzioni.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _caricamentoOpzioni = false);
    }
  }

  /// Gestisce la selezione di data ora.
  Future<void> _scegliDataOra() async {
    final now = DateTime.now();
    final data = await showDatePicker(
      context: context,
      initialDate: _programmataPer ?? now,
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 3650)),
    );
    if (data == null || !mounted) return;
    final ora = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_programmataPer ?? now),
    );
    if (ora == null) return;
    setState(() {
      _programmataPer = DateTime(data.year, data.month, data.day, ora.hour, ora.minute);
    });
  }

  /// Gestisce l’operazione interna “salva” della pagina.
  Future<void> _salva() async {
    final titolo = _titolo.text.trim();
    final messaggio = _messaggio.text.trim();
    if (titolo.isEmpty || messaggio.isEmpty || _destinatari == null) {
      setState(() => _errore = 'Titolo, messaggio e destinatari sono obbligatori.');
      return;
    }
    if ((_destinatari == 'iscritti_evento' ||
            _destinatari == 'iscritti_house_of_mentore') &&
        _riferimentoId == null) {
      setState(() => _errore = 'Seleziona il riferimento.');
      return;
    }
    if (_destinatari == 'anno_accademico' && _anno == null) {
      setState(() => _errore = 'Seleziona l’anno accademico.');
      return;
    }
    if (_destinatari == 'manuale' && _utentiManuali.isEmpty) {
      setState(() => _errore = 'Seleziona almeno una persona attiva.');
      return;
    }

    final config = <String, dynamic>{};
    switch (_destinatari) {
      case 'iscritti_evento':
        config['evento_id'] = _riferimentoId;
        break;
      case 'iscritti_house_of_mentore':
        config['house_of_mentore_id'] = _riferimentoId;
        break;
      case 'anno_accademico':
        config['anno_accademico'] = _anno;
        break;
      case 'manuale':
        config['user_ids'] = _utentiManuali.toList();
        break;
    }

    setState(() {
      _salvataggio = true;
      _errore = null;
    });
    try {
      final payload = <String, dynamic>{
        'titolo': titolo,
        'messaggio': messaggio,
        'destinatari': _destinatari,
        'destinatari_configurazione': jsonDecode(jsonEncode(config)),
        'programmata_per': _programmataPer?.toUtc().toIso8601String(),
        'stato': _programmataPer == null ? 'da_inviare' : 'programmato',
      };

      String? messaggioIdEsistente;

      if (_modifica) {
        final id = widget.messaggioEsistente!['id']?.toString();

        if (id == null || id.isEmpty) {
          throw StateError(
            'ID della notifica programmata non disponibile.',
          );
        }

        messaggioIdEsistente = id;
      }

      if (_modifica &&
          (messaggioIdEsistente == null || messaggioIdEsistente.isEmpty)) {
        throw StateError('ID della notifica programmata non disponibile.');
      }

      final numeroDestinatari = await widget.controller.salvaMessaggio(
        messaggioId: messaggioIdEsistente,
        payload: payload,
        programmato: _programmataPer != null,
      );

      final dettaglioInvio = _programmataPer == null
          ? ' · invio push completato'
          : ' · invio programmato';

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${_modifica ? 'Notifica aggiornata' : 'Notifica creata'} · '
            '$numeroDestinatari destinatari attivi$dettaglioInvio.',
          ),
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _errore = AppErrorMapper.converti(
          e,
          messaggioGenerico: _modifica
              ? 'Modifica della notifica non riuscita.'
              : 'Creazione della notifica non riuscita.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _salvataggio = false);
    }
  }

  /// Gestisce l’operazione interna “etichetta record” della pagina.
  String _etichettaRecord(Map<String, dynamic> r) {
    final nomeTabella = switch (_destinatari) {
      'iscritti_evento' => 'eventi',
      'iscritti_house_of_mentore' => 'house_of_mentore',
      _ => null,
    };
    if (nomeTabella != null) {
      final tabella = widget.schema.tabella(nomeTabella);
      final campoDescrittivo = tabella?.nomeCampoDescrittivo;
      if (campoDescrittivo != null) {
        final valore = r[campoDescrittivo]?.toString().trim();
        if (valore != null && valore.isNotEmpty) return valore;
      }
    }
    return r['id']?.toString() ?? 'Record';
  }
}

/// Gestisce l’operazione interna “formatta data db” della pagina.
String _formattaDataDb(Object? valore) {
  return formattaDataOra(
    valore,
    valoreAssente: '',
    mantieniValoreNonValido: true,
    locale: true,
  );
}

