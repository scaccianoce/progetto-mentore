part of 'insegnamenti_backoffice_page.dart';

/// Modello o componente interno “DialogTeamMentoraggio” usato esclusivamente da questo file.
class _DialogTeamMentoraggio extends StatefulWidget {
  const _DialogTeamMentoraggio({
    required this.controller,
    required this.mentoraggioId,
    required this.onAggiornato,
  });

  final InsegnamentiBackofficeController controller;
  final String mentoraggioId;
  final Future<void> Function() onAggiornato;

  @override
  State<_DialogTeamMentoraggio> createState() => _DialogTeamMentoraggioState();
}

/// Stato interno della pagina; coordina rendering e interazioni della UI.
class _DialogTeamMentoraggioState extends State<_DialogTeamMentoraggio> {
  String? _personaId;
  String? _tipo;
  bool _salvataggio = false;

  List<Map<String, dynamic>> get _assegnazioni => widget.controller.assegnazioni
      .where((a) => a['mentoraggio_id']?.toString() == widget.mentoraggioId)
      .toList(growable: false);

  /// Costruisce l’interfaccia grafica di questo componente.
  @override
  Widget build(BuildContext context) {
    final tipi = widget.controller.tipiMentoreDisponibili.isEmpty
        ? const <String>['mentor', 'senior']
        : widget.controller.tipiMentoreDisponibili;
    _tipo ??= tipi.firstOrNull;

    return AlertDialog(
      title: const Text('Mentori / senior'),
      content: SizedBox(
        width: 760,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Non è previsto alcun limite numerico per mentor o senior. '
              'È impedita soltanto la duplicazione della stessa persona con lo stesso ruolo.',
            ),
            const SizedBox(height: 12),
            if (_assegnazioni.isEmpty)
              const Text('Nessun membro assegnato.')
            else
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final a in _assegnazioni)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          widget.controller.etichettaPersona(
                            a['mentore_id']?.toString(),
                          ),
                        ),
                        subtitle: Text(a['tipo']?.toString() ?? '—'),
                        trailing: IconButton(
                          tooltip: 'Rimuovi',
                          icon: const Icon(Icons.delete_outline),
                          onPressed: _salvataggio ? null : () => _rimuovi(a),
                        ),
                      ),
                  ],
                ),
              ),
            const Divider(),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: DropdownButtonFormField<String>(
                    initialValue: _personaId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Persona (email)',
                      border: OutlineInputBorder(),
                    ),
                    items: widget.controller.partecipanti
                        .map(
                          (p) => DropdownMenuItem<String>(
                            value: p['user_id']?.toString(),
                            child: Text(
                              widget.controller.etichettaPersona(
                                p['user_id']?.toString(),
                              ),
                            ),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: _salvataggio
                        ? null
                        : (v) => setState(() => _personaId = v),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _tipo,
                    decoration: const InputDecoration(
                      labelText: 'Ruolo',
                      border: OutlineInputBorder(),
                    ),
                    items: tipi
                        .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                        .toList(growable: false),
                    onChanged: _salvataggio
                        ? null
                        : (v) => setState(() => _tipo = v),
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton.icon(
                  onPressed: _salvataggio || _personaId == null || _tipo == null
                      ? null
                      : _aggiungi,
                  icon: const Icon(Icons.add),
                  label: const Text('Aggiungi'),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _salvataggio ? null : () => Navigator.pop(context),
          child: const Text('Chiudi'),
        ),
      ],
    );
  }

  /// Gestisce l’operazione interna “aggiungi” della pagina.
  Future<void> _aggiungi() async {
    setState(() => _salvataggio = true);
    final errore = await widget.controller.aggiungiAssegnazione(
      widget.mentoraggioId,
      _personaId!,
      _tipo!,
    );
    if (!mounted) return;
    if (errore != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore)));
    } else {
      _personaId = null;
      await widget.onAggiornato();
    }
    if (mounted) setState(() => _salvataggio = false);
  }

  /// Gestisce l’operazione interna “rimuovi” della pagina.
  Future<void> _rimuovi(Map<String, dynamic> riga) async {
    setState(() => _salvataggio = true);
    final errore = await widget.controller.eliminaAssegnazione(riga);
    if (!mounted) return;
    if (errore != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore)));
    } else {
      await widget.onAggiornato();
    }
    if (mounted) setState(() => _salvataggio = false);
  }
}

extension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

/// Mostra errore.
void _mostraErrore(BuildContext context, String? errore) {
  if (!context.mounted) return;

  ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(errore ?? 'Operazione completata.')));
}
