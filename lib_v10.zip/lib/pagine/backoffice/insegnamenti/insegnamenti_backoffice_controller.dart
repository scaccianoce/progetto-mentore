import 'dart:typed_data';

import '../../../dati/repository.dart';
import '../../../ui/schema_dinamico.dart';

/// Controller dedicato alla relativa pagina di backoffice.
/// La UI non accede direttamente al repository condiviso.
class InsegnamentiBackofficeController extends BackofficeRepository {
  InsegnamentiBackofficeController(super.sessione)
      : _mentoraggi = MentoraggiRepository(RepositoryComune());

  final MentoraggiRepository _mentoraggi;

  /// Carica o sostituisce la scheda di sintesi di un mentoraggio.
  Future<String> salvaSchedaSintesi({
    required String mentoraggioId,
    required String annoAccademico,
    required String estensione,
    required Uint8List bytes,
    required String contentType,
    String? percorsoPrecedente,
  }) => _mentoraggi.salvaSchedaSintesi(
        mentoraggioId: mentoraggioId,
        annoAccademico: annoAccademico,
        estensione: estensione,
        bytes: bytes,
        contentType: contentType,
        percorsoPrecedente: percorsoPrecedente,
      );

  /// Restituisce un URL temporaneo per aprire la scheda di sintesi.
  Future<String> urlSchedaSintesi(String valore) =>
      _mentoraggi.urlSchedaSintesi(valore);

  /// Carica lo schema usato esclusivamente per la visualizzazione locale.
  Future<SchemaDatabase> caricaSchemaDatabase() => _mentoraggi.schemaDatabase();
}

