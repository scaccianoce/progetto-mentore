import '../../../dati/repository.dart';
import '../../../ui/schema_dinamico.dart';

/// Coordina l'accesso dati della pagina Database di backoffice.
///
/// La UI descrive e presenta le tabelle, mentre tutte le operazioni remote
/// vengono eseguite attraverso [RepositoryComune].
class DatabaseBackofficeController {
  DatabaseBackofficeController({RepositoryComune? repository})
      : _repository = repository ?? RepositoryComune();

  final RepositoryComune _repository;

  /// Ricarica lo schema del database ignorando l'eventuale cache locale.
  Future<SchemaDatabase> caricaSchema() =>
      _repository.schemaDatabase(forzaAggiornamento: true);

  /// Restituisce i nomi delle tabelle base, se la RPC è disponibile.
  Future<Set<String>?> caricaTabelleBase() async {
    try {
      final risposta = await _repository.rpc('app_database_base_tables');
      if (risposta is! List) return null;
      return risposta
          .map((e) => e is Map ? e['name'] : e)
          .where((e) => e != null)
          .map((e) => e.toString())
          .toSet();
    } catch (_) {
      return null;
    }
  }

  /// Carica al massimo 500 record dalla tabella indicata.
  Future<List<Map<String, dynamic>>> caricaTabella(String tabella) =>
      _repository.elenco(tabella: tabella, limite: 500);

  /// Inserisce un record in una tabella generica.
  Future<void> inserisci(String tabella, Map<String, dynamic> valori) async {
    await _repository.inserisci(tabella: tabella, valori: valori);
  }

  /// Aggiorna un record usando i valori della chiave primaria come filtri.
  Future<void> aggiorna(
    String tabella,
    Map<String, dynamic> valori,
    Map<String, dynamic> chiave,
  ) async {
    await _repository.aggiorna(
      tabella: tabella,
      valori: valori,
      filtri: [
        for (final e in chiave.entries) FiltroDb(e.key, e.value as Object),
      ],
    );
  }

  /// Elimina un record usando i valori della chiave primaria come filtri.
  Future<void> elimina(String tabella, Map<String, dynamic> chiave) =>
      _repository.elimina(
        tabella: tabella,
        filtri: [
          for (final e in chiave.entries) FiltroDb(e.key, e.value as Object),
        ],
      );

  /// Invoca la funzione amministrativa per gli utenti Auth.
  Future<Map<String, dynamic>> invocaUserAdmin(
    Map<String, dynamic> body,
  ) async {
    final data = await _repository.invocaFunzioneMappa(
      'backoffice-user-admin',
      body: body,
    );
    return data;
  }
}
