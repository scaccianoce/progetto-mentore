import '../../../dati/repository.dart';
import '../../../ui/schema_dinamico.dart';
import '../../../supporto/conversioni_dati.dart';
/// Controller dedicato alla pagina.
/// In questa prima fase strutturale resta intenzionalmente minimale: la grafica
/// e la logica esistente della pagina non vengono alterate.
class ControlloPartecipantiBackofficeController {
  ControlloPartecipantiBackofficeController({RepositoryComune? repository})
      : _repository = repository ?? RepositoryComune();

  final RepositoryComune _repository;

  /// Carica l’operazione `caricaDatiAnno` mantenendo separata la logica dalla UI.
  Future<BackofficeDatiAnno> caricaDatiAnno(String anno) =>
      BackofficeDatiAnno.carica(anno);

  /// Carica gli anni disponibili, ordinati dal più recente.
  Future<List<Map<String, dynamic>>> caricaAnni() => _repository.elenco(
        tabella: 'anni_accademici',
        colonne: 'codice, corrente',
        ordinamenti: const <OrdineDb>[OrdineDb('codice', crescente: false)],
      );

  /// Aggiorna un insegnamento dal controllo partecipanti.
  Future<void> aggiornaInsegnamento(
    String id,
    Map<String, dynamic> valori,
  ) async {
    await _repository.aggiorna(
      tabella: 'insegnamenti',
      valori: valori,
      filtri: <FiltroDb>[FiltroDb('id', id)],
    );
  }

  /// Aggiorna il mentoraggio tramite la RPC di backoffice.
  Future<void> aggiornaMentoraggio(
    String id,
    Map<String, dynamic> valori,
  ) async {
    await _repository.rpc(
      'mentoraggio_aggiorna_backoffice',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': id,
        'p_valori': valori,
      },
    );
  }

  /// Carica assegnazioni, persone e stato attivo per la gestione del team.
  Future<List<dynamic>> caricaDatiTeam(String mentoraggioId) =>
      Future.wait<dynamic>([
        _repository.elenco(
          tabella: 'mentoraggio_mentori',
          filtri: <FiltroDb>[FiltroDb('mentoraggio_id', mentoraggioId)],
        ),
        _repository.elenco(
          tabella: 'anagrafica',
          ordinamenti: const <OrdineDb>[OrdineDb('email_unipa')],
        ),
        _repository.elenco(
          tabella: 'anagrafica_riservata',
          colonne: 'user_id, attivo',
        ),
      ]);

  /// Carica l’operazione `caricaSchemaDatabase` mantenendo separata la logica dalla UI.
  Future<SchemaDatabase> caricaSchemaDatabase() => _repository.schemaDatabase();

  /// Rimuove una specifica assegnazione dal team di mentoraggio.
  Future<void> rimuoviAssegnazione({
    required String mentoraggioId,
    required Object mentoreId,
    required Object tipo,
  }) => _repository.elimina(
        tabella: 'mentoraggio_mentori',
        filtri: <FiltroDb>[
          FiltroDb('mentoraggio_id', mentoraggioId),
          FiltroDb('mentore_id', mentoreId),
          FiltroDb('tipo', tipo),
        ],
      );

  /// Inserisce una nuova assegnazione nel team di mentoraggio.
  Future<void> aggiungiAssegnazione(Map<String, dynamic> valori) async {
    await _repository.inserisci(
      tabella: 'mentoraggio_mentori',
      valori: valori,
    );
  }
}

// ============================================================================
// DATI ANNUALI CONDIVISI DALLA PAGINA
// ============================================================================

/// Pacchetto coerente di dati relativi a un singolo anno accademico.
///
/// La relazione annuale parte SEMPRE da `mentoraggi.anno_accademico`.
/// `insegnamenti` non contiene piu l'anno accademico: gli insegnamenti
/// vengono recuperati attraverso `mentoraggi.insegnamento_id`.
class BackofficeDatiAnno {
  const BackofficeDatiAnno({
    required this.anno,
    required this.mentoraggi,
    required this.insegnamenti,
    required this.assegnazioni,
    required this.eventi,
    required this.partecipazioniEventi,
    required this.partecipazioniAnnuali,
    required this.houseOfMentore,
    required this.opzioniHouseOfMentore,
    required this.partecipazioniHouseOfMentore,
    required this.anagrafiche,
    required this.riservati,
    required this.ruoli,
  });

  final String anno;
  final List<Map<String, dynamic>> mentoraggi;
  final List<Map<String, dynamic>> insegnamenti;
  final List<Map<String, dynamic>> assegnazioni;
  final List<Map<String, dynamic>> eventi;
  final List<Map<String, dynamic>> partecipazioniEventi;
  final List<Map<String, dynamic>> partecipazioniAnnuali;
  final List<Map<String, dynamic>> houseOfMentore;
  final List<Map<String, dynamic>> opzioniHouseOfMentore;
  final List<Map<String, dynamic>> partecipazioniHouseOfMentore;
  final List<Map<String, dynamic>> anagrafiche;
  final List<Map<String, dynamic>> riservati;
  final List<Map<String, dynamic>> ruoli;

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  static Future<BackofficeDatiAnno> carica(
    String anno, {
    bool caricaAnagrafiche = true,
  }) async {
    final repository = RepositoryComune();

    // L'anno accademico appartiene al mentoraggio, non all'insegnamento.
    final filtroAnno = <FiltroDb>[FiltroDb('anno_accademico', anno)];
    final risultatiPrincipali = await Future.wait<dynamic>([
      repository.elenco(tabella: 'mentoraggi', filtri: filtroAnno),
      repository.elenco(tabella: 'eventi', filtri: filtroAnno),
      repository.elenco(tabella: 'house_of_mentore', filtri: filtroAnno),
      repository.elenco(tabella: 'partecipazioni_annuali', filtri: filtroAnno),
    ]);

    final mentoraggi = mappeDa(risultatiPrincipali[0]);
    final eventi = mappeDa(risultatiPrincipali[1]);
    final hom = mappeDa(risultatiPrincipali[2]);
    final partecipazioniAnnuali = mappeDa(risultatiPrincipali[3]);

    final insegnamentoIds = idsUnivoci(mentoraggi, 'insegnamento_id');
    final mentoraggioIds = idsUnivoci(mentoraggi, 'id');
    final eventoIds = idsUnivoci(eventi, 'id');
    final homIds = idsUnivoci(hom, 'id');

    final risultatiCollegati = await Future.wait<dynamic>([
      insegnamentoIds.isEmpty
          ? Future.value(<Map<String, dynamic>>[])
          : repository.elenco(
              tabella: 'insegnamenti',
              filtriIn: <FiltroInDb>[FiltroInDb('id', insegnamentoIds)],
            ),
      mentoraggioIds.isEmpty
          ? Future.value(<Map<String, dynamic>>[])
          : repository.elenco(
              tabella: 'mentoraggio_mentori',
              filtriIn: <FiltroInDb>[
                FiltroInDb('mentoraggio_id', mentoraggioIds),
              ],
            ),
      eventoIds.isEmpty
          ? Future.value(<Map<String, dynamic>>[])
          : repository.elenco(
              tabella: 'partecipazioni_eventi',
              filtriIn: <FiltroInDb>[FiltroInDb('evento_id', eventoIds)],
            ),
      homIds.isEmpty
          ? Future.value(<Map<String, dynamic>>[])
          : repository.elenco(
              tabella: 'house_of_mentore_opzioni',
              filtriIn: <FiltroInDb>[FiltroInDb('evento_id', homIds)],
            ),
      homIds.isEmpty
          ? Future.value(<Map<String, dynamic>>[])
          : repository.elenco(
              tabella: 'partecipazioni_house_of_mentore',
              filtriIn: <FiltroInDb>[FiltroInDb('evento_id', homIds)],
            ),
    ]);

    final insegnamenti = mappeDa(risultatiCollegati[0]);
    final assegnazioni = mappeDa(risultatiCollegati[1]);
    final partecipazioniEventi = mappeDa(risultatiCollegati[2]);
    final opzioniHom = mappeDa(risultatiCollegati[3]);
    final partecipazioniHom = mappeDa(risultatiCollegati[4]);

    if (!caricaAnagrafiche) {
      return BackofficeDatiAnno(
        anno: anno,
        mentoraggi: mentoraggi,
        insegnamenti: insegnamenti,
        assegnazioni: assegnazioni,
        eventi: eventi,
        partecipazioniEventi: partecipazioniEventi,
        partecipazioniAnnuali: partecipazioniAnnuali,
        houseOfMentore: hom,
        opzioniHouseOfMentore: opzioniHom,
        partecipazioniHouseOfMentore: partecipazioniHom,
        anagrafiche: const [],
        riservati: const [],
        ruoli: const [],
      );
    }

    final partecipanteIds = <String>{
      ...insegnamenti
          .map((r) => r['docente_id']?.toString())
          .whereType<String>(),
      ...assegnazioni
          .map((r) => r['mentore_id']?.toString())
          .whereType<String>(),
      ...partecipazioniEventi
          .map((r) => r['partecipante_id']?.toString())
          .whereType<String>(),
      ...partecipazioniHom
          .map((r) => r['partecipante_id']?.toString())
          .whereType<String>(),
      ...partecipazioniAnnuali
          .map((r) => r['user_id']?.toString())
          .whereType<String>(),
    }..removeWhere((v) => v.isEmpty || v == 'null');

    final ids = partecipanteIds.toList();
    final risultatiPersone = ids.isEmpty
        ? <dynamic>[
            <Map<String, dynamic>>[],
            <Map<String, dynamic>>[],
            <Map<String, dynamic>>[],
          ]
        : await Future.wait<dynamic>([
            repository.elenco(
              tabella: 'anagrafica',
              filtriIn: <FiltroInDb>[FiltroInDb('user_id', ids)],
            ),
            repository.elenco(
              tabella: 'anagrafica_riservata',
              filtriIn: <FiltroInDb>[FiltroInDb('user_id', ids)],
            ),
            repository.elenco(
              tabella: 'user_roles',
              filtriIn: <FiltroInDb>[FiltroInDb('user_id', ids)],
            ),
          ]);

    return BackofficeDatiAnno(
      anno: anno,
      mentoraggi: mentoraggi,
      insegnamenti: insegnamenti,
      assegnazioni: assegnazioni,
      eventi: eventi,
      partecipazioniEventi: partecipazioniEventi,
      partecipazioniAnnuali: partecipazioniAnnuali,
      houseOfMentore: hom,
      opzioniHouseOfMentore: opzioniHom,
      partecipazioniHouseOfMentore: partecipazioniHom,
      anagrafiche: mappeDa(risultatiPersone[0]),
      riservati: mappeDa(risultatiPersone[1]),
      ruoli: mappeDa(risultatiPersone[2]),
    );
  }

  Map<String, List<Map<String, dynamic>>> esportazione({
    required List<Map<String, dynamic>> rigaAnno,
  }) =>
      <String, List<Map<String, dynamic>>>{
        'anni_accademici': rigaAnno,
        'anagrafica': anagrafiche,
        'anagrafica_riservata': riservati,
        'user_roles': ruoli,
        'insegnamenti': insegnamenti,
        'mentoraggi': mentoraggi,
        'mentoraggio_mentori': assegnazioni,
        'eventi': eventi,
        'partecipazioni_eventi': partecipazioniEventi,
        'partecipazioni_annuali': partecipazioniAnnuali,
        'house_of_mentore': houseOfMentore,
        'house_of_mentore_opzioni': opzioniHouseOfMentore,
        'partecipazioni_house_of_mentore': partecipazioniHouseOfMentore,
      };
}
