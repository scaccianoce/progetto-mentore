import 'package:flutter/foundation.dart';

import '../../app/app_core.dart';
import '../../app/app_session_controller.dart';
import '../../supporto/notifiche_automatiche_service.dart';
import '../../dati/repository.dart';
import '../../ui/schema_dinamico.dart';

/// Controller di eventi; coordina stato e logica applicativa.
class EventiController extends ChangeNotifier {
  EventiController(this.sessione, {EventiRepository? repository})
      : _repository = repository ?? EventiRepository();

  static const String bucketLocandine = 'locandine';
  static const int dimensioneMassimaLocandina = 300 * 1024;

  final SessioneController sessione;
  final EventiRepository _repository;

  /// Carica lo schema usato dalla visualizzazione locale della pagina Eventi.
  Future<SchemaDatabase> caricaSchemaDatabase() => _repository.schemaDatabase();

  final List<Map<String, dynamic>> eventi = <Map<String, dynamic>>[];
  final List<String> anniAccademici = <String>[];

  final Map<String, Map<String, dynamic>> iscrizioni =
      <String, Map<String, dynamic>>{};

  /// Iscritti visibili solo a owner/organizer, raggruppati per evento.
  final Map<String, List<Map<String, dynamic>>> iscrittiPerEvento =
      <String, List<Map<String, dynamic>>>{};

  final Map<String, Map<String, dynamic>> anagraficaPerUserId =
      <String, Map<String, dynamic>>{};

  /// evento_id -> questionario_id per i questionari interni di gradimento.
  final Map<String, String> questionarioPerEvento = <String, String>{};

  /// "questionario_id|user_id" -> data invio.
  final Map<String, DateTime> compilazioni = <String, DateTime>{};

  bool caricamento = false;
  String? errore;
  String? eventoSelezionatoId;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  Map<String, dynamic>? get eventoSelezionato {
    for (final evento in eventi) {
      if (evento['id']?.toString() == eventoSelezionatoId) return evento;
    }
    return eventi.isEmpty ? null : eventi.first;
  }

  /// Verifica l’operazione `iscritto` mantenendo separata la logica dalla UI.
  bool iscritto(String eventoId) => iscrizioni.containsKey(eventoId);

  /// Verifica l’operazione `presente` mantenendo separata la logica dalla UI.
  bool presente(String eventoId) =>
      iscrizioni[eventoId]?['presente'] == true;

  /// Verifica l’operazione `haQuestionario` mantenendo separata la logica dalla UI.
  bool haQuestionario(String eventoId) =>
      questionarioPerEvento.containsKey(eventoId);

  /// Gestisce l’operazione `questionarioCompilato` specifica di questa pagina.
  bool questionarioCompilato(
    String eventoId, {
    String? partecipanteId,
  }) {
    final questionarioId = questionarioPerEvento[eventoId];
    if (questionarioId == null) return false;

    final userId = partecipanteId ?? _repository.userIdCorrente;
    if (userId == null) return false;

    return compilazioni.containsKey('$questionarioId|$userId');
  }

  /// Gestisce l’operazione `dataCompilazione` specifica di questa pagina.
  DateTime? dataCompilazione(
    String eventoId,
    String partecipanteId,
  ) {
    final questionarioId = questionarioPerEvento[eventoId];
    if (questionarioId == null) return null;
    return compilazioni['$questionarioId|$partecipanteId'];
  }

  List<Map<String, dynamic>> iscritti(String eventoId) =>
      iscrittiPerEvento[eventoId] ?? const <Map<String, dynamic>>[];

  /// Restituisce l’operazione `nomePartecipante` mantenendo separata la logica dalla UI.
  String nomePartecipante(String userId) {
    final persona = anagraficaPerUserId[userId];
    if (persona == null) return userId;

    final cognome = persona['cognome']?.toString().trim() ?? '';
    final nome = persona['nome']?.toString().trim() ?? '';
    final completo = '$cognome $nome'.trim();

    return completo.isEmpty ? userId : completo;
  }

  /// Carica i dati necessari e aggiorna lo stato esposto alla pagina.
  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      final userId = _repository.userIdCorrente;
      if (userId == null) {
        throw const AppException('Sessione non valida.');
      }

      final risultati = await Future.wait<dynamic>(<Future<dynamic>>[
        _repository.eventi(includiNonAttivi: puoGestire),
        _repository.partecipazioni(userId: userId),
        _repository.anniAccademici(),
        _repository.questionariApertiInterni(),
        _repository.compilazioni(userId: userId),
      ]);

      eventi
        ..clear()
        ..addAll((risultati[0] as List).cast<Map<String, dynamic>>());

      iscrizioni.clear();
      for (final riga
          in (risultati[1] as List).cast<Map<String, dynamic>>()) {
        iscrizioni[riga['evento_id'].toString()] = riga;
      }

      anniAccademici
        ..clear()
        ..addAll((risultati[2] as List).cast<String>());

      questionarioPerEvento.clear();
      for (final riga
          in (risultati[3] as List).cast<Map<String, dynamic>>()) {
        final eventoId = riga['evento_id']?.toString();
        final questionarioId = riga['id']?.toString();

        if (eventoId != null &&
            eventoId.isNotEmpty &&
            questionarioId != null &&
            questionarioId.isNotEmpty) {
          questionarioPerEvento[eventoId] = questionarioId;
        }
      }

      compilazioni.clear();
      _aggiungiCompilazioni(
        (risultati[4] as List).cast<Map<String, dynamic>>(),
      );

      iscrittiPerEvento.clear();
      anagraficaPerUserId.clear();

      if (puoGestire) {
        final risultatiGestione =
            await Future.wait<dynamic>(<Future<dynamic>>[
          _repository.partecipazioni(),
          _repository.anagraficheEssenziali(),
          _repository.compilazioni(),
        ]);

        for (final riga
            in (risultatiGestione[0] as List).cast<Map<String, dynamic>>()) {
          final eventoId = riga['evento_id']?.toString() ?? '';
          if (eventoId.isEmpty) continue;

          iscrittiPerEvento
              .putIfAbsent(
                eventoId,
                () => <Map<String, dynamic>>[],
              )
              .add(riga);
        }

        for (final persona
            in (risultatiGestione[1] as List).cast<Map<String, dynamic>>()) {
          final id = persona['user_id']?.toString() ?? '';
          if (id.isNotEmpty) {
            anagraficaPerUserId[id] = persona;
          }
        }

        _aggiungiCompilazioni(
          (risultatiGestione[2] as List).cast<Map<String, dynamic>>(),
        );
      }

      if (eventoSelezionatoId == null && eventi.isNotEmpty) {
        eventoSelezionatoId = eventi.first['id'].toString();
      }
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare gli eventi.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  /// Gestisce l’operazione interna “aggiungi compilazioni” della pagina.
  void _aggiungiCompilazioni(
    List<Map<String, dynamic>> righe,
  ) {
    for (final riga in righe) {
      final questionarioId = riga['questionario_id']?.toString() ?? '';
      final userId = riga['user_id']?.toString() ?? '';

      if (questionarioId.isEmpty || userId.isEmpty) continue;

      final data = DateTime.tryParse(
        riga['inviato_at']?.toString() ?? '',
      );

      compilazioni['$questionarioId|$userId'] =
          data ?? DateTime.now();
    }
  }

  /// Aggiorna il record selezionato nella pagina.
  void seleziona(Map<String, dynamic> evento) {
    eventoSelezionatoId = evento['id'].toString();
    notifyListeners();
  }

  /// Gestisce l’operazione `iscrizioniAperte` specifica di questa pagina.
  bool iscrizioniAperte(Map<String, dynamic> evento) {
    final oggi = DateTime.now();
    final data = DateTime(oggi.year, oggi.month, oggi.day);

    final apertura = DateTime.tryParse(
      evento['data_apertura_iscrizioni']?.toString() ?? '',
    );

    final chiusura = DateTime.tryParse(
      evento['data_chiusura_iscrizioni']?.toString() ?? '',
    );

    return (apertura == null || !data.isBefore(apertura)) &&
        (chiusura == null || !data.isAfter(chiusura));
  }

  /// Aggiorna l’operazione `cambiaIscrizione` mantenendo separata la logica dalla UI.
  Future<String?> cambiaIscrizione(
    Map<String, dynamic> evento,
  ) async {
    try {
      final userId = _repository.userIdCorrente;

      if (userId == null) {
        throw const AppException('Sessione non valida.');
      }

      final eventoId = evento['id'].toString();

      if (iscritto(eventoId)) {
        await _repository.annullaIscrizione(eventoId: eventoId, userId: userId);
      } else {
        await _repository.iscrivi(eventoId: eventoId, userId: userId);
      }

      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile aggiornare l’iscrizione.',
      ).messaggio;
    }
  }

  /// Solo owner/organizer possono impostare la presenza.
  ///
  /// Lo stato di compilazione del questionario NON viene modificato:
  /// deriva automaticamente da questionari_compilazioni.
  Future<String?> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) async {
    try {
      if (!puoGestire) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      await _repository.aggiornaPresenza(
        eventoId: eventoId,
        partecipanteId: partecipanteId,
        presente: presente,
      );

      if (presente && haQuestionario(eventoId)) {
        final evento = eventi.cast<Map<String, dynamic>?>().firstWhere(
              (riga) => riga?['id']?.toString() == eventoId,
              orElse: () => null,
            );
        final titoloEvento =
            evento?['titolo']?.toString().trim() ?? 'evento';

        try {
          await NotificheAutomaticheService.inviaUtenti(
            userIds: <String>[partecipanteId],
            titolo: 'Questionario di gradimento disponibile',
            messaggio:
                'La tua presenza a "$titoloEvento" è stata confermata. '
                'Puoi ora compilare il questionario di gradimento.',
          );
        } catch (e) {
          debugPrint('Notifica questionario evento non inviata: $e');
        }
      }

      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile aggiornare la presenza.',
      ).messaggio;
    }
  }

  /// Valida e salva i dati richiesti dalla pagina.
  Future<String?> salva({
    String? id,
    required Map<String, dynamic> dati,
    bool aggiornaQuestionario = false,
    String? templateQuestionarioId,
    Uint8List? locandinaBytes,
    String? locandinaNomeFile,
    bool rimuoviLocandina = false,
  }) async {
    String? eventoCreatoId;

    try {
      if (!puoGestire) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      final anno =
          dati['anno_accademico']?.toString().trim() ?? '';

      if (anno.isEmpty) {
        throw const AppException(
          'Devi selezionare l’anno accademico.',
        );
      }

      final titolo =
          dati['titolo']?.toString().trim() ?? '';

      if (titolo.isEmpty) {
        throw const AppException(
          'Il titolo dell’evento è obbligatorio.',
        );
      }

      if (locandinaBytes != null &&
          locandinaBytes.lengthInBytes > dimensioneMassimaLocandina) {
        throw const AppException(
          'La locandina supera il limite massimo di 300 KB.',
        );
      }

      String? locandinaPrecedente;
      if (id != null && (locandinaBytes != null || rimuoviLocandina)) {
        final eventoEsistente = await _repository.evento(id, colonne: 'locandina_url');

        locandinaPrecedente =
            eventoEsistente?['locandina_url']?.toString();
      }

      String eventoId;

      if (id == null) {
        eventoId = await _repository.creaEvento(<String, dynamic>{
          ...dati,
          'attiva': dati['attiva'] ?? true,
        });
        eventoCreatoId = eventoId;
      } else {
        eventoId = id;

        await _repository.aggiornaEvento(id, dati);
      }

      if (rimuoviLocandina) {
        await _rimuoviLocandinaStorage(locandinaPrecedente);

        await _repository.aggiornaEvento(eventoId, <String, dynamic>{'locandina_url': null});
      } else if (locandinaBytes != null && locandinaNomeFile != null) {
        final nuovaUrl = await _caricaLocandina(
          eventoId: eventoId,
          bytes: locandinaBytes,
          nomeFile: locandinaNomeFile,
          urlPrecedente: locandinaPrecedente,
        );

        await _repository.aggiornaEvento(eventoId, <String, dynamic>{'locandina_url': nuovaUrl});
      }

      if (aggiornaQuestionario) {
        final esistente = await _repository.questionarioEvento(eventoId);

        if (esistente == null && templateQuestionarioId != null) {
          await _repository.creaQuestionarioEvento(
            eventoId: eventoId,
            templateId: templateQuestionarioId,
            titoloEvento: titolo,
          );
        } else if (esistente != null) {
          final questionarioId = esistente['id'].toString();
          final templateCorrente =
              esistente['template_id']?.toString();

          final haCompilazioni = await _repository.questionarioHaCompilazioni(questionarioId);

          if (templateQuestionarioId == null) {
            if (haCompilazioni) {
              throw const AppException(
                'Il questionario non può essere rimosso perché esistono già compilazioni.',
              );
            }

            await _repository.eliminaQuestionario(questionarioId);
          } else if (templateCorrente != templateQuestionarioId) {
            if (haCompilazioni) {
              throw const AppException(
                'Il template non può essere cambiato perché esistono già compilazioni.',
              );
            }

            await _repository.aggiornaQuestionario(
              questionarioId,
              titoloEvento: titolo,
              templateId: templateQuestionarioId,
            );
          } else {
            await _repository.aggiornaQuestionario(
              questionarioId,
              titoloEvento: titolo,
            );
          }
        }
      }

      if (id == null) {
        try {
          await NotificheAutomaticheService.inviaAnnoAccademico(
            annoAccademico: anno,
            titolo: 'Nuovo evento',
            messaggio: 'È stato pubblicato l’evento "$titolo". '
                'Apri la pagina Eventi per consultare i dettagli e iscriverti.',
          );
        } catch (e) {
          debugPrint('Notifica nuovo evento non inviata: $e');
        }
      }

      await carica();
      return null;
    } catch (e) {
      // Se fallisce la creazione del questionario dopo aver creato un nuovo
      // evento, proviamo a rimuovere il nuovo evento per non lasciare dati
      // parziali.
      if (eventoCreatoId != null) {
        try {
          await _repository.eliminaEvento(eventoCreatoId);
        } catch (_) {
          // best effort
        }
      }

      return AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile salvare l’evento.',
      ).messaggio;
    }
  }

  /// Elimina il record indicato e aggiorna lo stato locale.
  Future<String?> elimina(String id) async {
    try {
      if (!puoGestire) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      final prima = await _repository.evento(id, colonne: 'id, locandina_url');

      if (prima == null) {
        throw const AppException(
          'Evento non trovato.',
        );
      }

      final locandinaUrl =
          prima['locandina_url']?.toString();

      final eliminato = await _repository.eliminaEvento(id);

      if (!eliminato) {
        throw const AppException(
          'L’evento non è stato eliminato. Verifica i permessi RLS di cancellazione sulla tabella eventi.',
        );
      }

      // Il file Storage non è una FK PostgreSQL: lo rimuoviamo separatamente.
      // Se la pulizia Storage fallisce, l'evento resta comunque eliminato.
      try {
        await _rimuoviLocandinaStorage(locandinaUrl);
      } catch (e) {
        debugPrint('Pulizia locandina Storage non riuscita: $e');
      }

      eventoSelezionatoId = null;
      await carica();

      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico:
            'Impossibile eliminare l’evento.',
      ).messaggio;
    }
  }

  /// Carica locandina.
  Future<String> _caricaLocandina({
    required String eventoId,
    required Uint8List bytes,
    required String nomeFile,
    String? urlPrecedente,
  }) async {
    if (bytes.lengthInBytes > dimensioneMassimaLocandina) {
      throw const AppException(
        'La locandina supera il limite massimo di 300 KB.',
      );
    }

    final estensione =
        nomeFile.split('.').last.trim().toLowerCase();

    if (!<String>{'jpg', 'jpeg', 'png'}.contains(estensione)) {
      throw const AppException(
        'Formato locandina non valido. Sono ammessi JPG, JPEG e PNG.',
      );
    }

    final mimeType = estensione == 'png'
        ? 'image/png'
        : 'image/jpeg';

    final estensioneNormalizzata =
        estensione == 'jpeg' ? 'jpg' : estensione;

    final path =
        'eventi/$eventoId/locandina.$estensioneNormalizzata';

    final vecchioPath =
        _storagePathDaUrl(urlPrecedente);

    if (vecchioPath != null && vecchioPath != path) {
      try {
        await _repository.rimuoviFileStorage(
          bucket: bucketLocandine,
          percorso: vecchioPath,
        );
      } catch (_) {
        // Non blocchiamo la sostituzione se il vecchio file non esiste più.
      }
    }

    return _repository.caricaFilePubblico(
      bucket: bucketLocandine,
      percorso: path,
      bytes: bytes,
      contentType: mimeType,
    );
  }

  /// Gestisce l’operazione interna “rimuovi locandina storage” della pagina.
  Future<void> _rimuoviLocandinaStorage(
    String? url,
  ) async {
    final path = _storagePathDaUrl(url);
    if (path == null) return;

    await _repository.rimuoviFileStorage(
      bucket: bucketLocandine,
      percorso: path,
    );
  }

  /// Gestisce l’operazione `storagePathDaUrl` specifica di questa pagina.
  String? _storagePathDaUrl(String? url) {
    if (url == null || url.trim().isEmpty) return null;

    final marker =
        '/storage/v1/object/public/$bucketLocandine/';
    final indice = url.indexOf(marker);

    if (indice < 0) {
      // URL esterno/legacy (ad es. Google Drive): non è un oggetto
      // del bucket locandine e quindi non va rimosso da Storage.
      return null;
    }

    final path = url.substring(indice + marker.length);
    return Uri.decodeComponent(path);
  }

}
