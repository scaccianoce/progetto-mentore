import 'package:flutter/material.dart';

import '../../app/app_session_controller.dart';

/// Controller di login; coordina stato e logica applicativa.
class LoginController extends ChangeNotifier {
  LoginController(this.sessione) {
    sessione.addListener(_aggiorna);
  }

  final SessioneController sessione;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool _passwordVisibile = false;

  bool get passwordVisibile => _passwordVisibile;
  bool get caricamento => sessione.caricamento;
  String? get errore => sessione.errore;

  /// Aggiorna l’operazione `cambiaVisibilitaPassword` mantenendo separata la logica dalla UI.
  void cambiaVisibilitaPassword() {
    _passwordVisibile = !_passwordVisibile;
    notifyListeners();
  }

  /// Gestisce l’operazione `accedi` specifica di questa pagina.
  Future<void> accedi() {
    return sessione.accedi(
      email: emailController.text,
      password: passwordController.text,
    );
  }

  /// Aggiorna lo stato locale della pagina.
  void _aggiorna() => notifyListeners();

  /// Rilascia listener e controller associati allo stato della pagina.
  @override
  void dispose() {
    sessione.removeListener(_aggiorna);
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}
