import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_core.dart';
import '../dati/repository.dart';
import '../supporto/notifiche_push_service.dart';

enum AppRole {
  participant,
  organizer,
  owner;

  bool get puoAmministrare => this == organizer || this == owner;

  bool get puoGestireSicurezza => this == owner;

  static AppRole daDatabase(Object? valore) {
    return switch (valore) {
      'participant' => AppRole.participant,
      'organizer' => AppRole.organizer,
      'owner' => AppRole.owner,
      _ => throw const AppException(
        'Il ruolo dell’utente non è valido o non è stato assegnato.',
      ),
    };
  }
}

/// Componente `SessioneController`: incapsula responsabilità specifiche del relativo modulo.
class SessioneController extends ChangeNotifier
    implements AutorizzazioniBackoffice {
  SessioneController({SupabaseClient? client, SessioneRepository? repository})
      : _repository = repository ?? SessioneRepository(client: client);

  final SessioneRepository _repository;

  StreamSubscription<AuthState>? _authSubscription;
  User? _utente;
  AppRole? _ruolo;
  String? _errore;
  bool _caricamento = false;
  bool _inizializzato = false;
  int _versioneCaricamento = 0;

  User? get utente => _utente;
  AppRole? get ruolo => _ruolo;
  String? get errore => _errore;
  bool get caricamento => _caricamento;
  bool get autenticato => _utente != null;
  bool get pronto => _utente == null || _ruolo != null;

  @override
  bool get repositorySoloOwner => _ruolo == AppRole.owner;

  @override
  bool get repositoryPuoAmministrare => _ruolo?.puoAmministrare ?? false;

  @override
  String? get repositoryUserId => _utente?.id;

  Future<void> inizializza() async {
    if (_inizializzato) {
      return;
    }
    _inizializzato = true;

    _authSubscription = _repository.cambiAutenticazione.listen((
      AuthState stato,
    ) {
      unawaited(_caricaUtente(stato.session?.user));
    });

    await _caricaUtente(_repository.utenteCorrente);
  }

  Future<void> accedi({required String email, required String password}) async {
    _impostaCaricamento(true);
    _errore = null;

    try {
      final AuthResponse risposta = await _repository.accedi(
        email: email,
        password: password,
      );
      await _caricaUtente(risposta.user);
    } catch (errore) {
      _errore = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Accesso non riuscito. Controlla email e password.',
      ).messaggio;
    } finally {
      _impostaCaricamento(false);
    }
  }

  Future<void> esci() async {
    _impostaCaricamento(true);
    _errore = null;

    try {
      await NotifichePushService.instance.disattivaDispositivoCorrente();
      await _repository.esci();
      await _caricaUtente(null);
    } catch (errore) {
      _errore = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Disconnessione non riuscita. Riprova.',
      ).messaggio;
    } finally {
      _impostaCaricamento(false);
    }
  }

  Future<void> ricaricaRuolo() => _caricaUtente(_repository.utenteCorrente);

  void pulisciErrore() {
    if (_errore == null) {
      return;
    }
    _errore = null;
    notifyListeners();
  }

  Future<void> _caricaUtente(User? nuovoUtente) async {
    final int versione = ++_versioneCaricamento;
    _utente = nuovoUtente;
    _ruolo = null;
    _errore = null;

    if (nuovoUtente == null) {
      _caricamento = false;
      notifyListeners();
      return;
    }

    _caricamento = true;
    notifyListeners();

    try {
      final Map<String, dynamic>? riga = await _repository.ruoloUtente(nuovoUtente.id);

      if (versione != _versioneCaricamento) {
        return;
      }

      if (riga == null) {
        throw const AppException(
          'A questo utente non è stato assegnato un ruolo.',
        );
      }

      _ruolo = AppRole.daDatabase(riga['role']);
      unawaited(_precaricaSchemaDatabase());
    } catch (errore) {
      if (versione != _versioneCaricamento) {
        return;
      }
      _errore = AppErrorMapper.converti(
        errore,
        messaggioGenerico: 'Impossibile caricare il ruolo dell’utente.',
      ).messaggio;
    } finally {
      if (versione == _versioneCaricamento) {
        _caricamento = false;
        notifyListeners();
      }
    }
  }

  void _impostaCaricamento(bool valore) {
    if (_caricamento == valore) {
      return;
    }
    _caricamento = valore;
    notifyListeners();
  }

  Future<void> _precaricaSchemaDatabase() async {
    try {
      await _repository.schemaDatabase();
    } catch (_) {
      // Le pagine mantengono il fallback locale se i metadati non sono
      // temporaneamente disponibili; l'accesso dell'utente non viene bloccato.
    }
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }
}
