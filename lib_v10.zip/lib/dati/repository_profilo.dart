import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Operazioni Supabase dell'area Profilo.
class ProfiloRepository {
  ProfiloRepository({SupabaseClient? client})
    : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() =>
      RepositoryComune(client: _client).schemaDatabase();

  Future<Map<String, dynamic>?> profiloCorrente() async {
    final userId = userIdCorrente;
    if (userId == null) return null;
    final raw = await _client
        .from('anagrafica')
        .select()
        .eq('user_id', userId)
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<List<Map<String, dynamic>>> ssd() async {
    final List<dynamic> raw = await _client
        .from('ssd')
        .select('cod_ssd, gsd, area')
        .order('cod_ssd');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw
        .map((e) => (e as Map)['codice']?.toString())
        .whereType<String>()
        .toSet()
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> statoPartecipazioneAnnuale() async {
    final raw = await _client.rpc('partecipazione_annuale_stato');
    return raw is Map ? Map<String, dynamic>.from(raw) : null;
  }

  /// Restituisce lo storico delle partecipazioni dell'utente corrente.
  Future<List<Map<String, dynamic>>> partecipazioniAnnuali() async {
    if (userIdCorrente == null) return const <Map<String, dynamic>>[];
    final dynamic risposta = await _client.rpc(
      'partecipazioni_annuali_proprie',
    );
    final List<dynamic> raw = risposta is List ? risposta : const <dynamic>[];
    return raw
        .map((riga) => Map<String, dynamic>.from(riga as Map))
        .toList(growable: false);
  }

  Future<bool> puoModificareCorrente() async {
    final raw = await _client.rpc(
      'puo_modificare_corrente',
      params: const <String, dynamic>{'p_ambito': 'anagrafica'},
    );
    return raw == true;
  }

  Future<Map<String, dynamic>> rispondiPartecipazione(bool partecipa) async {
    final raw = await _client.rpc(
      'partecipazione_annuale_rispondi',
      params: <String, dynamic>{'p_partecipa': partecipa},
    );
    return Map<String, dynamic>.from(raw as Map);
  }

  Future<void> aggiornaPartecipazioneAnnuale({
    required String anno,
    required Map<String, dynamic> valori,
  }) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione assente.');
    await _client
        .from('partecipazioni_annuali')
        .update(valori)
        .eq('user_id', userId)
        .eq('anno_accademico', anno);
  }

  Future<void> cambiaPassword(String nuovaPassword) async {
    await _client.auth.updateUser(UserAttributes(password: nuovaPassword));
  }

  Future<void> richiediModifica() async {
    await _client.rpc(
      'richiedi_abilitazione',
      params: const <String, dynamic>{'p_ambito': 'anagrafica'},
    );
  }

  Future<Map<String, dynamic>?> aggiornaProfilo(
    Map<String, dynamic> valori,
  ) async {
    final userId = userIdCorrente;
    if (userId == null) return null;
    final raw = await _client
        .from('anagrafica')
        .update(valori)
        .eq('user_id', userId)
        .select()
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }
}
