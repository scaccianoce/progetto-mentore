/// Punto di accesso unico al livello dati dell'app.
///
/// Storicamente tutti i repository vivevano in questo unico file. Per
/// facilitarne la manutenzione sono stati divisi per dominio in file
/// separati (`repository_*.dart`); questo file li riesporta tutti così che
/// il resto del progetto possa continuare a scrivere semplicemente:
///
///   import '.../dati/repository.dart';
///
/// senza dover conoscere in quale file specifico vive ciascuna classe.
library;

export 'repository_base.dart';
export 'repository_mentoraggi.dart';
export 'repository_insegnamenti.dart';
export 'repository_backoffice.dart';
export 'repository_notifiche.dart';
export 'repository_profilo.dart';
export 'repository_contatti.dart';
export 'repository_eventi.dart';
export 'repository_house_of_mentore.dart';
export 'repository_risorse_mentoring.dart';
export 'repository_questionari.dart';
export 'repository_sessione.dart';
