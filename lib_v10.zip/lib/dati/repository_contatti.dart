import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Operazioni Supabase della pagina Contatti.
class ContattiRepository {
  ContattiRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  Future<List<Map<String, dynamic>>> contattiPubblici({
    required String colonne,
  }) async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select(colonne)
        .order('cognome', ascending: true)
        .order('nome', ascending: true);
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();
}
