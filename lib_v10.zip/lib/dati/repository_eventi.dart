import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Operazioni Supabase della pagina Eventi.
class EventiRepository {
  EventiRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();

  Future<List<Map<String, dynamic>>> eventi({required bool includiNonAttivi}) async {
    dynamic query = _client.from('eventi').select(
      'id, titolo, anno_accademico, luogo, data_evento, tipologia, '
      'descrizione, modalita, relatori, moderatori, note_organizzative, '
      'locandina_url, data_apertura_iscrizioni, data_chiusura_iscrizioni, '
      'attiva, created_at',
    );
    if (!includiNonAttivi) query = query.eq('attiva', true);
    final List<dynamic> raw = await query.order('data_evento', ascending: false);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> partecipazioni({String? userId}) async {
    dynamic query = _client.from('partecipazioni_eventi').select(
      'evento_id, partecipante_id, data_iscrizione, presente',
    );
    if (userId != null) query = query.eq('partecipante_id', userId);
    if (userId == null) query = query.order('data_iscrizione', ascending: true);
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw.map((e) => (e as Map)['codice'].toString()).toList();
  }

  Future<List<Map<String, dynamic>>> questionariApertiInterni() async {
    final List<dynamic> raw = await _client
        .from('questionari')
        .select('id, evento_id')
        .eq('provider', 'interno')
        .eq('aperto', true);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> compilazioni({String? userId}) async {
    dynamic query = _client
        .from('questionari_compilazioni')
        .select('questionario_id, user_id, inviato_at');
    if (userId != null) query = query.eq('user_id', userId);
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> anagraficheEssenziali() async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select('user_id, nome, cognome');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> iscrivi({required String eventoId, required String userId}) async {
    await _client.from('partecipazioni_eventi').insert(<String, dynamic>{
      'evento_id': eventoId,
      'partecipante_id': userId,
    });
  }

  Future<void> annullaIscrizione({
    required String eventoId,
    required String userId,
  }) async {
    await _client
        .from('partecipazioni_eventi')
        .delete()
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId);
  }

  Future<void> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) async {
    await _client
        .from('partecipazioni_eventi')
        .update(<String, dynamic>{'presente': presente})
        .eq('evento_id', eventoId)
        .eq('partecipante_id', partecipanteId);
  }

  Future<Map<String, dynamic>?> evento(String id, {String colonne = '*'}) async {
    final raw = await _client.from('eventi').select(colonne).eq('id', id).maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<String> creaEvento(Map<String, dynamic> valori) async {
    final raw = await _client
        .from('eventi')
        .insert(valori)
        .select('id')
        .single();
    return (raw as Map)['id'].toString();
  }

  Future<void> aggiornaEvento(String id, Map<String, dynamic> valori) async {
    await _client.from('eventi').update(valori).eq('id', id);
  }

  Future<bool> eliminaEvento(String id) async {
    final raw = await _client
        .from('eventi')
        .delete()
        .eq('id', id)
        .select('id')
        .maybeSingle();
    return raw != null;
  }

  Future<Map<String, dynamic>?> questionarioEvento(String eventoId) async {
    final raw = await _client
        .from('questionari')
        .select('id, template_id')
        .eq('provider', 'interno')
        .eq('evento_id', eventoId)
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<bool> questionarioHaCompilazioni(String questionarioId) async {
    final List<dynamic> raw = await _client
        .from('questionari_compilazioni')
        .select('id')
        .eq('questionario_id', questionarioId)
        .limit(1);
    return raw.isNotEmpty;
  }

  Future<void> creaQuestionarioEvento({
    required String eventoId,
    required String templateId,
    required String titoloEvento,
  }) async {
    await _client.from('questionari').insert(<String, dynamic>{
      'template_id': templateId,
      'titolo': 'Gradimento - $titoloEvento',
      'provider': 'interno',
      'evento_id': eventoId,
      'aperto': true,
      'created_by': userIdCorrente,
    });
  }

  Future<void> eliminaQuestionario(String id) async {
    await _client.from('questionari').delete().eq('id', id);
  }

  Future<void> aggiornaQuestionario(
    String id, {
    required String titoloEvento,
    String? templateId,
  }) async {
    await _client.from('questionari').update(<String, dynamic>{
      'template_id': ?templateId,
      'titolo': 'Gradimento - $titoloEvento',
    }).eq('id', id);
  }

  Future<void> rimuoviFileStorage({
    required String bucket,
    required String percorso,
  }) async {
    await _client.storage.from(bucket).remove(<String>[percorso]);
  }

  Future<String> caricaFilePubblico({
    required String bucket,
    required String percorso,
    required Uint8List bytes,
    required String contentType,
  }) async {
    await _client.storage.from(bucket).uploadBinary(
      percorso,
      bytes,
      fileOptions: FileOptions(
        cacheControl: '3600',
        upsert: true,
        contentType: contentType,
      ),
    );
    return _client.storage.from(bucket).getPublicUrl(percorso);
  }
}
