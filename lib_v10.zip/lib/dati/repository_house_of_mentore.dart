import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Operazioni Supabase della pagina House of Mentore.
class HouseOfMentoreRepository {
  HouseOfMentoreRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();

  Future<List<Map<String, dynamic>>> eventi() async {
    final List<dynamic> raw = await _client
        .from('house_of_mentore')
        .select(
          'id, titolo, descrizione, anno_accademico, data_evento, luogo, '
          'locandina_url, iscrizioni_aperte, created_at, updated_at',
        )
        .order('data_evento', ascending: false, nullsFirst: false);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> opzioni() async {
    final List<dynamic> raw = await _client
        .from('house_of_mentore_opzioni')
        .select('id, evento_id, descrizione, ordine_visualizzazione')
        .order('ordine_visualizzazione');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> partecipazioni({String? userId}) async {
    dynamic query = _client.from('partecipazioni_house_of_mentore').select(
      userId == null
          ? 'evento_id, partecipante_id, opzione_id, data_iscrizione, presente'
          : 'evento_id, partecipante_id, opzione_id, data_iscrizione',
    );
    if (userId != null) {
      query = query.eq('partecipante_id', userId);
    } else {
      query = query.order('data_iscrizione', ascending: true);
    }
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw.map((e) => (e as Map)['codice'].toString()).toList();
  }

  Future<List<Map<String, dynamic>>> anagraficheEssenziali() async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select('user_id, nome, cognome');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) async {
    await _client
        .from('partecipazioni_house_of_mentore')
        .update(<String, dynamic>{'presente': presente})
        .eq('evento_id', eventoId)
        .eq('partecipante_id', partecipanteId);
  }

  Future<void> salvaEvento({
    String? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('house_of_mentore').insert(valori);
    } else {
      await _client.from('house_of_mentore').update(valori).eq('id', id);
    }
  }

  Future<void> eliminaEvento(String id) async {
    await _client.from('house_of_mentore').delete().eq('id', id);
  }

  Future<void> salvaOpzione({
    String? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('house_of_mentore_opzioni').insert(valori);
    } else {
      await _client.from('house_of_mentore_opzioni').update(valori).eq('id', id);
    }
  }

  Future<void> eliminaOpzione(String id) async {
    await _client.from('house_of_mentore_opzioni').delete().eq('id', id);
  }

  Future<void> scegliOpzione({
    required String eventoId,
    required String opzioneId,
  }) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione non valida.');
    final esistente = await _client
        .from('partecipazioni_house_of_mentore')
        .select('evento_id')
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId)
        .maybeSingle();
    if (esistente == null) {
      await _client.from('partecipazioni_house_of_mentore').insert(
        <String, dynamic>{
          'evento_id': eventoId,
          'partecipante_id': userId,
          'opzione_id': opzioneId,
        },
      );
    } else {
      await _client
          .from('partecipazioni_house_of_mentore')
          .update(<String, dynamic>{'opzione_id': opzioneId})
          .eq('evento_id', eventoId)
          .eq('partecipante_id', userId);
    }
  }

  Future<void> cancellaIscrizione(String eventoId) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione non valida.');
    await _client
        .from('partecipazioni_house_of_mentore')
        .delete()
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId);
  }
}
