import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'repository_base.dart';

/// Operazioni Supabase per la libreria delle risorse di mentoring.
class RisorseMentoringRepository {
  RisorseMentoringRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;
  static const String bucket = 'risorse-mentoring';

  String? get userIdCorrente => _client.auth.currentUser?.id;

  /// Carica risorse attive e anni accademici disponibili.
  Future<List<dynamic>> caricaDati() => Future.wait<dynamic>([
        _client
            .from('risorse_mentoring')
            .select()
            .eq('attivo', true)
            .order('categoria')
            .order('ordine')
            .order('titolo'),
        _client
            .from('anni_accademici')
            .select('codice')
            .order('codice', ascending: false),
      ]);

  /// Carica un file nello Storage e crea il relativo record.
  Future<void> creaRisorsa({
    required Uint8List bytes,
    required String path,
    required String nomeFile,
    required String titolo,
    required String categoria,
    String? descrizione,
    String? annoAccademico,
    required String userId,
  }) async {
    await _client.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: false),
        );
    try {
      await _client.from('risorse_mentoring').insert({
        'titolo': titolo.trim(),
        'descrizione': descrizione == null || descrizione.trim().isEmpty
            ? null
            : descrizione.trim(),
        'categoria': categoria,
        'anno_accademico': annoAccademico == null || annoAccademico.isEmpty
            ? null
            : annoAccademico,
        'storage_path': path,
        'nome_file': nomeFile,
        'dimensione_bytes': bytes.lengthInBytes,
        'uploaded_by': userId,
        'attivo': true,
      });
    } catch (_) {
      try {
        await _client.storage.from(bucket).remove([path]);
      } catch (_) {}
      rethrow;
    }
  }

  /// Crea un URL temporaneo per il download della risorsa.
  Future<String> creaUrlDownload(String path) =>
      _client.storage.from(bucket).createSignedUrl(path, 60 * 30);

  /// Elimina record e, se presente, file associato.
  Future<void> eliminaRisorsa({required String id, String? path}) async {
    await _client.from('risorse_mentoring').delete().eq('id', id);
    if (path != null && path.isNotEmpty) {
      try {
        await _client.storage.from(bucket).remove([path]);
      } catch (_) {}
    }
  }
}
