import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Query e RPC condivise dall'intera area Mentoraggio.
///
/// Questa classe non gestisce stato UI e non chiama notifyListeners: restituisce
/// soltanto dati al controller che li trasforma nel modello richiesto dalla
/// pagina.
class MentoraggiRepository {
  MentoraggiRepository(this.db);

  final RepositoryComune db;

  String? get userIdCorrente => db.userIdCorrente;

  /// Schema DB usato dalle pagine per costruire localmente la sola visualizzazione.
  Future<SchemaDatabase> schemaDatabase() => db.schemaDatabase();

  Future<String?> annoAccademicoCorrente() async {
    final riga = await db.singolo(
      tabella: 'anni_accademici',
      colonne: 'codice',
      filtri: const <FiltroDb>[
        FiltroDb('corrente', true),
      ],
    );
    return riga?['codice']?.toString();
  }

  Future<List<Map<String, dynamic>>> insegnamentiDelDocente(
    String docenteId,
  ) => db.elenco(
        tabella: 'insegnamenti',
        filtri: <FiltroDb>[
          FiltroDb('docente_id', docenteId),
        ],
      );

  Future<List<Map<String, dynamic>>> insegnamentiPerId(
    List<String> ids,
  ) {
    if (ids.isEmpty) return Future.value(const <Map<String, dynamic>>[]);
    return db.elenco(
      tabella: 'insegnamenti',
      filtriIn: <FiltroInDb>[
        FiltroInDb('id', ids),
      ],
    );
  }

  Future<List<Map<String, dynamic>>> mentoraggiDelMentee() =>
      db.rpcElenco('mentoraggi_del_mentee');

  Future<List<Map<String, dynamic>>> mentoraggiDelMentore() =>
      db.rpcElenco('mentoraggi_del_mentore');

  Future<List<Map<String, dynamic>>> assegnazioniDelMentore(
    String mentoreId,
  ) => db.elenco(
        tabella: 'mentoraggio_mentori',
        colonne: 'mentoraggio_id, mentore_id, tipo',
        filtri: <FiltroDb>[
          FiltroDb('mentore_id', mentoreId),
        ],
      );

  Future<List<Map<String, dynamic>>> assegnazioniPerMentoraggi(
    List<String> mentoraggioIds,
  ) {
    if (mentoraggioIds.isEmpty) {
      return Future.value(const <Map<String, dynamic>>[]);
    }
    return db.elenco(
      tabella: 'mentoraggio_mentori',
      colonne: 'mentoraggio_id, mentore_id, tipo',
      filtriIn: <FiltroInDb>[
        FiltroInDb('mentoraggio_id', mentoraggioIds),
      ],
    );
  }

  Future<List<Map<String, dynamic>>> anagrafiche(
    List<String> userIds, {
    bool includiCellulare = false,
  }) {
    if (userIds.isEmpty) {
      return Future.value(const <Map<String, dynamic>>[]);
    }
    return db.elenco(
      tabella: 'anagrafica',
      colonne: includiCellulare
          ? 'user_id, nome, cognome, email_unipa, cellulare'
          : 'user_id, nome, cognome, email_unipa',
      filtriIn: <FiltroInDb>[
        FiltroInDb('user_id', userIds),
      ],
    );
  }

  Future<Map<String, dynamic>?> sintesiQuestionario(
    String mentoraggioId,
  ) => db.rpcMappa(
        'questionario_sintesi_mentoraggio',
        parametri: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
        },
      );

  Future<Map<String, dynamic>?> risultatiQuestionario(
    String mentoraggioId,
  ) => db.rpcMappa(
        'questionario_risultati_mentoraggio',
        parametri: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
        },
      );

  Future<void> aggiornaComeMentee(
    String mentoraggioId,
    Map<String, dynamic> valori,
  ) async {
    await db.rpc(
      'mentoraggio_aggiorna_mentee',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_valori': valori,
      },
    );
  }

  /// Restituisce un URL apribile per una scheda di sintesi salvata nello Storage.
  Future<String> urlSchedaSintesi(
    String valore, {
    int durataSecondi = 3600,
  }) async {
    if (valore.startsWith('http://') || valore.startsWith('https://')) {
      return valore;
    }
    return db.client.storage
        .from('schede-sintesi')
        .createSignedUrl(valore, durataSecondi);
  }

  /// Carica/sostituisce la scheda di sintesi e aggiorna il mentoraggio.
  ///
  /// L'eventuale vecchio file viene rimosso solo dopo che il nuovo documento
  /// è stato caricato e registrato correttamente nel database.
  Future<String> salvaSchedaSintesi({
    required String mentoraggioId,
    required String annoAccademico,
    required String estensione,
    required Uint8List bytes,
    required String contentType,
    String? percorsoPrecedente,
  }) async {
    const bucket = 'schede-sintesi';
    final path = '$annoAccademico/$mentoraggioId/scheda_sintesi.$estensione';

    await db.client.storage.from(bucket).uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(upsert: true, contentType: contentType),
    );

    await db.rpc(
      'mentoraggio_scheda_sintesi_imposta',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_storage_path': path,
      },
    );

    final precedente = percorsoPrecedente?.trim() ?? '';
    if (precedente.isNotEmpty &&
        precedente != path &&
        !precedente.startsWith('http://') &&
        !precedente.startsWith('https://')) {
      try {
        await db.client.storage.from(bucket).remove(<String>[precedente]);
      } catch (_) {
        // Il nuovo documento è valido; un residuo del file precedente non
        // deve annullare l'operazione conclusa correttamente.
      }
    }
    return path;
  }

  Future<void> aggiornaComeMentore(
    String mentoraggioId,
    Map<String, dynamic> valori,
  ) async {
    await db.rpc(
      'mentoraggio_aggiorna_mentore',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_valori': valori,
      },
    );
  }
}
