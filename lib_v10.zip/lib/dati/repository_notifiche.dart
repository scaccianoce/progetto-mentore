import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Accesso centralizzato ai dati e alle funzioni Supabase dell'area notifiche.
///
/// Tutte le operazioni remote della pagina notifiche passano da questa classe:
/// le pagine e i controller non costruiscono query Supabase direttamente.
class NotificheRepository {
  NotificheRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  /// Flusso di autenticazione usato dal servizio push per sincronizzare il device.
  Stream<AuthState> get cambiAutenticazione => _client.auth.onAuthStateChange;

  bool get utenteAutenticato => _client.auth.currentUser != null;

  /// Carica lo schema DB usato dai dialog dinamici delle notifiche.
  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();


  /// Conta le notifiche consegnate all'utente corrente usate per il badge.
  Future<int> contaNotificheNonLette() async {
    final userId = userIdCorrente;
    if (userId == null) return 0;
    final List<dynamic> raw = await _client
        .from('notifiche_destinatari')
        .select('id')
        .eq('user_id', userId)
        .eq('stato', 'inviato');
    return raw.length;
  }

  Future<void> registraDispositivo({
    required String token,
    required String piattaforma,
  }) async {
    await _client.rpc(
      'notifiche_registra_dispositivo',
      params: <String, dynamic>{
        'p_token': token,
        'p_piattaforma': piattaforma,
      },
    );
  }

  Future<void> disattivaDispositivo(String token) async {
    await _client.rpc(
      'notifiche_disattiva_dispositivo',
      params: <String, dynamic>{'p_token': token},
    );
  }

  /// Restituisce gli ultimi messaggi creati, dal più recente al più vecchio.
  Future<List<Map<String, dynamic>>> messaggi({int limite = 200}) async {
    final List<dynamic> raw = await _client
        .from('notifiche_messaggi')
        .select()
        .order('created_at', ascending: false)
        .limit(limite);
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Restituisce il dettaglio dei destinatari generati per un messaggio.
  Future<List<Map<String, dynamic>>> destinatariMessaggio(
    String messaggioId,
  ) async {
    final dynamic raw = await _client.rpc(
      'notifiche_dettaglio_destinatari',
      params: <String, dynamic>{'p_messaggio_id': messaggioId},
    );
    if (raw == null) return const <Map<String, dynamic>>[];
    return (raw as List<dynamic>)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Carica le possibili scelte per un tipo di destinatario manuale.
  Future<List<Map<String, dynamic>>> opzioniDestinatari(String tipo) async {
    dynamic raw;
    switch (tipo) {
      case 'iscritti_evento':
        raw = await _client
            .from('eventi')
            .select()
            .order('created_at', ascending: false);
        break;
      case 'iscritti_house_of_mentore':
        raw = await _client
            .from('house_of_mentore')
            .select()
            .order('created_at', ascending: false);
        break;
      case 'anno_accademico':
        raw = await _client
            .from('anni_accademici')
            .select('codice, corrente')
            .order('codice', ascending: false);
        break;
      case 'manuale':
        raw = await _client.rpc('notifiche_elenco_utenti_attivi');
        break;
      default:
        raw = const <dynamic>[];
    }
    return (raw as List<dynamic>)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Crea un messaggio e restituisce l'identificativo assegnato dal database.
  Future<String> creaMessaggio(Map<String, dynamic> valori) async {
    final dynamic raw = await _client
        .from('notifiche_messaggi')
        .insert(valori)
        .select('id')
        .single();
    final id = (raw as Map)['id']?.toString() ?? '';
    if (id.isEmpty) {
      throw StateError('Il database non ha restituito l’ID della notifica.');
    }
    return id;
  }

  Future<void> aggiornaMessaggio(
    String messaggioId,
    Map<String, dynamic> valori,
  ) async {
    await _client
        .from('notifiche_messaggi')
        .update(valori)
        .eq('id', messaggioId);
  }

  Future<void> eliminaMessaggio(String messaggioId) async {
    await _client.from('notifiche_messaggi').delete().eq('id', messaggioId);
  }

  Future<void> eliminaDestinatari(String messaggioId) async {
    await _client
        .from('notifiche_destinatari')
        .delete()
        .eq('messaggio_id', messaggioId);
  }

  /// Genera i destinatari e restituisce il numero calcolato dalla RPC.
  Future<int> generaDestinatari(String messaggioId) async {
    final dynamic raw = await _client
        .rpc(
          'notifiche_genera_destinatari',
          params: <String, dynamic>{'p_messaggio_id': messaggioId},
        )
        .timeout(const Duration(seconds: 30));
    if (raw is num) return raw.toInt();
    return int.tryParse(raw?.toString() ?? '') ?? 0;
  }

  /// Invoca la Edge Function che effettua l'invio push.
  ///
  /// Se l'invocazione fallisce, il messaggio viene portato nello stato
  /// `errore`, evitando che resti indefinitamente in `da_inviare`.
  Future<void> inviaMessaggio(String messaggioId) async {
    try {
      final risposta = await _client.functions
          .invoke(
            'notifiche-invia',
            body: <String, dynamic>{'messaggio_id': messaggioId},
          )
          .timeout(const Duration(seconds: 30));
      if (risposta.status < 200 || risposta.status >= 300) {
        throw StateError(
          'Invio push non riuscito (HTTP ${risposta.status}): ${risposta.data}',
        );
      }
    } catch (e) {
      try {
        await aggiornaMessaggio(
          messaggioId,
          <String, dynamic>{'stato': 'errore'},
        );
      } catch (_) {
        // Conserva l'errore originale dell'invio: è il dato più utile alla UI.
      }
      rethrow;
    }
  }

  /// Carica i destinatari consegnati all'utente corrente per la pagina notifiche.
  Future<List<Map<String, dynamic>>> notificheRicevute({int limite = 20}) async {
    final userId = userIdCorrente;
    if (userId == null) return const <Map<String, dynamic>>[];
    final raw = await _client
        .from('notifiche_destinatari')
        .select('id, messaggio_id, stato, inviato_at, letto_at, created_at')
        .eq('user_id', userId)
        .inFilter('stato', const <String>['inviato', 'letto'])
        .order('created_at', ascending: false)
        .limit(limite);
    return (raw as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Carica i messaggi indicati, indicizzabili poi per ID dal controller.
  Future<List<Map<String, dynamic>>> messaggiPerIds(List<String> ids) async {
    if (ids.isEmpty) return const <Map<String, dynamic>>[];
    final raw = await _client
        .from('notifiche_messaggi')
        .select('id, titolo, messaggio, anno_accademico, origine_tabella, origine_id, inviata_at, created_at')
        .inFilter('id', ids);
    return (raw as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Segna come letto un destinatario tramite la RPC applicativa.
  Future<void> segnaDestinatarioLetto(String destinatarioId) => _client.rpc(
        'notifiche_segna_letta',
        params: <String, dynamic>{'p_destinatario_id': destinatarioId},
      );

  Future<List<Map<String, dynamic>>> regole() async {
    final List<dynamic> raw = await _client
        .from('notifiche_regole')
        .select()
        .order('codice');
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  Future<void> impostaRegolaAttiva(String id, bool attiva) async {
    await _client.from('notifiche_regole').update(
      <String, dynamic>{'attiva': attiva},
    ).eq('id', id);
  }

  Future<void> eliminaRegola(Object id) async {
    await _client.from('notifiche_regole').delete().eq('id', id);
  }

  Future<void> salvaRegola({
    Object? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('notifiche_regole').insert(valori);
    } else {
      await _client.from('notifiche_regole').update(valori).eq('id', id);
    }
  }
}
