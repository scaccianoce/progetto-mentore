import 'package:supabase_flutter/supabase_flutter.dart';

import '../ui/schema_dinamico.dart';
import 'repository_base.dart';

/// Accesso Supabase dedicato alla sessione applicativa.
///
/// Mantiene anche autenticazione e lettura del ruolo nello stesso file dati,
/// lasciando il controller di sessione responsabile esclusivamente dello stato UI.
class SessioneRepository {
  SessioneRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  Stream<AuthState> get cambiAutenticazione => _client.auth.onAuthStateChange;
  User? get utenteCorrente => _client.auth.currentUser;

  Future<AuthResponse> accedi({
    required String email,
    required String password,
  }) => _client.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );

  Future<void> esci() => _client.auth.signOut();

  Future<Map<String, dynamic>?> ruoloUtente(String userId) =>
      RepositoryComune(client: _client).singolo(
        tabella: 'user_roles',
        colonne: 'role',
        filtri: <FiltroDb>[FiltroDb('user_id', userId)],
      );

  Future<SchemaDatabase> schemaDatabase() =>
      RepositoryComune(client: _client).schemaDatabase();
}
