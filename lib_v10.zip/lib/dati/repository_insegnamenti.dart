import 'repository_base.dart';

/// Query e RPC relative alla scelta e gestione annuale degli insegnamenti.
class InsegnamentiRepository {
  InsegnamentiRepository(this.db);

  final RepositoryComune db;

  String? get userIdCorrente => db.userIdCorrente;

  Future<String?> annoGestione() async {
    final raw = await db.rpc('anno_accademico_gestione_insegnamenti');
    return raw?.toString();
  }

  Future<Map<String, dynamic>?> statoAnnuale(String? anno) => db.rpcMappa(
        'insegnamento_stato_annuale',
        parametri: <String, dynamic>{
          'p_anno_accademico': anno,
        },
      );

  Future<Map<String, dynamic>?> partecipazioneAnnuale({
    required String userId,
    required String annoAccademico,
  }) => db.singolo(
        tabella: 'partecipazioni_annuali',
        colonne: 'stato, solo_mentore',
        filtri: <FiltroDb>[
          FiltroDb('user_id', userId),
          FiltroDb('anno_accademico', annoAccademico),
        ],
      );

  Future<List<Map<String, dynamic>>> miei() =>
      db.rpcElenco('insegnamenti_miei');

  Future<void> selezionaPerAnno({
    required String insegnamentoId,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_seleziona_per_anno',
      parametri: <String, dynamic>{
        'p_insegnamento_id': insegnamentoId,
        'p_anno_accademico': annoAccademico,
      },
    );
  }

  Future<void> creaPerAnno({
    required Map<String, dynamic> valori,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_crea_per_anno',
      parametri: <String, dynamic>{
        'p_valori': valori,
        'p_anno_accademico': annoAccademico,
      },
    );
  }

  Future<void> modificaAutorizzata({
    required String insegnamentoId,
    required Map<String, dynamic> valori,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_modifica_autorizzata',
      parametri: <String, dynamic>{
        'p_insegnamento_id': insegnamentoId,
        'p_valori': valori,
        'p_anno_accademico': annoAccademico,
      },
    );
  }
}
