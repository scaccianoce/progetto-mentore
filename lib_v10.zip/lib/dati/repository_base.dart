import 'package:supabase_flutter/supabase_flutter.dart';

import '../app/app_core.dart';
import '../ui/schema_dinamico.dart';
import 'dart:typed_data';

// ============================================================================
// BASE DATI: primitive condivise da tutti i repository di dominio.
//
// Questo file contiene solo i "mattoncini" comuni (client Supabase, filtri,
// ordinamenti, letture/scritture generiche). Le operazioni specifiche di ogni
// area (eventi, notifiche, questionari, ...) vivono nei rispettivi file
// `repository_*.dart` e sono riesportate da `repository.dart`.
// ============================================================================

abstract final class SupabaseConfig {
  static const String url = AppConfig.supabaseUrl;
  static const String publishableKey = AppConfig.supabasePublishableKey;

  /// Inizializza Supabase prima dell'avvio dell'app.
  static Future<void> inizializza() async {
    if (url.trim().isEmpty || publishableKey.trim().isEmpty) {
      throw StateError(
        'Configurazione Supabase mancante. Avvia l’app passando '
        'SUPABASE_URL e SUPABASE_PUBLISHABLE_KEY con --dart-define.',
      );
    }

    final Uri? indirizzo = Uri.tryParse(url);
    if (indirizzo == null || !indirizzo.hasScheme || !indirizzo.hasAuthority) {
      throw StateError('SUPABASE_URL non contiene un indirizzo valido.');
    }

    await Supabase.initialize(
      url: url,
      publishableKey: publishableKey,
      authOptions: const FlutterAuthClientOptions(
        authFlowType: AuthFlowType.pkce,
      ),
    );
  }
  /// Client condiviso usato esclusivamente dal livello dati.
  static SupabaseClient get client => Supabase.instance.client;
}

/// Filtro di uguaglianza usato nelle letture standard.
class FiltroDb {
  const FiltroDb(this.campo, this.valore);

  final String campo;
  final Object valore;
}

/// Filtro `IN (...)` usato nelle letture standard.
class FiltroInDb {
  const FiltroInDb(this.campo, this.valori);

  final String campo;
  final List<Object> valori;
}

/// Ordinamento di una query standard.
class OrdineDb {
  const OrdineDb(
    this.campo, {
    this.crescente = true,
    this.nullPrima = false,
  });

  final String campo;
  final bool crescente;
  final bool nullPrima;
}

/// Contratto minimo usato dai repository di backoffice per le autorizzazioni.
///
/// Evita che il livello dati dipenda dal controller di sessione e mantiene la
/// dipendenza nella sola direzione UI/controller -> repository.
abstract interface class AutorizzazioniBackoffice {
  bool get repositorySoloOwner;
  bool get repositoryPuoAmministrare;

  String? get repositoryUserId;
}

/// Unico punto di accesso alle operazioni Supabase comuni dell'applicazione.
///
/// Non contiene regole di business: espone soltanto primitive uniformi per
/// lettura, scrittura, RPC e autenticazione. I controller non dovrebbero
/// costruire query Supabase direttamente quando l'operazione è esprimibile qui.
class RepositoryComune {
  RepositoryComune({SupabaseClient? client})
      : client = client ?? SupabaseConfig.client;

  final SupabaseClient client;

  static SchemaDatabase? _schemaDatabase;
  static Future<SchemaDatabase>? _caricamentoSchema;

  String? get userIdCorrente => client.auth.currentUser?.id;

  /// Carica e mantiene in cache la descrizione dello schema `public`.
  ///
  /// Anche questa RPC passa dal repository, così [SupabaseConfig] resta
  /// limitato alla sola inizializzazione del client.
  Future<SchemaDatabase> schemaDatabase({bool forzaAggiornamento = false}) {
    if (!forzaAggiornamento && _schemaDatabase != null) {
      return Future<SchemaDatabase>.value(_schemaDatabase);
    }
    if (!forzaAggiornamento && _caricamentoSchema != null) {
      return _caricamentoSchema!;
    }

    final caricamento = _leggiSchemaDatabase();
    _caricamentoSchema = caricamento;
    return caricamento.whenComplete(() {
      if (identical(_caricamentoSchema, caricamento)) {
        _caricamentoSchema = null;
      }
    });
  }

  Future<SchemaDatabase> _leggiSchemaDatabase() async {
    final dynamic risposta = await client.rpc('app_database_schema');
    if (risposta is! Map) {
      throw const FormatException(
        'La funzione app_database_schema ha restituito dati non validi.',
      );
    }
    final schema = SchemaDatabase.fromJson(
      Map<String, dynamic>.from(risposta),
    );
    _schemaDatabase = schema;
    return schema;
  }

  Future<List<Map<String, dynamic>>> elenco({
    required String tabella,
    String colonne = '*',
    List<FiltroDb> filtri = const <FiltroDb>[],
    List<FiltroInDb> filtriIn = const <FiltroInDb>[],
    List<OrdineDb> ordinamenti = const <OrdineDb>[],
    int? limite,
  }) async {
    dynamic query = client.from(tabella).select(colonne);

    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }
    for (final filtro in filtriIn) {
      query = query.inFilter(filtro.campo, filtro.valori);
    }
    for (final ordine in ordinamenti) {
      query = query.order(
        ordine.campo,
        ascending: ordine.crescente,
        nullsFirst: ordine.nullPrima,
      );
    }
    if (limite != null) query = query.limit(limite);

    final List<dynamic> righe = await query;
    return righe
        .map((riga) => Map<String, dynamic>.from(riga as Map))
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> singolo({
    required String tabella,
    String colonne = '*',
    List<FiltroDb> filtri = const <FiltroDb>[],
  }) async {
    dynamic query = client.from(tabella).select(colonne);
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }

    final dynamic riga = await query.maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> inserisci({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) async {
    final dynamic riga = await client
        .from(tabella)
        .insert(valori)
        .select(colonne)
        .maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> aggiorna({
    required String tabella,
    required Map<String, dynamic> valori,
    required List<FiltroDb> filtri,
    String colonne = '*',
  }) async {
    dynamic query = client.from(tabella).update(valori);
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }

    final dynamic riga = await query.select(colonne).maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> upsert({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
    String? onConflict,
  }) async {
    dynamic query = client.from(tabella).upsert(
          valori,
          onConflict: onConflict,
        );
    final dynamic riga = await query.select(colonne).maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<void> elimina({
    required String tabella,
    required List<FiltroDb> filtri,
  }) async {
    dynamic query = client.from(tabella).delete();
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }
    await query;
  }

  /// Esegue una RPC e restituisce la risposta grezza quando il chiamante ha
  /// bisogno di distinguere Map, List, valore scalare o null.
  Future<dynamic> rpc(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) => client.rpc(nome, params: parametri);

  Future<List<Map<String, dynamic>>> rpcElenco(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) async {
    final dynamic raw = await rpc(nome, parametri: parametri);
    if (raw == null) return const <Map<String, dynamic>>[];
    return (raw as List<dynamic>)
        .map((riga) => Map<String, dynamic>.from(riga as Map))
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> rpcMappa(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) async {
    final dynamic raw = await rpc(nome, parametri: parametri);
    if (raw == null) return null;
    return Map<String, dynamic>.from(raw as Map);
  }

  /// Invoca una Edge Function e restituisce una mappa JSON validata.
  Future<Map<String, dynamic>> invocaFunzioneMappa(
    String nome, {
    Map<String, dynamic> body = const <String, dynamic>{},
  }) async {
    final risposta = await client.functions.invoke(nome, body: body);
    final data = risposta.data;
    if (risposta.status < 200 || risposta.status >= 300) {
      throw StateError('Edge Function (${risposta.status}): $data');
    }
    if (data is Map) return Map<String, dynamic>.from(data);
    throw StateError('Risposta non JSON dalla Edge Function $nome: $data');
  }
}

/// Accesso uniforme a Supabase Storage.
///
/// È separato da [RepositoryComune] perché Storage ha una semantica diversa
/// dalle tabelle PostgreSQL, ma usa lo stesso client Supabase condiviso.
class StorageRepository {
  StorageRepository({SupabaseClient? client})
      : client = client ?? SupabaseConfig.client;

  final SupabaseClient client;

  Future<void> caricaBytes({
    required String bucket,
    required String percorso,
    required Uint8List bytes,
    FileOptions opzioni = const FileOptions(upsert: true),
  }) async {
    await client.storage.from(bucket).uploadBinary(
          percorso,
          bytes,
          fileOptions: opzioni,
        );
  }

  Future<void> elimina({
    required String bucket,
    required List<String> percorsi,
  }) async {
    if (percorsi.isEmpty) return;
    await client.storage.from(bucket).remove(percorsi);
  }

  Future<String> urlFirmato({
    required String bucket,
    required String percorso,
    int durataSecondi = 3600,
  }) => client.storage
      .from(bucket)
      .createSignedUrl(percorso, durataSecondi);

  String urlPubblico({
    required String bucket,
    required String percorso,
  }) => client.storage.from(bucket).getPublicUrl(percorso);
}


// ============================================================================
// COMPATIBILITA CRUD DINAMICO
// ============================================================================

/// Alias storico mantenuto per i componenti dinamici esistenti.
typedef FiltroDinamico = FiltroDb;

/// Componente `OrdinamentoDinamico`: incapsula responsabilità specifiche del relativo modulo.
class OrdinamentoDinamico extends OrdineDb {
  const OrdinamentoDinamico(
    super.campo, {
    super.crescente = true,
    super.nullPrima = false,
  });
}

/// Adattatore compatibile con l'API CRUD dinamica esistente.
class RepositoryDinamico {
  RepositoryDinamico({SupabaseClient? client})
      : _db = RepositoryComune(client: client);

  final RepositoryComune _db;

  Future<List<Map<String, dynamic>>> elenco({
    required String tabella,
    String colonne = '*',
    List<FiltroDinamico> filtri = const <FiltroDinamico>[],
    List<OrdinamentoDinamico> ordinamenti = const <OrdinamentoDinamico>[],
  }) => _db.elenco(
        tabella: tabella,
        colonne: colonne,
        filtri: filtri,
        ordinamenti: ordinamenti,
      );

  Future<Map<String, dynamic>?> singolo({
    required String tabella,
    String colonne = '*',
    List<FiltroDinamico> filtri = const <FiltroDinamico>[],
  }) => _db.singolo(tabella: tabella, colonne: colonne, filtri: filtri);

  Future<Map<String, dynamic>?> inserisci({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) => _db.inserisci(tabella: tabella, valori: valori, colonne: colonne);

  Future<Map<String, dynamic>?> aggiorna({
    required String tabella,
    required String campoFiltro,
    required Object valoreFiltro,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) => _db.aggiorna(
        tabella: tabella,
        valori: valori,
        filtri: <FiltroDb>[FiltroDb(campoFiltro, valoreFiltro)],
        colonne: colonne,
      );

  Future<void> elimina({
    required String tabella,
    required String campoFiltro,
    required Object valoreFiltro,
  }) => _db.elimina(
        tabella: tabella,
        filtri: <FiltroDb>[FiltroDb(campoFiltro, valoreFiltro)],
      );
}
