import 'package:flutter/material.dart';

import '../../app_exception.dart';
import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/pagina_scheda_dinamica.dart';
import 'profilo_controller.dart';

class ProfiloPage extends StatefulWidget {
  const ProfiloPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<ProfiloPage> createState() => _ProfiloPageState();
}

class _ProfiloPageState extends State<ProfiloPage> {
  late final ProfiloController _controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  ConfigurazionePaginaDinamica get _configurazione =>
      ConfigurazionePaginaDinamica(
        tabella: 'anagrafica',
        campi: <String, PersonalizzazioneCampo>{
          'user_id': const PersonalizzazioneCampo(nascosto: true),
          'email_unipa': const PersonalizzazioneCampo(solaLettura: true),
          'cod_ssd': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            valoriScelta: _controller.ssd
                .map((riga) => riga['cod_ssd'].toString())
                .toList(growable: false),
          ),
          'anno_prima_partecipazione': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            valoriScelta: _controller.anniAccademici,
          ),
        },
      );

  @override
  void initState() {
    super.initState();
    _controller = ProfiloController(sessione: widget.sessione)..carica();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) {
      final profilo = _controller.profilo;
      final cardPartecipazione = _cardPartecipazione(context);

      return PaginaSchedaDinamica(
        titolo: 'Il mio profilo',
        configurazione: _configurazione,
        valori: profilo,
        partecipante: _partecipante,
        caricamento: _controller.caricamento && profilo == null,
        errore: _controller.errore,
        vuoto: profilo == null,
        messaggioVuoto: 'Profilo non trovato.',
        primaDeiCampi: cardPartecipazione == null
            ? const <Widget>[]
            : <Widget>[
                cardPartecipazione,
                const SizedBox(height: 20),
              ],
        azioni: <Widget>[
          if (_controller.puoModificare)
            FilledButton.icon(
              onPressed: _controller.salvataggio ? null : _apriEditor,
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Modifica'),
            )
          else
            OutlinedButton.icon(
              onPressed: _controller.richiediModifica,
              icon: const Icon(Icons.lock_open_outlined),
              label: const Text('Richiedi modifica'),
            ),
        ],
      );
    },
  );

  Widget? _cardPartecipazione(BuildContext context) {
    final stato = _controller.partecipazioneAnnuale;
    if (stato == null || !stato.disponibile || stato.annoAccademico == null) {
      return null;
    }

    final anno = stato.annoAccademico!;
    final tema = Theme.of(context);

    if (stato.daConfermare) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Partecipazione $anno',
                style: tema.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Conferma se desideri partecipare al Progetto Mentore nel '
                'prossimo anno accademico. La comunicazione dell’insegnamento '
                'avverrà separatamente nella pagina “I miei insegnamenti”.',
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 12,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: _controller.salvataggioPartecipazione
                        ? null
                        : () => _rispondiPartecipazione(true),
                    icon: const Icon(Icons.check_circle_outline),
                    label: const Text('Confermo la partecipazione'),
                  ),
                  OutlinedButton.icon(
                    onPressed: _controller.salvataggioPartecipazione
                        ? null
                        : () => _rispondiPartecipazione(false),
                    icon: const Icon(Icons.cancel_outlined),
                    label: const Text('Non parteciperò'),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }

    final testo = switch (stato.stato) {
      'confermato' =>
        'Partecipazione confermata. Quando il backoffice abiliterà la fase '
            'insegnamenti, potrai confermare o inserire l’insegnamento da “I miei insegnamenti”.',
      'nuovo' => 'Partecipazione registrata come nuovo partecipante.',
      'rinuncia' =>
        'Hai indicato che non parteciperai nell’anno accademico $anno. '
            'Il tuo account e lo storico restano comunque disponibili.',
      'sospeso' => 'Partecipazione temporaneamente sospesa dal backoffice.',
      _ => 'Stato partecipazione: ${stato.stato ?? '—'}',
    };

    return Card(
      child: ListTile(
        leading: Icon(
          stato.confermata || stato.nuovo
              ? Icons.check_circle_outline
              : stato.rinuncia
              ? Icons.event_busy_outlined
              : Icons.info_outline,
        ),
        title: Text('Partecipazione $anno'),
        subtitle: Text(testo),
      ),
    );
  }

  Future<void> _rispondiPartecipazione(bool partecipa) async {
    try {
      await _controller.rispondiPartecipazione(partecipa);
    } on AppException catch (errore) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
    }
  }

  Future<void> _apriEditor() async {
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazione,
      valoriIniziali: _controller.profilo!,
      partecipante: _partecipante,
      titolo: 'Modifica profilo',
    );
    if (valori == null) return;
    try {
      await _controller.salva(valori);
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }
}
