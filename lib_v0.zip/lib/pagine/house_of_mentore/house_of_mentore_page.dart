import 'package:flutter/material.dart';

import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_elenco_dettaglio_page.dart';
import 'house_of_mentore_controller.dart';

class HouseOfMentorePage extends StatefulWidget {
  const HouseOfMentorePage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<HouseOfMentorePage> createState() => _HouseOfMentorePageState();
}

class _HouseOfMentorePageState extends State<HouseOfMentorePage> {
  late final HouseOfMentoreController controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  ConfigurazionePaginaDinamica get _configurazioneEvento =>
      ConfigurazionePaginaDinamica(
        tabella: 'house_of_mentore',
        campi: <String, PersonalizzazioneCampo>{
          'id': const PersonalizzazioneCampo(nascosto: true),
          'created_at': const PersonalizzazioneCampo(nascosto: true),
          'updated_at': const PersonalizzazioneCampo(nascosto: true),
          'titolo': const PersonalizzazioneCampo(
            etichetta: 'Titolo',
            modificabilePartecipante: false,
          ),
          'descrizione': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.testoFormattato,
            etichetta: 'Descrizione',
            modificabilePartecipante: false,
          ),
          'anno_accademico': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Anno accademico',
            valoriScelta: controller.anniAccademici,
            modificabilePartecipante: false,
          ),
          'data_evento': const PersonalizzazioneCampo(
            etichetta: 'Data evento',
            modificabilePartecipante: false,
          ),
          'luogo': const PersonalizzazioneCampo(
            etichetta: 'Luogo',
            modificabilePartecipante: false,
          ),
          'locandina_url': const PersonalizzazioneCampo(
            etichetta: 'Locandina',
            modificabilePartecipante: false,
          ),
          'iscrizioni_aperte': const PersonalizzazioneCampo(
            etichetta: 'Iscrizioni aperte',
            modificabilePartecipante: false,
          ),
        },
      );

  static const _configurazioneOpzione = ConfigurazionePaginaDinamica(
    tabella: 'house_of_mentore_opzioni',
    campi: <String, PersonalizzazioneCampo>{
      'id': PersonalizzazioneCampo(nascosto: true),
      'evento_id': PersonalizzazioneCampo(nascosto: true),
      'descrizione': PersonalizzazioneCampo(etichetta: 'Descrizione'),
      'ordine_visualizzazione': PersonalizzazioneCampo(
        etichetta: 'Ordine di visualizzazione',
      ),
    },
  );

  @override
  void initState() {
    super.initState();
    controller = HouseOfMentoreController(widget.sessione)..carica();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) => TemplatePaginaElencoDettaglio(
      caricamento: controller.caricamento && controller.eventi.isEmpty,
      errore: controller.errore,
      vuoto: controller.eventi.isEmpty,
      messaggioVuoto: 'Nessuna iniziativa disponibile.',
      larghezzaElenco: 340,
      intestazione: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              'House of Mentore',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
          IconButton(
            tooltip: 'Aggiorna',
            onPressed: controller.carica,
            icon: const Icon(Icons.refresh),
          ),
          if (controller.puoGestire)
            FilledButton.icon(
              onPressed: () => _apriEditorEvento(),
              icon: const Icon(Icons.add),
              label: const Text('Nuovo'),
            ),
        ],
      ),
      elenco: Card(margin: EdgeInsets.zero, child: _elenco()),
      dettaglio: controller.eventoSelezionato == null
          ? const Center(child: Text('Seleziona un’iniziativa.'))
          : Card(
              margin: EdgeInsets.zero,
              child: _dettaglio(controller.eventoSelezionato!),
            ),
    ),
  );

  Widget _elenco() => ListView.builder(
    itemCount: controller.eventi.length,
    itemBuilder: (context, indice) {
      final evento = controller.eventi[indice];
      final id = evento['id'].toString();
      return ListTile(
        selected: id == controller.eventoSelezionatoId,
        leading: const Icon(Icons.home_work_outlined),
        title: Text(
          _testo(evento['titolo']),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${_data(evento['data_evento'])} · ${_testo(evento['anno_accademico'])}',
        ),
        trailing: controller.iscrizione(id) == null
            ? null
            : const Icon(Icons.check_circle, color: Colors.green),
        onTap: () => controller.seleziona(evento),
      );
    },
  );

  Widget _dettaglio(Map<String, dynamic> evento) {
    final eventoId = evento['id'].toString();
    final opzioni = controller.opzioni(eventoId);
    final iscrizione = controller.iscrizione(eventoId);
    final iscrizioniAperte = evento['iscrizioni_aperte'] == true;
    final locandina = _testo(evento['locandina_url']);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: <Widget>[
        if (locandina.isNotEmpty)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.network(
              locandina,
              height: 260,
              fit: BoxFit.contain,
              errorBuilder: (_, _, _) => const SizedBox(
                height: 100,
                child: Center(child: Text('Locandina non disponibile.')),
              ),
            ),
          ),
        CampiTabellaDinamici(
          configurazione: _configurazioneEvento,
          valori: evento,
          partecipante: _partecipante,
        ),
        const Divider(height: 32),
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Alternative di partecipazione',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            if (controller.puoGestire)
              TextButton.icon(
                onPressed: () => _apriEditorOpzione(eventoId),
                icon: const Icon(Icons.add),
                label: const Text('Aggiungi'),
              ),
          ],
        ),
        if (opzioni.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Text('Le alternative non sono ancora disponibili.'),
          )
        else
          for (final opzione in opzioni)
            _OpzioneTile(
              opzione: opzione,
              selezionata:
                  iscrizione?['opzione_id']?.toString() ==
                  opzione['id'].toString(),
              abilitata: iscrizioniAperte,
              puoGestire: controller.puoGestire,
              onScegli: () => _scegli(eventoId, opzione['id'].toString()),
              onModifica: () => _apriEditorOpzione(eventoId, opzione: opzione),
              onElimina: () => _eliminaOpzione(opzione),
            ),
        if (!iscrizioniAperte)
          const Padding(
            padding: EdgeInsets.only(top: 12),
            child: Text('Le iscrizioni non sono aperte.'),
          ),
        if (iscrizione != null)
          TextButton.icon(
            onPressed: iscrizioniAperte
                ? () => _cancellaIscrizione(eventoId)
                : null,
            icon: const Icon(Icons.event_busy),
            label: const Text('Cancella la mia iscrizione'),
          ),
        if (controller.puoGestire) ...<Widget>[
          const Divider(height: 32),
          Wrap(
            spacing: 8,
            children: <Widget>[
              OutlinedButton.icon(
                onPressed: () => _apriEditorEvento(evento),
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Modifica evento'),
              ),
              OutlinedButton.icon(
                onPressed: () => _eliminaEvento(evento),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Elimina evento'),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Future<void> _scegli(String eventoId, String opzioneId) async {
    final errore = await controller.scegliOpzione(
      eventoId: eventoId,
      opzioneId: opzioneId,
    );
    _esito(errore, 'Scelta registrata.');
  }

  Future<void> _cancellaIscrizione(String eventoId) async {
    final conferma = await _conferma(
      'Cancellare l’iscrizione?',
      'Potrai iscriverti nuovamente finché le iscrizioni saranno aperte.',
    );
    if (!conferma) return;
    final errore = await controller.cancellaIscrizione(eventoId);
    _esito(errore, 'Iscrizione cancellata.');
  }

  Future<void> _apriEditorEvento([Map<String, dynamic>? evento]) async {
    final dati = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazioneEvento,
      valoriIniziali:
          evento ??
          <String, dynamic>{
            'titolo': '',
            'anno_accademico': controller.anniAccademici.isEmpty
                ? null
                : controller.anniAccademici.first,
            'iscrizioni_aperte': false,
          },
      partecipante: _partecipante,
      titolo: evento == null ? 'Nuovo evento' : 'Modifica evento',
    );
    if (dati == null) return;
    final errore = await controller.salvaEvento(
      id: evento?['id']?.toString(),
      dati: dati,
    );
    _esito(errore, 'Evento salvato.');
  }

  Future<void> _apriEditorOpzione(
    String eventoId, {
    Map<String, dynamic>? opzione,
  }) async {
    final dati = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazioneOpzione,
      valoriIniziali:
          opzione ??
          <String, dynamic>{
            'evento_id': eventoId,
            'descrizione': '',
            'ordine_visualizzazione': 0,
          },
      partecipante: false,
      titolo: opzione == null ? 'Nuova alternativa' : 'Modifica alternativa',
    );
    if (dati == null) return;
    final errore = await controller.salvaOpzione(
      id: opzione?['id']?.toString(),
      eventoId: eventoId,
      descrizione: dati['descrizione'].toString(),
      ordine: (dati['ordine_visualizzazione'] as num).toInt(),
    );
    _esito(errore, 'Alternativa salvata.');
  }

  Future<void> _eliminaEvento(Map<String, dynamic> evento) async {
    final conferma = await _conferma(
      'Eliminare House of Mentore?',
      'Verranno eliminate anche le relative alternative.',
    );
    if (!conferma) return;
    final errore = await controller.eliminaEvento(evento['id'].toString());
    _esito(errore, 'Evento eliminato.');
  }

  Future<void> _eliminaOpzione(Map<String, dynamic> opzione) async {
    final conferma = await _conferma(
      'Eliminare l’alternativa?',
      _testo(opzione['descrizione']),
    );
    if (!conferma) return;
    final errore = await controller.eliminaOpzione(opzione['id'].toString());
    _esito(errore, 'Alternativa eliminata.');
  }

  Future<bool> _conferma(String titolo, String testo) async =>
      await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(titolo),
          content: Text(testo),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Annulla'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Conferma'),
            ),
          ],
        ),
      ) ??
      false;

  void _esito(String? errore, String successo) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(errore ?? successo)));
  }
}

class _OpzioneTile extends StatelessWidget {
  const _OpzioneTile({
    required this.opzione,
    required this.selezionata,
    required this.abilitata,
    required this.puoGestire,
    required this.onScegli,
    required this.onModifica,
    required this.onElimina,
  });

  final Map<String, dynamic> opzione;
  final bool selezionata;
  final bool abilitata;
  final bool puoGestire;
  final VoidCallback onScegli;
  final VoidCallback onModifica;
  final VoidCallback onElimina;

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(
        selezionata ? Icons.radio_button_checked : Icons.radio_button_unchecked,
        color: selezionata
            ? Theme.of(context).colorScheme.primary
            : abilitata
            ? null
            : Theme.of(context).disabledColor,
      ),
      title: Text(_testo(opzione['descrizione'])),
      onTap: abilitata ? onScegli : null,
      trailing: puoGestire
          ? PopupMenuButton<String>(
              onSelected: (valore) =>
                  valore == 'modifica' ? onModifica() : onElimina(),
              itemBuilder: (_) => const <PopupMenuEntry<String>>[
                PopupMenuItem(value: 'modifica', child: Text('Modifica')),
                PopupMenuItem(value: 'elimina', child: Text('Elimina')),
              ],
            )
          : null,
    ),
  );
}

String _testo(Object? valore) => valore?.toString().trim() ?? '';

String _data(Object? valore) {
  final data = valore is DateTime ? valore : DateTime.tryParse(_testo(valore));
  if (data == null) return '—';
  return '${data.day.toString().padLeft(2, '0')}/'
      '${data.month.toString().padLeft(2, '0')}/${data.year}';
}
