import 'package:flutter/material.dart';

import '../../app_exception.dart';
import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_elenco_dettaglio_page.dart';
import 'mentore_controller.dart';

class MentorePage extends StatefulWidget {
  const MentorePage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<MentorePage> createState() => _MentorePageState();
}

class _MentorePageState extends State<MentorePage> {
  static const configurazione = ConfigurazionePaginaDinamica(
    tabella: 'mentoraggi',
    campi: <String, PersonalizzazioneCampo>{
      'id': PersonalizzazioneCampo(nascosto: true),
      'insegnamento_id': PersonalizzazioneCampo(nascosto: true),
      'created_at': PersonalizzazioneCampo(nascosto: true),
      'updated_at': PersonalizzazioneCampo(nascosto: true),
      'osservazioni_aula': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoMultiriga,
        etichetta: 'Osservazioni aula',
      ),
      'osservazioni_focus_group': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoMultiriga,
        etichetta: 'Osservazioni focus group',
      ),
      'scheda_sintesi': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoFormattato,
        etichetta: 'Scheda di sintesi',
      ),
      'stato': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.scelta,
        etichetta: 'Stato',
        valoriScelta: <String>['Non iniziato', 'In corso', 'Completato'],
      ),
      'stato_mentoraggio': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.scelta,
        etichetta: 'Stato mentoraggio',
        valoriScelta: <String>['Non iniziato', 'In corso', 'Completato'],
      ),
    },
  );

  late final MentoreController controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  @override
  void initState() {
    super.initState();
    controller = MentoreController()..carica();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) => TemplatePaginaElencoDettaglio(
      caricamento: controller.caricamento && controller.percorsi.isEmpty,
      errore: controller.errore,
      vuoto: controller.percorsi.isEmpty,
      messaggioVuoto: 'Nessun mentoraggio assegnato.',
      larghezzaElenco: 340,
      elenco: Card(
        margin: EdgeInsets.zero,
        child: ListView(
          children: controller.percorsi
              .map(
                (percorso) => ListTile(
                  selected:
                      percorso.mentoraggio['id'] ==
                      controller.selezionato?.mentoraggio['id'],
                  title: Text(
                    percorso.insegnamento['insegnamento']?.toString() ?? '',
                  ),
                  subtitle: Text(
                    '${percorso.docente['nome'] ?? ''} ${percorso.docente['cognome'] ?? ''}'
                        .trim(),
                  ),
                  onTap: () => controller.seleziona(percorso),
                ),
              )
              .toList(growable: false),
        ),
      ),
      dettaglio: Card(margin: EdgeInsets.zero, child: _dettaglio()),
    ),
  );

  Widget _dettaglio() {
    final percorso = controller.selezionato;
    if (percorso == null) {
      return const Center(child: Text('Seleziona un mentoraggio.'));
    }
    return ListView(
      padding: const EdgeInsets.all(20),
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Ruolo mentore',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            FilledButton.icon(
              onPressed: controller.salvataggio ? null : _modifica,
              icon: const Icon(Icons.edit),
              label: const Text('Modifica'),
            ),
          ],
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Insegnamento'),
          subtitle: Text(
            percorso.insegnamento['insegnamento']?.toString() ?? '',
          ),
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Mentee',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
            '${percorso.docente['nome'] ?? ''} ${percorso.docente['cognome'] ?? ''}'
                .trim(),
          ),
        ),
        const Divider(),
        Text('Team', style: Theme.of(context).textTheme.titleMedium),
        ...percorso.team.map(
          (mentore) => ListTile(
            title: Text(
              '${mentore['nome'] ?? ''} ${mentore['cognome'] ?? ''}'.trim(),
            ),
            subtitle: Text(mentore['tipo']?.toString() ?? ''),
          ),
        ),
        const Divider(),
        CampiTabellaDinamici(
          configurazione: configurazione,
          valori: percorso.mentoraggio,
          partecipante: _partecipante,
        ),
      ],
    );
  }

  Future<void> _modifica() async {
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: configurazione,
      valoriIniziali: controller.selezionato!.mentoraggio,
      partecipante: _partecipante,
      titolo: 'Aggiorna mentoraggio',
    );
    if (valori == null) return;
    try {
      await controller.salvaMentoraggio(valori);
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }
}
