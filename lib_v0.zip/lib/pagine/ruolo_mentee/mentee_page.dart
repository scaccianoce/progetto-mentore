import 'package:flutter/material.dart';

import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_scheda_page.dart';
import 'mentee_controller.dart';

class MenteePage extends StatefulWidget {
  const MenteePage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<MenteePage> createState() => _MenteePageState();
}

class _MenteePageState extends State<MenteePage> {
  static const configurazione = ConfigurazionePaginaDinamica(
    tabella: 'mentoraggi',
    campi: <String, PersonalizzazioneCampo>{
      'id': PersonalizzazioneCampo(nascosto: true),
      'insegnamento_id': PersonalizzazioneCampo(nascosto: true),
      'created_at': PersonalizzazioneCampo(nascosto: true),
      'updated_at': PersonalizzazioneCampo(nascosto: true),
      'osservazioni_aula': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoMultiriga,
        modificabilePartecipante: false,
      ),
      'osservazioni_focus_group': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoMultiriga,
        modificabilePartecipante: false,
      ),
      'scheda_sintesi': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoFormattato,
        modificabilePartecipante: false,
      ),
    },
  );

  late final MenteeController controller;

  @override
  void initState() {
    super.initState();
    controller = MenteeController()..carica();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) {
      final mentoraggio = controller.mentoraggio;
      final messaggioVuoto = controller.insegnamento == null
          ? 'Nessun insegnamento per l’anno corrente.'
          : 'Mentoraggio non ancora disponibile.';
      return TemplatePaginaScheda(
        titolo: 'Ruolo mentee',
        caricamento: controller.caricamento,
        errore: controller.errore,
        vuoto: mentoraggio == null,
        messaggioVuoto: messaggioVuoto,
        contenuto: mentoraggio == null
            ? const SizedBox.shrink()
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      controller.insegnamento!['insegnamento']?.toString() ??
                          '',
                    ),
                    subtitle: Text(
                      controller.insegnamento!['anno_accademico']?.toString() ??
                          '',
                    ),
                  ),
                  const Divider(height: 28),
                  Text(
                    'Team di mentoraggio',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  ...controller.mentori.map(
                    (mentore) => ListTile(
                      leading: const Icon(Icons.person_outline),
                      title: Text(
                        '${mentore['nome'] ?? ''} ${mentore['cognome'] ?? ''}'
                            .trim(),
                      ),
                      subtitle: Text(
                        '${mentore['tipo'] ?? ''} · ${mentore['email_unipa'] ?? ''}',
                      ),
                    ),
                  ),
                  const Divider(height: 28),
                  CampiTabellaDinamici(
                    configurazione: configurazione,
                    valori: mentoraggio,
                    partecipante: widget.sessione.ruolo == AppRole.participant,
                  ),
                ],
              ),
      );
    },
  );
}
