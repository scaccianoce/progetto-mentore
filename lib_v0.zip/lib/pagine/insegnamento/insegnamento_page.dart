import 'package:flutter/material.dart';

import '../../app_exception.dart';
import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_scheda_page.dart';
import 'insegnamento_controller.dart';

class InsegnamentoPage extends StatefulWidget {
  const InsegnamentoPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<InsegnamentoPage> createState() => _InsegnamentoPageState();
}

class _InsegnamentoPageState extends State<InsegnamentoPage> {
  late final InsegnamentoController _controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  ConfigurazionePaginaDinamica get _configurazione {
    final nuovo = _controller.insegnamento == null;
    return ConfigurazionePaginaDinamica(
      tabella: 'insegnamenti',
      campi: <String, PersonalizzazioneCampo>{
        'id': const PersonalizzazioneCampo(nascosto: true),
        'docente_id': const PersonalizzazioneCampo(nascosto: true),
        'anno_accademico': const PersonalizzazioneCampo(nascosto: true),
        'created_at': const PersonalizzazioneCampo(nascosto: true),
        'insegnamento': PersonalizzazioneCampo(
          etichetta: 'Insegnamento',
          modificabilePartecipante: nuovo,
        ),
        'semestre': PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.scelta,
          etichetta: 'Semestre',
          valoriScelta: const <String>['I semestre', 'II semestre', 'Annuale'],
          modificabilePartecipante: nuovo,
        ),
        'cfu': const PersonalizzazioneCampo(etichetta: 'CFU'),
        'ore': const PersonalizzazioneCampo(etichetta: 'Ore'),
        'cds': const PersonalizzazioneCampo(etichetta: 'Corso di studi'),
        'anno_erogazione': const PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.scelta,
          etichetta: 'Anno di erogazione',
          valoriScelta: <String>[
            '1° anno',
            '2° anno',
            '3° anno',
            '4° anno',
            '5° anno',
          ],
        ),
        'data_inizio': const PersonalizzazioneCampo(etichetta: 'Data inizio'),
        'data_fine': const PersonalizzazioneCampo(etichetta: 'Data fine'),
        'numero_studenti': const PersonalizzazioneCampo(
          etichetta: 'Numero studenti',
        ),
        'sede': const PersonalizzazioneCampo(etichetta: 'Sede'),
        'svolgimento': const PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.scelta,
          etichetta: 'Svolgimento',
          valoriScelta: <String>['In presenza', 'Online', 'Misto'],
        ),
        'gia_mentorato': const PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.scelta,
          etichetta: 'Già mentorato',
          valoriScelta: <String>['1 volta', '2 volte', '3 o più volte'],
        ),
        'giorni_orari_lezioni': const PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.testoMultiriga,
          etichetta: 'Giorni e orari delle lezioni',
        ),
        'note': const PersonalizzazioneCampo(
          tipo: TipoCampoDinamico.testoMultiriga,
          etichetta: 'Note',
        ),
      },
    );
  }

  @override
  void initState() {
    super.initState();
    _controller = InsegnamentoController(sessione: widget.sessione)..carica();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) {
      final insegnamento = _controller.insegnamento;
      return TemplatePaginaScheda(
        titolo: 'Il mio insegnamento — ${_controller.annoCorrente ?? ''}',
        caricamento: _controller.caricamento,
        errore: _controller.errore,
        azioni: <Widget>[
          if (_controller.puoModificare)
            FilledButton.icon(
              onPressed: _controller.salvataggio ? null : _apriEditor,
              icon: Icon(
                insegnamento == null ? Icons.add : Icons.edit_outlined,
              ),
              label: Text(insegnamento == null ? 'Inserisci' : 'Modifica'),
            ),
        ],
        contenuto: insegnamento == null
            ? const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Nessun insegnamento per l’anno corrente.'),
              )
            : CampiTabellaDinamici(
                configurazione: _configurazione,
                valori: insegnamento,
                partecipante: _partecipante,
              ),
      );
    },
  );

  Future<void> _apriEditor() async {
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazione,
      valoriIniziali:
          _controller.insegnamento ??
          <String, dynamic>{
            'insegnamento': '',
            'semestre': 'I semestre',
            'anno_erogazione': '1° anno',
            'svolgimento': 'In presenza',
          },
      partecipante: _partecipante,
      titolo: 'Dati dell’insegnamento',
    );
    if (valori == null) return;
    try {
      await _controller.salva(valori);
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }
}
