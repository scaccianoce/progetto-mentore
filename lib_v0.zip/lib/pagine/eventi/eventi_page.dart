import 'package:flutter/material.dart';

import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_elenco_dettaglio_page.dart';
import 'eventi_controller.dart';

class EventiPage extends StatefulWidget {
  const EventiPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<EventiPage> createState() => _EventiPageState();
}

class _EventiPageState extends State<EventiPage> {
  late final EventiController controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  ConfigurazionePaginaDinamica get _configurazione =>
      ConfigurazionePaginaDinamica(
        tabella: 'eventi',
        campi: <String, PersonalizzazioneCampo>{
          'id': const PersonalizzazioneCampo(nascosto: true),
          'created_at': const PersonalizzazioneCampo(nascosto: true),
          'updated_at': const PersonalizzazioneCampo(nascosto: true),
          'titolo': const PersonalizzazioneCampo(
            etichetta: 'Titolo',
            modificabilePartecipante: false,
          ),
          'anno_accademico': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Anno accademico',
            valoriScelta: controller.anniAccademici,
            modificabilePartecipante: false,
          ),
          'data_evento': const PersonalizzazioneCampo(
            etichetta: 'Data evento',
            modificabilePartecipante: false,
          ),
          'tipologia': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Tipologia',
            valoriScelta: <String>[
              'Incontro di approfondimento',
              'Seminario',
              'Workshop',
              'Altro',
            ],
            modificabilePartecipante: false,
          ),
          'modalita': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Modalità',
            valoriScelta: <String>['In presenza', 'A distanza', 'Misto'],
            modificabilePartecipante: false,
          ),
          'luogo': const PersonalizzazioneCampo(
            etichetta: 'Luogo',
            modificabilePartecipante: false,
          ),
          'descrizione': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.testoFormattato,
            etichetta: 'Descrizione',
            modificabilePartecipante: false,
          ),
          'relatori': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.testoMultiriga,
            etichetta: 'Relatori',
            modificabilePartecipante: false,
          ),
          'moderatori': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.testoMultiriga,
            etichetta: 'Moderatori',
            modificabilePartecipante: false,
          ),
          'note_organizzative': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.testoMultiriga,
            etichetta: 'Note organizzative',
            modificabilePartecipante: false,
          ),
          'locandina_path': const PersonalizzazioneCampo(
            etichetta: 'Locandina',
            modificabilePartecipante: false,
          ),
          'modulo_partecipazione_url': const PersonalizzazioneCampo(
            etichetta: 'Modulo di partecipazione',
            modificabilePartecipante: false,
          ),
          'data_apertura_iscrizioni': const PersonalizzazioneCampo(
            etichetta: 'Apertura iscrizioni',
            modificabilePartecipante: false,
          ),
          'data_chiusura_iscrizioni': const PersonalizzazioneCampo(
            etichetta: 'Chiusura iscrizioni',
            modificabilePartecipante: false,
          ),
          'questionario_gradimento_attivo': const PersonalizzazioneCampo(
            etichetta: 'Questionario attivo',
            visibilePartecipante: false,
            modificabilePartecipante: false,
          ),
          'link_questionario_gradimento': const PersonalizzazioneCampo(
            etichetta: 'Link questionario',
            visibilePartecipante: false,
            modificabilePartecipante: false,
          ),
        },
      );

  @override
  void initState() {
    super.initState();
    controller = EventiController(widget.sessione)..carica();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) => TemplatePaginaElencoDettaglio(
      caricamento: controller.caricamento && controller.eventi.isEmpty,
      errore: controller.errore,
      vuoto: controller.eventi.isEmpty,
      messaggioVuoto: 'Nessun evento disponibile.',
      larghezzaElenco: 340,
      intestazione: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              'Eventi',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
          IconButton(
            onPressed: controller.carica,
            tooltip: 'Aggiorna',
            icon: const Icon(Icons.refresh),
          ),
          if (controller.puoGestire)
            FilledButton.icon(
              onPressed: () => _apriEditor(),
              icon: const Icon(Icons.add),
              label: const Text('Nuovo'),
            ),
        ],
      ),
      elenco: Card(margin: EdgeInsets.zero, child: _elenco()),
      dettaglio: controller.eventoSelezionato == null
          ? const Center(child: Text('Seleziona un evento.'))
          : Card(
              margin: EdgeInsets.zero,
              child: _dettaglio(controller.eventoSelezionato!),
            ),
    ),
  );

  Widget _elenco() => ListView.builder(
    itemCount: controller.eventi.length,
    itemBuilder: (context, indice) {
      final evento = controller.eventi[indice];
      final id = evento['id'].toString();
      return ListTile(
        selected: id == controller.eventoSelezionatoId,
        title: Text(
          evento['titolo']?.toString() ?? '',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(_data(evento['data_evento'])),
        trailing: controller.iscritto(id)
            ? const Icon(Icons.check_circle, color: Colors.green)
            : null,
        onTap: () => controller.seleziona(evento),
      );
    },
  );

  Widget _dettaglio(Map<String, dynamic> evento) {
    final id = evento['id'].toString();
    final iscritto = controller.iscritto(id);
    final aperte = controller.iscrizioniAperte(evento);
    return ListView(
      padding: const EdgeInsets.all(20),
      children: <Widget>[
        CampiTabellaDinamici(
          configurazione: _configurazione,
          valori: evento,
          partecipante: _partecipante,
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: aperte ? () => _cambiaIscrizione(evento) : null,
          icon: Icon(iscritto ? Icons.event_busy : Icons.event_available),
          label: Text(iscritto ? 'Annulla iscrizione' : 'Iscriviti'),
        ),
        if (!aperte)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('Le iscrizioni non sono aperte.'),
          ),
        if (iscritto &&
            evento['questionario_gradimento_attivo'] == true &&
            _testo(evento['link_questionario_gradimento']).isNotEmpty) ...[
          const SizedBox(height: 16),
          const Text(
            'Questionario di gradimento',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SelectableText(_testo(evento['link_questionario_gradimento'])),
        ],
        if (controller.puoGestire) ...[
          const Divider(height: 32),
          Wrap(
            spacing: 8,
            children: <Widget>[
              OutlinedButton.icon(
                onPressed: () => _apriEditor(evento),
                icon: const Icon(Icons.edit),
                label: const Text('Modifica'),
              ),
              OutlinedButton.icon(
                onPressed: () => _elimina(evento),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Elimina'),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Future<void> _cambiaIscrizione(Map<String, dynamic> evento) async {
    final errore = await controller.cambiaIscrizione(evento);
    if (mounted && errore != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore)));
    }
  }

  Future<void> _apriEditor([Map<String, dynamic>? evento]) async {
    final iniziali =
        evento ??
        <String, dynamic>{
          'titolo': '',
          'anno_accademico': controller.anniAccademici.isEmpty
              ? null
              : controller.anniAccademici.first,
          'tipologia': 'Altro',
          'modalita': 'In presenza',
          'questionario_gradimento_attivo': false,
        };
    final risultato = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazione,
      valoriIniziali: iniziali,
      partecipante: _partecipante,
      titolo: evento == null ? 'Nuovo evento' : 'Modifica evento',
    );
    if (risultato == null) return;
    final errore = await controller.salva(
      id: evento?['id']?.toString(),
      dati: risultato,
    );
    if (mounted && errore != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore)));
    }
  }

  Future<void> _elimina(Map<String, dynamic> evento) async {
    final conferma =
        await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Eliminare l’evento?'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Sì'),
              ),
            ],
          ),
        ) ??
        false;
    if (!conferma) return;
    final errore = await controller.elimina(evento['id'].toString());
    if (mounted && errore != null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errore)));
    }
  }
}

String _testo(Object? valore) => valore?.toString().trim() ?? '';

String _data(Object? valore) {
  final data = DateTime.tryParse(_testo(valore));
  if (data == null) return _testo(valore);
  return '${data.day.toString().padLeft(2, '0')}/'
      '${data.month.toString().padLeft(2, '0')}/${data.year}';
}
