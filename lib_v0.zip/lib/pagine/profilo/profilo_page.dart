import 'package:flutter/material.dart';

import '../../app_exception.dart';
import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_scheda_page.dart';
import 'profilo_controller.dart';

class ProfiloPage extends StatefulWidget {
  const ProfiloPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<ProfiloPage> createState() => _ProfiloPageState();
}

class _ProfiloPageState extends State<ProfiloPage> {
  static const _ruoliAccademici = <String>[
    'PO',
    'PA',
    'RU',
    'RTT',
    'RTDb',
    'RTDa',
    'altro',
  ];
  static const _fasceEta = <String>[
    '<35',
    '35-40',
    '41-50',
    '51-60',
    '61-70',
    '>70',
  ];

  late final ProfiloController _controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  ConfigurazionePaginaDinamica get _configurazione =>
      ConfigurazionePaginaDinamica(
        tabella: 'anagrafica',
        campi: <String, PersonalizzazioneCampo>{
          'user_id': const PersonalizzazioneCampo(nascosto: true),
          'email_unipa': const PersonalizzazioneCampo(
            etichetta: 'Email UNIPA',
            modificabilePartecipante: false,
          ),
          'cognome': const PersonalizzazioneCampo(etichetta: 'Cognome'),
          'nome': const PersonalizzazioneCampo(etichetta: 'Nome'),
          'cod_ssd': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'SSD',
            valoriScelta: _controller.ssd
                .map((riga) => riga['cod_ssd'].toString())
                .toList(growable: false),
          ),
          'dipartimento': const PersonalizzazioneCampo(
            etichetta: 'Dipartimento',
          ),
          'ufficio': const PersonalizzazioneCampo(etichetta: 'Ufficio'),
          'ruolo_accademico': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Ruolo accademico',
            valoriScelta: _ruoliAccademici,
          ),
          'cellulare': const PersonalizzazioneCampo(etichetta: 'Cellulare'),
          'fascia_eta': const PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Fascia d’età',
            valoriScelta: _fasceEta,
          ),
          'pagina_personale_unipa': const PersonalizzazioneCampo(
            etichetta: 'Pagina personale UNIPA',
          ),
          'anno_prima_partecipazione': PersonalizzazioneCampo(
            tipo: TipoCampoDinamico.scelta,
            etichetta: 'Prima partecipazione',
            valoriScelta: _controller.anniAccademici,
          ),
        },
      );

  @override
  void initState() {
    super.initState();
    _controller = ProfiloController(sessione: widget.sessione)..carica();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) {
      final profilo = _controller.profilo;
      return TemplatePaginaScheda(
        titolo: 'Il mio profilo',
        caricamento: _controller.caricamento && profilo == null,
        errore: _controller.errore,
        vuoto: profilo == null,
        messaggioVuoto: 'Profilo non trovato.',
        azioni: <Widget>[
          if (_controller.puoModificare)
            FilledButton.icon(
              onPressed: _controller.salvataggio ? null : _apriEditor,
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Modifica'),
            )
          else
            OutlinedButton.icon(
              onPressed: _controller.richiediModifica,
              icon: const Icon(Icons.lock_open_outlined),
              label: const Text('Richiedi modifica'),
            ),
        ],
        contenuto: profilo == null
            ? const SizedBox.shrink()
            : CampiTabellaDinamici(
                configurazione: _configurazione,
                valori: profilo,
                partecipante: _partecipante,
              ),
      );
    },
  );

  Future<void> _apriEditor() async {
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: _configurazione,
      valoriIniziali: _controller.profilo!,
      partecipante: _partecipante,
      titolo: 'Modifica profilo',
    );
    if (valori == null) return;
    try {
      await _controller.salva(valori);
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }
}
