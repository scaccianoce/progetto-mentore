import 'package:flutter/material.dart';

import '../../app_exception.dart';
import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_elenco_dettaglio_page.dart';
import 'news_controller.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  static const configurazione = ConfigurazionePaginaDinamica(
    tabella: 'news',
    campi: <String, PersonalizzazioneCampo>{
      'id': PersonalizzazioneCampo(nascosto: true),
      'titolo': PersonalizzazioneCampo(
        etichetta: 'Titolo',
        modificabilePartecipante: false,
      ),
      'testo': PersonalizzazioneCampo(
        tipo: TipoCampoDinamico.testoFormattato,
        etichetta: 'Testo',
        modificabilePartecipante: false,
      ),
      'data_pubblicazione': PersonalizzazioneCampo(
        etichetta: 'Data pubblicazione',
        modificabilePartecipante: false,
      ),
      'attiva': PersonalizzazioneCampo(
        etichetta: 'Attiva',
        visibilePartecipante: false,
        modificabilePartecipante: false,
      ),
    },
  );

  late final NewsController _controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  @override
  void initState() {
    super.initState();
    _controller = NewsController(
      ruolo: widget.sessione.ruolo ?? AppRole.participant,
    );
    _controller.carica();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => TemplatePaginaElencoDettaglio(
        caricamento: _controller.caricamento && _controller.news.isEmpty,
        errore: _controller.errore,
        vuoto: _controller.news.isEmpty,
        messaggioVuoto: 'Nessuna news disponibile.',
        larghezzaElenco: 340,
        intestazione: _IntestazioneNews(
          puoGestire: _controller.puoGestire,
          caricamento: _controller.caricamento,
          onAggiorna: _controller.carica,
          onNuova: () => _apriEditor(),
        ),
        elenco: _ElencoNews(
          news: _controller.news,
          selezionata: _controller.selezionata,
          onSeleziona: _controller.seleziona,
        ),
        dettaglio: _DettaglioNews(
          news: _controller.selezionata,
          puoGestire: _controller.puoGestire,
          partecipante: _partecipante,
          configurazione: configurazione,
          onModifica: _controller.selezionata == null
              ? null
              : () => _apriEditor(esistente: _controller.selezionata),
          onElimina: _controller.selezionata == null
              ? null
              : () => _confermaEliminazione(_controller.selezionata!),
        ),
      ),
    );
  }

  Future<void> _apriEditor({News? esistente}) async {
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: configurazione,
      partecipante: _partecipante,
      valoriIniziali:
          esistente?.toMap() ??
          <String, dynamic>{
            'titolo': '',
            'testo': null,
            'data_pubblicazione': DateTime.now()
                .toIso8601String()
                .split('T')
                .first,
            'attiva': true,
          },
      titolo: esistente == null ? 'Nuova news' : 'Modifica news',
    );
    if (valori == null) return;
    try {
      await _controller.salva(
        esistente: esistente,
        titolo: valori['titolo']?.toString() ?? '',
        testo: valori['testo']?.toString() ?? '',
        dataPubblicazione:
            DateTime.tryParse(valori['data_pubblicazione']?.toString() ?? '') ??
            DateTime.now(),
        attiva: valori['attiva'] == true,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('News salvata.')));
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }

  Future<void> _confermaEliminazione(News news) async {
    final bool? confermata = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Eliminare la news?'),
          content: Text('La news “${news.titolo}” verrà eliminata.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Annulla'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Elimina'),
            ),
          ],
        );
      },
    );

    if (confermata != true) {
      return;
    }

    try {
      await _controller.elimina(news);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('News eliminata.')));
      }
    } on AppException catch (errore) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(errore.messaggio)));
      }
    }
  }
}

class _IntestazioneNews extends StatelessWidget {
  const _IntestazioneNews({
    required this.puoGestire,
    required this.caricamento,
    required this.onAggiorna,
    required this.onNuova,
  });

  final bool puoGestire;
  final bool caricamento;
  final VoidCallback onAggiorna;
  final VoidCallback onNuova;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Text('News', style: Theme.of(context).textTheme.headlineSmall),
        ),
        IconButton(
          tooltip: 'Aggiorna',
          onPressed: caricamento ? null : onAggiorna,
          icon: const Icon(Icons.refresh),
        ),
        if (puoGestire)
          FilledButton.icon(
            onPressed: caricamento ? null : onNuova,
            icon: const Icon(Icons.add),
            label: const Text('Nuova'),
          ),
      ],
    );
  }
}

class _ElencoNews extends StatelessWidget {
  const _ElencoNews({
    required this.news,
    required this.selezionata,
    required this.onSeleziona,
  });

  final List<News> news;
  final News? selezionata;
  final ValueChanged<News> onSeleziona;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: ListView.separated(
        itemCount: news.length,
        separatorBuilder: (_, _) => const Divider(height: 1),
        itemBuilder: (BuildContext context, int index) {
          final News elemento = news[index];
          return ListTile(
            selected: elemento.id == selezionata?.id,
            title: Text(
              elemento.titolo,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(_formattaData(elemento.dataPubblicazione)),
            trailing: elemento.attiva
                ? null
                : const Tooltip(
                    message: 'News non attiva',
                    child: Icon(Icons.visibility_off_outlined),
                  ),
            onTap: () => onSeleziona(elemento),
          );
        },
      ),
    );
  }
}

class _DettaglioNews extends StatelessWidget {
  const _DettaglioNews({
    required this.news,
    required this.puoGestire,
    required this.partecipante,
    required this.configurazione,
    required this.onModifica,
    required this.onElimina,
  });

  final News? news;
  final bool puoGestire;
  final bool partecipante;
  final ConfigurazionePaginaDinamica configurazione;
  final VoidCallback? onModifica;
  final VoidCallback? onElimina;

  @override
  Widget build(BuildContext context) {
    final News? elemento = news;
    if (elemento == null) {
      return const Center(child: Text('Seleziona una news.'));
    }

    return Card(
      margin: EdgeInsets.zero,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Text(
                    'News',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                ),
                if (puoGestire) ...<Widget>[
                  IconButton(
                    tooltip: 'Modifica',
                    onPressed: onModifica,
                    icon: const Icon(Icons.edit_outlined),
                  ),
                  IconButton(
                    tooltip: 'Elimina',
                    onPressed: onElimina,
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ],
            ),
            const Divider(height: 32),
            CampiTabellaDinamici(
              configurazione: configurazione,
              valori: elemento.toMap(),
              partecipante: partecipante,
            ),
          ],
        ),
      ),
    );
  }
}

String _formattaData(DateTime? data) {
  if (data == null) {
    return 'Data non indicata';
  }
  String dueCifre(int valore) => valore.toString().padLeft(2, '0');
  return '${dueCifre(data.day)}/${dueCifre(data.month)}/${data.year}';
}
