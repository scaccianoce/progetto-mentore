import 'package:flutter/material.dart';

import '../../dinamico/maschera_dinamica_controller.dart';
import '../../dinamico/maschera_dinamica_widget.dart';
import '../../sessione_controller.dart';
import '../template/template_elenco_dettaglio_page.dart';
import 'contatti_controller.dart';

class ContattiPage extends StatefulWidget {
  const ContattiPage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<ContattiPage> createState() => _ContattiPageState();
}

class _ContattiPageState extends State<ContattiPage> {
  static const configurazione = ConfigurazionePaginaDinamica(
    tabella: 'anagrafica',
    campi: <String, PersonalizzazioneCampo>{
      'user_id': PersonalizzazioneCampo(nascosto: true),
      'nome': PersonalizzazioneCampo(nascosto: true),
      'cognome': PersonalizzazioneCampo(nascosto: true),
      'email_unipa': PersonalizzazioneCampo(
        etichetta: 'Email',
        modificabilePartecipante: false,
      ),
      'cellulare': PersonalizzazioneCampo(
        etichetta: 'Cellulare',
        modificabilePartecipante: false,
      ),
      'cod_ssd': PersonalizzazioneCampo(
        etichetta: 'SSD',
        modificabilePartecipante: false,
      ),
      'ruolo_accademico': PersonalizzazioneCampo(
        etichetta: 'Ruolo accademico',
        modificabilePartecipante: false,
      ),
      'dipartimento': PersonalizzazioneCampo(
        etichetta: 'Dipartimento',
        modificabilePartecipante: false,
      ),
      'ufficio': PersonalizzazioneCampo(
        etichetta: 'Ufficio',
        modificabilePartecipante: false,
      ),
      'pagina_personale_unipa': PersonalizzazioneCampo(
        etichetta: 'Pagina personale',
        modificabilePartecipante: false,
      ),
    },
  );

  late final ContattiController _controller;

  bool get _partecipante => widget.sessione.ruolo == AppRole.participant;

  @override
  void initState() {
    super.initState();
    _controller = ContattiController()..carica();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) => TemplatePaginaElencoDettaglio(
      caricamento: _controller.caricamento && _controller.contatti.isEmpty,
      errore: _controller.errore,
      vuoto: _controller.contatti.isEmpty,
      messaggioVuoto: 'Nessun contatto disponibile.',
      intestazione: TextField(
        onChanged: _controller.cerca,
        decoration: const InputDecoration(
          labelText: 'Cerca per nome, email o SSD',
          prefixIcon: Icon(Icons.search),
          border: OutlineInputBorder(),
        ),
      ),
      elenco: Card(
        margin: EdgeInsets.zero,
        child: ListView.builder(
          itemCount: _controller.contatti.length,
          itemBuilder: (context, index) {
            final contatto = _controller.contatti[index];
            return ListTile(
              selected:
                  contatto['user_id'] == _controller.selezionato?['user_id'],
              leading: const CircleAvatar(child: Icon(Icons.person_outline)),
              title: Text(
                '${contatto['cognome'] ?? ''} ${contatto['nome'] ?? ''}'.trim(),
              ),
              subtitle: Text(contatto['email_unipa']?.toString() ?? ''),
              onTap: () => _controller.seleziona(contatto),
            );
          },
        ),
      ),
      dettaglio: _dettaglio(),
    ),
  );

  Widget _dettaglio() {
    final contatto = _controller.selezionato;
    if (contatto == null) {
      return const Center(child: Text('Seleziona un contatto.'));
    }
    final nome = '${contatto['nome'] ?? ''} ${contatto['cognome'] ?? ''}'
        .trim();
    return Card(
      margin: EdgeInsets.zero,
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: <Widget>[
          Text(nome, style: Theme.of(context).textTheme.headlineSmall),
          const Divider(height: 28),
          CampiTabellaDinamici(
            configurazione: configurazione,
            valori: contatto,
            partecipante: _partecipante,
          ),
        ],
      ),
    );
  }
}
