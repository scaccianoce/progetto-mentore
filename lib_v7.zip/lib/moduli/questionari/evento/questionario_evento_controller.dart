import 'package:flutter/foundation.dart';

import '../../../app/app_core.dart';
import '../../../app/app_session_controller.dart';
import '../../../dati/questionari_repository.dart';

class QuestionarioEventoController extends ChangeNotifier {
  QuestionarioEventoController(
    this.sessione, {
    QuestionariRepository? repository,
  }) : repository = repository ?? QuestionariRepository();

  final SessioneController sessione;
  final QuestionariRepository repository;

  final List<Map<String, dynamic>> template = <Map<String, dynamic>>[];
  final List<Map<String, dynamic>> questionari = <Map<String, dynamic>>[];

  bool caricamento = false;
  String? errore;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();
    try {
      final dati = await repository.caricaCatalogo();
      template
        ..clear()
        ..addAll(dati.template);
      questionari
        ..clear()
        ..addAll(dati.questionari);
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i questionari evento.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  List<Map<String, dynamic>> templatePer(String destinatario) => template
      .where(
        (riga) =>
            riga['destinatario']?.toString() == destinatario &&
            riga['attivo'] != false,
      )
      .toList(growable: false);

  Map<String, dynamic>? questionarioEvento(String eventoId) {
    for (final questionario in questionari) {
      if (questionario['provider']?.toString() == 'interno' &&
          questionario['evento_id']?.toString() == eventoId) {
        return questionario;
      }
    }
    return null;
  }

  Future<String?> creaQuestionarioEvento({
    required String eventoId,
    required String templateId,
    required String titolo,
  }) => _esegui(() async {
    if (!puoGestire) {
      throw const AppException('Operazione non autorizzata.');
    }
    await repository.creaQuestionarioEvento(
      eventoId: eventoId,
      templateId: templateId,
      titolo: titolo,
    );
  });

  Future<Map<String, dynamic>?> caricaQuestionarioEvento(String eventoId) =>
      repository.caricaQuestionarioEvento(eventoId);

  Future<String?> inviaQuestionarioInterno({
    required String questionarioId,
    required Map<String, dynamic> risposte,
  }) async {
    try {
      if (await repository.questionarioGiaCompilato(questionarioId)) {
        throw const AppException('Hai già compilato questo questionario.');
      }
      final compilazioneId = await repository.creaCompilazioneInterna(
        questionarioId,
      );
      try {
        await repository.inserisciRisposte(compilazioneId, risposte);
      } catch (_) {
        await repository.eliminaCompilazione(compilazioneId);
        rethrow;
      }
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile inviare il questionario.',
      ).messaggio;
    }
  }

  Future<String?> _esegui(Future<void> Function() azione) async {
    try {
      await azione();
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Operazione sul questionario evento non riuscita.',
      ).messaggio;
    }
  }
}
