import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../app/app_core.dart';
import '../../dati/questionari_repository.dart';

class QuestionarioPubblicoController extends ChangeNotifier {
  QuestionarioPubblicoController({QuestionariRepository? repository})
    : repository =
          repository ??
          QuestionariRepository(
            client: SupabaseClient(
              AppConfig.supabaseUrl,
              AppConfig.supabasePublishableKey,
              authOptions: const AuthClientOptions(autoRefreshToken: false),
            ),
          );

  final QuestionariRepository repository;

  Map<String, dynamic>? dati;
  bool caricamento = true;
  bool invio = false;
  bool completato = false;
  String? errore;

  Future<void> carica(String token) async {
    caricamento = true;
    errore = null;
    notifyListeners();
    try {
      dati = await repository.caricaQuestionarioPubblico(token);
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Questionario non disponibile.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  Future<String?> invia(String token, Map<String, dynamic> risposte) async {
    invio = true;
    notifyListeners();
    try {
      await repository.inviaQuestionarioPubblico(token, risposte);
      completato = true;
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Invio del questionario non riuscito.',
      ).messaggio;
    } finally {
      invio = false;
      notifyListeners();
    }
  }
}
