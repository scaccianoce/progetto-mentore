/// Controller della pagina News.
/// La migrazione della logica CRUD dinamica avverrà senza modificare la UI.
class NewsController {
  const NewsController();
}
