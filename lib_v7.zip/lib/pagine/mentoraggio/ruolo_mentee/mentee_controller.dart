import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../app/app_core.dart';
import '../../../dati/repository.dart';

class PercorsoMentee {
  const PercorsoMentee({
    required this.insegnamento,
    required this.mentoraggio,
    required this.mentori,
    required this.annoCorrente,
    required this.sintesiQuestionario,
  });

  final Map<String, dynamic> insegnamento;
  final Map<String, dynamic> mentoraggio;
  final List<Map<String, dynamic>> mentori;
  final bool annoCorrente;
  final Map<String, dynamic>? sintesiQuestionario;
}

class MenteeController extends ChangeNotifier {
  MenteeController({
    SupabaseClient? client,
    MentoraggiRepository? repository,
  }) : _repository = repository ??
            MentoraggiRepository(
              RepositoryComune(client: client),
            );

  final MentoraggiRepository _repository;

  List<PercorsoMentee> percorsi = const <PercorsoMentee>[];
  PercorsoMentee? selezionato;
  String? annoCorrente;
  bool caricamento = false;
  bool salvataggio = false;
  String? errore;

  Future<void> carica() async {
    final userId = _repository.userIdCorrente;
    if (userId == null) return;

    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      annoCorrente = await _repository.annoAccademicoCorrente();

      final risultati = await Future.wait<dynamic>(<Future<dynamic>>[
        _repository.insegnamentiDelDocente(userId),
        _repository.mentoraggiDelMentee(),
      ]);

      final insegnamenti =
          risultati[0] as List<Map<String, dynamic>>;
      final mentoraggi =
          risultati[1] as List<Map<String, dynamic>>;

      final insegnamentiPerId = <String, Map<String, dynamic>>{
        for (final insegnamento in insegnamenti)
          insegnamento['id'].toString(): insegnamento,
      };

      final mentoraggioIds = mentoraggi
          .map((m) => m['id']?.toString())
          .whereType<String>()
          .toList(growable: false);

      final assegnazioni =
          await _repository.assegnazioniPerMentoraggi(mentoraggioIds);

      final personeIds = assegnazioni
          .map((a) => a['mentore_id']?.toString())
          .whereType<String>()
          .toSet()
          .toList(growable: false);

      final persone = await _repository.anagrafiche(
        personeIds,
        includiCellulare: true,
      );

      final personePerId = <String, Map<String, dynamic>>{
        for (final persona in persone)
          persona['user_id'].toString(): persona,
      };

      final risultato = <PercorsoMentee>[];

      for (final mentoraggio in mentoraggi) {
        final insegnamento = insegnamentiPerId[
          mentoraggio['insegnamento_id']?.toString()
        ];
        if (insegnamento == null) continue;

        final mentoraggioId = mentoraggio['id']?.toString();
        final team = assegnazioni
            .where(
              (a) => a['mentoraggio_id']?.toString() == mentoraggioId,
            )
            .map((a) {
              final persona = personePerId[
                    a['mentore_id']?.toString()
                  ] ??
                  <String, dynamic>{};
              return <String, dynamic>{
                ...persona,
                'tipo': a['tipo'],
              };
            })
            .toList(growable: false)
          ..sort(_confrontaTeam);

        Map<String, dynamic>? sintesiQuestionario;
        if (mentoraggioId != null) {
          try {
            sintesiQuestionario =
                await _repository.sintesiQuestionario(mentoraggioId);
          } catch (_) {
            // Il percorso resta visibile anche senza questionario.
          }
        }

        risultato.add(
          PercorsoMentee(
            insegnamento: insegnamento,
            mentoraggio: mentoraggio,
            mentori: team,
            annoCorrente:
                mentoraggio['anno_accademico']?.toString() == annoCorrente,
            sintesiQuestionario: sintesiQuestionario,
          ),
        );
      }

      risultato.sort(_confrontaPercorsi);
      percorsi = risultato;
      _ripristinaSelezione();
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i mentoraggi da mentee.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  void seleziona(PercorsoMentee percorso) {
    selezionato = percorso;
    notifyListeners();
  }

  Future<void> salva(Map<String, dynamic> valori) async {
    final percorso = selezionato;
    if (percorso == null || !percorso.annoCorrente) {
      throw const AppException('Questo mentoraggio e in sola lettura.');
    }

    salvataggio = true;
    notifyListeners();

    try {
      const consentiti = <String>{
        'data_inizio',
        'data_fine',
        'numero_studenti',
        'sede',
        'note',
        'svolgimento',
        'giorni_orari_lezioni',
      };

      final patch = <String, dynamic>{
        for (final entry in valori.entries)
          if (consentiti.contains(entry.key)) entry.key: entry.value,
      };

      await _repository.aggiornaComeMentee(
        percorso.mentoraggio['id'].toString(),
        patch,
      );
      await carica();
    } catch (e) {
      throw AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile aggiornare il mentoraggio.',
      );
    } finally {
      salvataggio = false;
      notifyListeners();
    }
  }

  void _ripristinaSelezione() {
    final idSelezionato = selezionato?.mentoraggio['id']?.toString();
    if (idSelezionato == null ||
        !percorsi.any(
          (p) => p.mentoraggio['id']?.toString() == idSelezionato,
        )) {
      selezionato = percorsi.isEmpty ? null : percorsi.first;
      return;
    }

    selezionato = percorsi.firstWhere(
      (p) => p.mentoraggio['id']?.toString() == idSelezionato,
    );
  }

  static int _confrontaTeam(
    Map<String, dynamic> a,
    Map<String, dynamic> b,
  ) {
    final seniorA = a['tipo']?.toString().toLowerCase() == 'senior';
    final seniorB = b['tipo']?.toString().toLowerCase() == 'senior';
    if (seniorA != seniorB) return seniorA ? 1 : -1;
    return '${a['cognome'] ?? ''} ${a['nome'] ?? ''}'
        .compareTo('${b['cognome'] ?? ''} ${b['nome'] ?? ''}');
  }

  static int _confrontaPercorsi(PercorsoMentee a, PercorsoMentee b) {
    final confrontoAnno =
        (b.mentoraggio['anno_accademico']?.toString() ?? '')
            .compareTo(a.mentoraggio['anno_accademico']?.toString() ?? '');
    if (confrontoAnno != 0) return confrontoAnno;
    return (a.insegnamento['insegnamento']?.toString() ?? '')
        .compareTo(b.insegnamento['insegnamento']?.toString() ?? '');
  }
}
