import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../app/app_core.dart';
import '../../../dati/repository.dart';

class PercorsoMentore {
  const PercorsoMentore({
    required this.mentoraggio,
    required this.insegnamento,
    required this.docente,
    required this.team,
    required this.annoCorrente,
    required this.mioRuolo,
  });

  final Map<String, dynamic> mentoraggio;
  final Map<String, dynamic> insegnamento;
  final Map<String, dynamic> docente;
  final List<Map<String, dynamic>> team;
  final bool annoCorrente;
  final String mioRuolo;
}

class MentoreController extends ChangeNotifier {
  MentoreController({
    SupabaseClient? client,
    MentoraggiRepository? repository,
  }) : _repository = repository ??
            MentoraggiRepository(
              RepositoryComune(client: client),
            );

  final MentoraggiRepository _repository;

  List<PercorsoMentore> percorsi = const <PercorsoMentore>[];
  PercorsoMentore? selezionato;
  String? annoCorrente;
  bool caricamento = false;
  bool salvataggio = false;
  String? errore;

  Future<void> carica() async {
    final userId = _repository.userIdCorrente;
    if (userId == null) return;

    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      annoCorrente = await _repository.annoAccademicoCorrente();

      final mieAssegnazioni =
          await _repository.assegnazioniDelMentore(userId);
      if (mieAssegnazioni.isEmpty) {
        percorsi = const <PercorsoMentore>[];
        selezionato = null;
        return;
      }

      final mentoraggi = await _repository.mentoraggiDelMentore();

      final insegnamentoIds = mentoraggi
          .map((m) => m['insegnamento_id']?.toString())
          .whereType<String>()
          .toSet()
          .toList(growable: false);

      final insegnamenti =
          await _repository.insegnamentiPerId(insegnamentoIds);
      final insegnamentiPerId = <String, Map<String, dynamic>>{
        for (final insegnamento in insegnamenti)
          insegnamento['id'].toString(): insegnamento,
      };

      final docentiIds = insegnamenti
          .map((i) => i['docente_id']?.toString())
          .whereType<String>()
          .toSet()
          .toList(growable: false);
      final docenti = await _repository.anagrafiche(
        docentiIds,
        includiCellulare: true,
      );
      final docentiPerId = <String, Map<String, dynamic>>{
        for (final docente in docenti)
          docente['user_id'].toString(): docente,
      };

      final mentoraggioIds = mentoraggi
          .map((m) => m['id']?.toString())
          .whereType<String>()
          .toList(growable: false);
      final assegnazioni =
          await _repository.assegnazioniPerMentoraggi(mentoraggioIds);

      final teamIds = assegnazioni
          .map((a) => a['mentore_id']?.toString())
          .whereType<String>()
          .toSet()
          .toList(growable: false);
      final persone = await _repository.anagrafiche(teamIds);
      final personePerId = <String, Map<String, dynamic>>{
        for (final persona in persone)
          persona['user_id'].toString(): persona,
      };

      final risultato = <PercorsoMentore>[];

      for (final mentoraggio in mentoraggi) {
        final insegnamento = insegnamentiPerId[
          mentoraggio['insegnamento_id']?.toString()
        ];
        if (insegnamento == null) continue;

        final mentoraggioId = mentoraggio['id']?.toString();
        final assegnati = assegnazioni
            .where(
              (a) => a['mentoraggio_id']?.toString() == mentoraggioId,
            )
            .toList(growable: false);

        final miaAssegnazione = assegnati.firstWhere(
          (a) => a['mentore_id']?.toString() == userId,
          orElse: () => <String, dynamic>{},
        );

        final team = assegnati.map((a) {
          final persona = personePerId[a['mentore_id']?.toString()] ??
              <String, dynamic>{};
          return <String, dynamic>{
            ...persona,
            'tipo': a['tipo'],
          };
        }).toList(growable: false)
          ..sort(_confrontaTeam);

        risultato.add(
          PercorsoMentore(
            mentoraggio: mentoraggio,
            insegnamento: insegnamento,
            docente: docentiPerId[
                  insegnamento['docente_id']?.toString()
                ] ??
                <String, dynamic>{},
            team: team,
            annoCorrente:
                mentoraggio['anno_accademico']?.toString() == annoCorrente,
            mioRuolo: miaAssegnazione['tipo']?.toString() ?? '',
          ),
        );
      }

      risultato.sort(_confrontaPercorsi);
      percorsi = risultato;
      _ripristinaSelezione();
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i mentoraggi assegnati.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  void seleziona(PercorsoMentore valore) {
    selezionato = valore;
    notifyListeners();
  }

  Future<void> salvaMentoraggio(Map<String, dynamic> valori) async {
    final percorso = selezionato;
    if (percorso == null || !percorso.annoCorrente) {
      throw const AppException('Questo mentoraggio e in sola lettura.');
    }

    salvataggio = true;
    notifyListeners();

    try {
      const esclusi = <String>{
        'id',
        'insegnamento_id',
        'anno_accademico',
        'data_inizio',
        'data_fine',
        'numero_studenti',
        'sede',
        'note',
        'svolgimento',
        'giorni_orari_lezioni',
        'scheda_sintesi_pdf_url',
        'created_at',
        'updated_at',
      };

      final patch = <String, dynamic>{
        for (final entry in valori.entries)
          if (!esclusi.contains(entry.key)) entry.key: entry.value,
      };

      await _repository.aggiornaComeMentore(
        percorso.mentoraggio['id'].toString(),
        patch,
      );
      await carica();
    } catch (e) {
      throw AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile salvare il mentoraggio.',
      );
    } finally {
      salvataggio = false;
      notifyListeners();
    }
  }

  void _ripristinaSelezione() {
    final idSelezionato = selezionato?.mentoraggio['id']?.toString();
    if (idSelezionato == null ||
        !percorsi.any(
          (p) => p.mentoraggio['id']?.toString() == idSelezionato,
        )) {
      selezionato = percorsi.isEmpty ? null : percorsi.first;
      return;
    }

    selezionato = percorsi.firstWhere(
      (p) => p.mentoraggio['id']?.toString() == idSelezionato,
    );
  }

  static int _confrontaTeam(
    Map<String, dynamic> a,
    Map<String, dynamic> b,
  ) {
    final seniorA = a['tipo']?.toString().toLowerCase() == 'senior';
    final seniorB = b['tipo']?.toString().toLowerCase() == 'senior';
    if (seniorA != seniorB) return seniorA ? 1 : -1;
    return '${a['cognome'] ?? ''} ${a['nome'] ?? ''}'
        .compareTo('${b['cognome'] ?? ''} ${b['nome'] ?? ''}');
  }

  static int _confrontaPercorsi(PercorsoMentore a, PercorsoMentore b) {
    final confrontoAnno =
        (b.mentoraggio['anno_accademico']?.toString() ?? '')
            .compareTo(a.mentoraggio['anno_accademico']?.toString() ?? '');
    if (confrontoAnno != 0) return confrontoAnno;
    return (a.insegnamento['insegnamento']?.toString() ?? '')
        .compareTo(b.insegnamento['insegnamento']?.toString() ?? '');
  }
}
