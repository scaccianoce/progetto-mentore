import '../../../dati/repository.dart';

/// Controller dedicato alla relativa pagina di backoffice.
/// La UI non accede direttamente al repository condiviso.
class PartecipantiBackofficeController extends BackofficeRepository {
  PartecipantiBackofficeController(super.sessione);
}
