/// Controller dedicato alla pagina.
/// In questa prima fase strutturale resta intenzionalmente minimale: la grafica
/// e la logica esistente della pagina non vengono alterate.
class NotificheBackofficeController {
  const NotificheBackofficeController();
}
