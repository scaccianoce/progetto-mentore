import '../../../dati/repository.dart';

/// Controller dedicato alla relativa pagina di backoffice.
/// La UI non accede direttamente al repository condiviso.
class InsegnamentiBackofficeController extends BackofficeRepository {
  InsegnamentiBackofficeController(super.sessione);
}
