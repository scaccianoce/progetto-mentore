String campoCsv(Object? valore) {
  final testo = valore?.toString() ?? '';
  return '"${testo.replaceAll('"', '""')}"';
}
