String nomeFileSicuro(String valore, {bool consentiPunto = true}) {
  final espressione = consentiPunto
      ? RegExp(r'[^A-Za-z0-9._-]+')
      : RegExp(r'[^A-Za-z0-9_-]+');
  return valore.replaceAll(espressione, '_');
}
