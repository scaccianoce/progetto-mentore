List<Map<String, dynamic>> mappeDa(Object? valore) {
  if (valore is! List) return const <Map<String, dynamic>>[];
  return valore
      .whereType<Map>()
      .map((riga) => Map<String, dynamic>.from(riga))
      .toList(growable: false);
}

List<String> idsUnivoci(
  List<Map<String, dynamic>> righe,
  String campo,
) => righe
    .map((riga) => riga[campo]?.toString())
    .whereType<String>()
    .where((valore) => valore.isNotEmpty && valore != 'null')
    .toSet()
    .toList(growable: false);

String testoDa(Object? valore) => valore?.toString().trim() ?? '';
