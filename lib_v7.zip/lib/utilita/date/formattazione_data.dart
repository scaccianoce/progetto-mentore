DateTime? dataDa(Object? valore) {
  if (valore is DateTime) return valore;
  final testo = valore?.toString().trim() ?? '';
  return testo.isEmpty ? null : DateTime.tryParse(testo);
}

String formattaData(
  Object? valore, {
  String valoreAssente = '—',
  bool mantieniValoreNonValido = false,
  bool locale = false,
}) {
  var data = dataDa(valore);
  if (data == null) {
    final originale = valore?.toString().trim() ?? '';
    return mantieniValoreNonValido && originale.isNotEmpty
        ? originale
        : valoreAssente;
  }
  if (locale) data = data.toLocal();
  return '${_dueCifre(data.day)}/${_dueCifre(data.month)}/${data.year}';
}

String formattaDataOra(
  Object? valore, {
  String valoreAssente = '—',
  bool mantieniValoreNonValido = false,
  bool locale = false,
}) {
  var data = dataDa(valore);
  if (data == null) {
    final originale = valore?.toString().trim() ?? '';
    return mantieniValoreNonValido && originale.isNotEmpty
        ? originale
        : valoreAssente;
  }
  if (locale) data = data.toLocal();
  return '${formattaData(data)} ${_dueCifre(data.hour)}:${_dueCifre(data.minute)}';
}

String? dataIso(DateTime? data) => data?.toIso8601String().split('T').first;

String _dueCifre(int valore) => valore.toString().padLeft(2, '0');
