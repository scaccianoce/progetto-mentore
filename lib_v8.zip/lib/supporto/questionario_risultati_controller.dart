import '../app/app_core.dart';
import '../app/app_session_controller.dart';
import '../dati/questionari_repository.dart';
import 'questionario_csv_service.dart';

class QuestionarioRisultatiController {
  QuestionarioRisultatiController(
    this.sessione, {
    QuestionariRepository? repository,
    QuestionarioCsvService? csvService,
  }) : repository = repository ?? QuestionariRepository(),
       csvService = csvService ?? const QuestionarioCsvService();

  final SessioneController sessione;
  final QuestionariRepository repository;
  final QuestionarioCsvService csvService;

  bool get puoGestire => sessione.ruolo?.puoAmministrare ?? false;

  Future<Map<String, dynamic>> caricaRisultatiQuestionario(
    String questionarioId,
  ) async {
    if (!puoGestire) {
      throw const AppException('Operazione non autorizzata.');
    }
    final dati = await repository.caricaRisultati(questionarioId);
    final domande = (dati['domande'] as List).cast<Map<String, dynamic>>();
    final risposte = (dati['risposte'] as List).cast<Map<String, dynamic>>();
    dati['sintesi'] = <Map<String, dynamic>>[
      for (final domanda in domande)
        _sintesiDomanda(
          domanda,
          risposte
              .where(
                (riga) =>
                    riga['domanda_id']?.toString() == domanda['id'].toString(),
              )
              .map((riga) => riga['valore'])
              .where((valore) => valore != null)
              .toList(growable: false),
        ),
    ];
    return dati;
  }

  Future<String?> esportaCsvRisultati(String questionarioId) async {
    try {
      await csvService.esporta(
        await caricaRisultatiQuestionario(questionarioId),
      );
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile esportare i risultati CSV.',
      ).messaggio;
    }
  }

  Map<String, dynamic> _sintesiDomanda(
    Map<String, dynamic> domanda,
    List<dynamic> valori,
  ) {
    final tipo = domanda['tipo']?.toString() ?? '';
    if (tipo == 'scala') {
      final numeri = valori
          .map((valore) => double.tryParse(valore.toString()))
          .whereType<double>()
          .toList();
      return <String, dynamic>{
        ...domanda,
        'numero_risposte': numeri.length,
        'media': numeri.isEmpty
            ? null
            : numeri.reduce((a, b) => a + b) / numeri.length,
      };
    }
    if (tipo == 'booleano' || tipo == 'scelta_singola') {
      final frequenze = <String, int>{};
      for (final valore in valori) {
        final chiave = valore is bool
            ? (valore ? 'Sì' : 'No')
            : valore.toString();
        frequenze[chiave] = (frequenze[chiave] ?? 0) + 1;
      }
      return <String, dynamic>{
        ...domanda,
        'numero_risposte': valori.length,
        'frequenze': frequenze,
      };
    }
    return <String, dynamic>{
      ...domanda,
      'numero_risposte': valori.length,
      'testi': valori
          .map((valore) => valore.toString())
          .toList(growable: false),
    };
  }
}
