import 'package:supabase_flutter/supabase_flutter.dart';

import '../app/app_core.dart';
import '../supporto/conversioni_dati.dart';

class DatiCatalogoQuestionari {
  const DatiCatalogoQuestionari({
    required this.template,
    required this.domande,
    required this.questionari,
  });

  final List<Map<String, dynamic>> template;
  final List<Map<String, dynamic>> domande;
  final List<Map<String, dynamic>> questionari;
}

/// Accesso condiviso ai dati e alle RPC del modulo questionari.
class QuestionariRepository {
  QuestionariRepository({SupabaseClient? client})
    : client = client ?? SupabaseConfig.client;

  final SupabaseClient client;

  String? get userIdCorrente => client.auth.currentUser?.id;

  Future<DatiCatalogoQuestionari> caricaCatalogo({
    bool includiQuestionari = true,
  }) async {
    final risultati = await Future.wait<dynamic>([
      client
          .from('questionari_template')
          .select()
          .order('destinatario')
          .order('titolo'),
      client
          .from('questionari_domande')
          .select()
          .order('template_id')
          .order('ordine'),
      if (includiQuestionari)
        client
            .from('questionari')
            .select()
            .order('created_at', ascending: false),
    ]);

    return DatiCatalogoQuestionari(
      template: mappeDa(risultati[0]),
      domande: mappeDa(risultati[1]),
      questionari: includiQuestionari
          ? mappeDa(risultati[2])
          : const <Map<String, dynamic>>[],
    );
  }

  Future<void> inserisciTemplate(Map<String, dynamic> valori) =>
      client.from('questionari_template').insert(valori);

  Future<void> aggiornaTemplate(String id, Map<String, dynamic> valori) =>
      client.from('questionari_template').update(valori).eq('id', id);

  Future<void> inserisciDomanda(Map<String, dynamic> valori) =>
      client.from('questionari_domande').insert(valori);

  Future<void> eliminaDomanda(String id) =>
      client.from('questionari_domande').delete().eq('id', id);

  Future<List<Map<String, dynamic>>> ordiniDomande(String templateId) async =>
      mappeDa(
        await client
            .from('questionari_domande')
            .select('id, ordine')
            .eq('template_id', templateId)
            .order('ordine'),
      );

  Future<void> aggiornaOrdineDomanda(String id, int ordine) => client
      .from('questionari_domande')
      .update(<String, dynamic>{'ordine': ordine})
      .eq('id', id);

  Future<void> creaQuestionarioEvento({
    required String eventoId,
    required String templateId,
    required String titolo,
  }) => client.from('questionari').insert(<String, dynamic>{
    'template_id': templateId,
    'titolo': titolo.trim(),
    'provider': 'interno',
    'evento_id': eventoId,
    'aperto': true,
    'created_by': userIdCorrente,
  });

  Future<Map<String, dynamic>?> caricaQuestionarioEvento(
    String eventoId,
  ) async {
    final questionario = await client
        .from('questionari')
        .select()
        .eq('provider', 'interno')
        .eq('evento_id', eventoId)
        .eq('aperto', true)
        .maybeSingle();
    if (questionario == null) return null;

    final domande = await client
        .from('questionari_domande')
        .select()
        .eq('template_id', questionario['template_id'])
        .order('ordine');
    return <String, dynamic>{
      'questionario': Map<String, dynamic>.from(questionario),
      'domande': mappeDa(domande),
    };
  }

  Future<bool> questionarioGiaCompilato(String questionarioId) async {
    final userId = userIdCorrente;
    if (userId == null) return false;
    final riga = await client
        .from('questionari_compilazioni')
        .select('id')
        .eq('questionario_id', questionarioId)
        .eq('user_id', userId)
        .maybeSingle();
    return riga != null;
  }

  Future<String> creaCompilazioneInterna(String questionarioId) async {
    final userId = userIdCorrente;
    if (userId == null) throw const AppException('Sessione non valida.');
    final compilazione = await client
        .from('questionari_compilazioni')
        .insert(<String, dynamic>{
          'questionario_id': questionarioId,
          'user_id': userId,
        })
        .select('id')
        .single();
    return compilazione['id'].toString();
  }

  Future<void> inserisciRisposte(
    String compilazioneId,
    Map<String, dynamic> risposte,
  ) async {
    final righe = risposte.entries
        .map(
          (entry) => <String, dynamic>{
            'compilazione_id': compilazioneId,
            'domanda_id': entry.key,
            'valore': entry.value,
          },
        )
        .toList(growable: false);
    if (righe.isNotEmpty) {
      await client.from('questionari_risposte').insert(righe);
    }
  }

  Future<void> eliminaCompilazione(String id) =>
      client.from('questionari_compilazioni').delete().eq('id', id);

  Future<Map<String, dynamic>> creaQuestionarioMentoraggio({
    required String mentoraggioId,
    required String templateId,
    required String titolo,
  }) async {
    final esistente = await client
        .from('questionari')
        .select('id')
        .eq('provider', 'pubblico')
        .eq('mentoraggio_id', mentoraggioId)
        .maybeSingle();
    if (esistente != null) {
      throw const AppException(
        'Il questionario per questo mentoraggio è già stato generato.',
      );
    }

    return Map<String, dynamic>.from(
      await client
          .from('questionari')
          .insert(<String, dynamic>{
            'template_id': templateId,
            'titolo': titolo.trim(),
            'provider': 'pubblico',
            'mentoraggio_id': mentoraggioId,
            'aperto': true,
            'created_by': userIdCorrente,
          })
          .select('id, token_pubblico')
          .single(),
    );
  }

  Future<void> impostaLinkMentoraggio(String mentoraggioId, String url) =>
      client.rpc(
        'questionario_mentoraggio_link_imposta',
        params: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
          'p_url': url,
        },
      );

  Future<int> contaCompilazioni(String questionarioId) async =>
      (await client
                  .from('questionari_compilazioni')
                  .select('id')
                  .eq('questionario_id', questionarioId)
              as List)
          .length;

  Future<String?> mentoraggioDelQuestionario(String questionarioId) async {
    final riga = await client
        .from('questionari')
        .select('mentoraggio_id')
        .eq('id', questionarioId)
        .maybeSingle();
    return riga?['mentoraggio_id']?.toString();
  }

  Future<void> eliminaQuestionario(String id) =>
      client.from('questionari').delete().eq('id', id);

  Future<Map<String, dynamic>> caricaRisultati(String questionarioId) async {
    final questionario = await client
        .from('questionari')
        .select('id, titolo, template_id, provider, evento_id, mentoraggio_id')
        .eq('id', questionarioId)
        .single();
    final domande = mappeDa(
      await client
          .from('questionari_domande')
          .select('id, ordine, testo, tipo, opzioni')
          .eq('template_id', questionario['template_id'])
          .order('ordine'),
    );
    final compilazioni = mappeDa(
      await client
          .from('questionari_compilazioni')
          .select('id, user_id, inviato_at')
          .eq('questionario_id', questionarioId)
          .order('inviato_at'),
    );
    final ids = compilazioni.map((riga) => riga['id'].toString()).toList();
    final risposte = ids.isEmpty
        ? <Map<String, dynamic>>[]
        : mappeDa(
            await client
                .from('questionari_risposte')
                .select('compilazione_id, domanda_id, valore')
                .inFilter('compilazione_id', ids),
          );

    return <String, dynamic>{
      'questionario': Map<String, dynamic>.from(questionario),
      'numero_compilazioni': compilazioni.length,
      'domande': domande,
      'compilazioni': compilazioni,
      'risposte': risposte,
    };
  }

  Future<Map<String, dynamic>?> caricaQuestionarioPubblico(String token) async {
    final raw = await client.rpc(
      'questionario_pubblico_carica',
      params: <String, dynamic>{'p_token': token},
    );
    return raw == null ? null : Map<String, dynamic>.from(raw as Map);
  }

  Future<void> inviaQuestionarioPubblico(
    String token,
    Map<String, dynamic> risposte,
  ) => client.rpc(
    'questionario_pubblico_invia',
    params: <String, dynamic>{'p_token': token, 'p_risposte': risposte},
  );
}
