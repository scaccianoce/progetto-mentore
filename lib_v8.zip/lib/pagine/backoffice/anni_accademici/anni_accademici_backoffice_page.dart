import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../app/app_core.dart';
import '../../../app/app_session_controller.dart';
import '../../../supporto/formattazione_csv.dart';
import '../../../supporto/conversioni_dati.dart';
import '../../../supporto/formattazione_data.dart';
import 'anni_accademici_backoffice_controller.dart';

/// Sintesi annuale calcolata direttamente dalle tabelle reali del DB.
/// Non richiede view/materialized view/RPC di riepilogo.
class AnniAccademiciBackofficePage extends StatefulWidget {
  const AnniAccademiciBackofficePage({super.key, required this.sessione});

  final SessioneController sessione;
    

  @override
  State<AnniAccademiciBackofficePage> createState() =>
      _AnniAccademiciBackofficePageState();
}

class _AnniAccademiciBackofficePageState
    extends State<AnniAccademiciBackofficePage> {
  late final AnniAccademiciBackofficeController controller;
  
  final ScrollController _scrollOrizzontale = ScrollController();
  Map<String, _RiepilogoAnno> _riepiloghi = const {};
  bool _caricamento = true;
  String? _errore;

  @override
  void initState() {
    super.initState();
    controller = AnniAccademiciBackofficeController(widget.sessione)..carica();
    controller.addListener(_aggiornaController);
    _caricaSintesi();
  }

  void _aggiornaController() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    controller.removeListener(_aggiornaController);
    controller.dispose();
    _scrollOrizzontale.dispose();
    super.dispose();
  }

  Future<void> _caricaSintesi() async {
    setState(() {
      _caricamento = true;
      _errore = null;
    });
    try {
      final db = SupabaseConfig.client;
      final risultati = await Future.wait<dynamic>([
        db.from('insegnamenti').select(),
        db.from('mentoraggi').select(),
        db.from('mentoraggio_mentori').select(),
        db.from('eventi').select(),
        db.from('partecipazioni_eventi').select(),
        db.from('house_of_mentore').select(),
        db.from('partecipazioni_house_of_mentore').select(),
        db.from('partecipazioni_annuali').select(),
        db.from('user_roles').select('user_id, role'),
      ]);
      final insegnamenti = mappeDa(risultati[0]);
      final mentoraggi = mappeDa(risultati[1]);
      final assegnazioni = mappeDa(risultati[2]);
      final eventi = mappeDa(risultati[3]);
      final partecipazioniEventi = mappeDa(risultati[4]);
      final hom = mappeDa(risultati[5]);
      final partecipazioniHom = mappeDa(risultati[6]);
      final partecipazioniAnnuali = mappeDa(risultati[7]);
      final userRoles = mappeDa(risultati[8]);

      final risultato = <String, _RiepilogoAnno>{};
      for (final anno in controller.anni) {
        final codice = anno['codice']?.toString() ?? '';
        if (codice.isEmpty) continue;
        risultato[codice] = _calcola(
          codice,
          insegnamenti: insegnamenti,
          mentoraggi: mentoraggi,
          assegnazioni: assegnazioni,
          eventi: eventi,
          partecipazioniEventi: partecipazioniEventi,
          hom: hom,
          partecipazioniHom: partecipazioniHom,
          partecipazioniAnnuali: partecipazioniAnnuali,
          userRoles: userRoles,
        );
      }
      if (!mounted) return;
      setState(() => _riepiloghi = risultato);
    } catch (e) {
      if (!mounted) return;
      setState(() => _errore =
          'Impossibile calcolare la sintesi direttamente dalle tabelle DB.\n$e');
    } finally {
      if (mounted) setState(() => _caricamento = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Sintesi anni accademici',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
              IconButton(
                tooltip: 'Aggiorna',
                onPressed: _caricamento
                    ? null
                    : () async {
                        await controller.carica();
                        await _caricaSintesi();
                      },
                icon: const Icon(Icons.refresh),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: () => _nuovoAnno(context),
                icon: const Icon(Icons.add),
                label: const Text('Nuovo anno'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_caricamento) const LinearProgressIndicator(),
          if (_errore != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(_errore!),
            ),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Scrollbar(
                controller: _scrollOrizzontale,
                thumbVisibility: true,
                trackVisibility: true,
                scrollbarOrientation: ScrollbarOrientation.bottom,
                child: SingleChildScrollView(
                  controller: _scrollOrizzontale,
                  scrollDirection: Axis.horizontal,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: DataTable(
                      columns: const [
                        DataColumn(label: Text('Anno')),
                        DataColumn(label: Text('Stato')),
                        DataColumn(label: Text('Partecipanti'), numeric: true),
                        DataColumn(label: Text('Da confermare'), numeric: true),
                        DataColumn(label: Text('Confermati'), numeric: true),
                        DataColumn(label: Text('Rinunce'), numeric: true),
                        DataColumn(label: Text('Insegnamenti'), numeric: true),
                        DataColumn(
                          label: Text('Insegnamenti mentorati'),
                          numeric: true,
                        ),
                        DataColumn(label: Text('Conclusi'), numeric: true),
                        DataColumn(label: Text('Eventi'), numeric: true),
                        DataColumn(label: Text('Iscrizioni eventi'), numeric: true),
                        DataColumn(label: Text('Presenze eventi'), numeric: true),
                        DataColumn(
                          label: Text('Media presenze/evento'),
                          numeric: true,
                        ),
                        DataColumn(
                          label: Text('House of Mentore'),
                          numeric: true,
                        ),
                        DataColumn(label: Text('Iscrizioni HoM'), numeric: true),
                        DataColumn(label: Text('Presenze HoM'), numeric: true),
                        DataColumn(
                          label: Text('Media presenze/HoM'),
                          numeric: true,
                        ),
                        DataColumn(label: Text('Azioni'),numeric: false),
                      ],
                      rows: [
                        for (final anno in controller.anni)
                          _rigaAnno(context, anno),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      );

  DataRow _rigaAnno(BuildContext context, Map<String, dynamic> anno) {
    final codice = anno['codice']?.toString() ?? '';
    final r = _riepiloghi[codice] ?? _RiepilogoAnno.vuoto(codice);
    return DataRow(cells: [
      DataCell(Row(children: [
        if (_annoCorrente(anno))
          const Padding(
            padding: EdgeInsets.only(right: 6),
            child: Icon(Icons.check_circle, size: 18),
          ),
        Text(codice),
      ])),
      DataCell(_chipStatoAnno(anno)),
      DataCell(Text('${r.partecipanti}')),
      DataCell(Text('${r.daConfermare}')),
      DataCell(Text('${r.confermati}')),
      DataCell(Text('${r.rinunce}')),
      DataCell(Text('${r.insegnamenti}')),
      DataCell(Text('${r.insegnamentiMentorati}')),
      DataCell(Text('${r.mentoraggiConclusi}')),
      DataCell(Text('${r.eventi}')),
      DataCell(Text('${r.iscrizioniEventi}')),
      DataCell(Text('${r.presenzeEventi}')),
      DataCell(Text(r.mediaPresenzeEventi.toStringAsFixed(1))),
      DataCell(Text('${r.houseOfMentore}')),
      DataCell(Text('${r.iscrizioniHom}')),
      DataCell(Text('${r.presenzeHom}')),
      DataCell(Text(r.mediaPresenzeHom.toStringAsFixed(1))),
      DataCell(
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              tooltip: 'Esporta tabelle CSV',
              onPressed: () => _esportaAnno(context, codice),
              icon: const Icon(Icons.download_outlined),
            ),
            if (_statoAnno(anno) == 'preparazione')
              IconButton(
                tooltip: 'Genera richieste di conferma dai partecipanti dell’anno attivo',
                onPressed: () => _generaRichieste(context, codice),
                icon: const Icon(Icons.how_to_reg_outlined),
              ),
            PopupMenuButton<String>(
              tooltip: 'Cambia stato anno',
              onSelected: (stato) => _impostaStatoAnno(context, codice, stato),
              itemBuilder: (context) => const [
                PopupMenuItem(
                  value: 'preparazione',
                  child: Text('Imposta in preparazione'),
                ),
                PopupMenuItem(
                  value: 'attivo',
                  child: Text('Imposta attivo'),
                ),
                PopupMenuItem(
                  value: 'chiuso',
                  child: Text('Chiudi anno'),
                ),
              ],
            ),
          ],
        ),
      ),

    ]);
  }

  _RiepilogoAnno _calcola(
    String anno, {
    required List<Map<String, dynamic>> insegnamenti,
    required List<Map<String, dynamic>> mentoraggi,
    required List<Map<String, dynamic>> assegnazioni,
    required List<Map<String, dynamic>> eventi,
    required List<Map<String, dynamic>> partecipazioniEventi,
    required List<Map<String, dynamic>> hom,
    required List<Map<String, dynamic>> partecipazioniHom,
    required List<Map<String, dynamic>> partecipazioniAnnuali,
    required List<Map<String, dynamic>> userRoles,
  }) {
    final mentAnno = mentoraggi
        .where((r) => r['anno_accademico']?.toString() == anno)
        .toList();
    final insIds = mentAnno
        .map((r) => r['insegnamento_id']?.toString())
        .whereType<String>()
        .toSet();
    final insAnno = insegnamenti
        .where((r) => insIds.contains(r['id']?.toString()))
        .toList();
    final mentIds = mentAnno.map((r) => r['id']?.toString()).whereType<String>().toSet();
    final mentoriIds = assegnazioni
        .where((r) => mentIds.contains(r['mentoraggio_id']?.toString()))
        .map((r) => r['mentore_id']?.toString())
        .whereType<String>();
    final insegnamentiMentoratiIds = mentAnno
        .map((r) => r['insegnamento_id']?.toString())
        .whereType<String>()
        .toSet();
    final menteeIds = insAnno
        .where((r) => insegnamentiMentoratiIds.contains(r['id']?.toString()))
        .map((r) => r['docente_id']?.toString())
        .whereType<String>();
    // Un partecipante dell'anno e chi ha effettivamente svolto almeno uno dei
    // due ruoli: mentee in un mentoraggio e/o mentore assegnato a un mentoraggio.
    final partecipanti = <String>{...menteeIds, ...mentoriIds}
      ..removeWhere((v) => v.isEmpty || v == 'null');

    final eventiAnno = eventi.where((r) => r['anno_accademico']?.toString() == anno).toList();
    final eventoIds = eventiAnno.map((r) => r['id']?.toString()).whereType<String>().toSet();
    final pe = partecipazioniEventi
        .where((r) => eventoIds.contains(r['evento_id']?.toString()))
        .toList();
    final presenzeEventi = pe.where((r) => r['presente'] == true).length;

    final homAnno = hom.where((r) => r['anno_accademico']?.toString() == anno).toList();
    final homIds = homAnno.map((r) => r['id']?.toString()).whereType<String>().toSet();
    final ph = partecipazioniHom
        .where((r) => homIds.contains(r['evento_id']?.toString()))
        .toList();
    final presenzeHom = ph.where((r) => r['presente'] == true).length;

    final annualiAnno = partecipazioniAnnuali
        .where((r) => r['anno_accademico']?.toString() == anno)
        .toList();
    final daConfermare = annualiAnno
        .where((r) => r['stato']?.toString() == 'da_contattare')
        .length;
    final confermati = annualiAnno
        .where((r) => <String>{'confermato', 'nuovo'}.contains(r['stato']?.toString()))
        .length;
    final rinunce = annualiAnno
        .where((r) => r['stato']?.toString() == 'rinuncia')
        .length;

    final amministratoriIds = userRoles
        .where(
          (r) => <String>{'owner', 'organizer'}
              .contains(r['role']?.toString()),
        )
        .map((r) => r['user_id']?.toString())
        .whereType<String>()
        .where((id) => id.isNotEmpty && id != 'null')
        .toSet();

    final partecipantiAnnualiIds = annualiAnno
        .map((r) => r['user_id']?.toString())
        .whereType<String>()
        .where((id) => id.isNotEmpty && id != 'null')
        .toSet();

    final numeroPartecipanti = annualiAnno.isEmpty
        ? (<String>{...partecipanti, ...amministratoriIds}).length
        : (<String>{...partecipantiAnnualiIds, ...amministratoriIds}).length;

    return _RiepilogoAnno(
      anno: anno,
      partecipanti: numeroPartecipanti,
      daConfermare: daConfermare,
      confermati: confermati,
      rinunce: rinunce,
      insegnamenti: insAnno.length,
      insegnamentiMentorati: insegnamentiMentoratiIds.length,
      mentoraggiConclusi: mentAnno.where(_mentoraggioConcluso).length,
      eventi: eventiAnno.length,
      iscrizioniEventi: pe.length,
      presenzeEventi: presenzeEventi,
      mediaPresenzeEventi: eventiAnno.isEmpty ? 0 : presenzeEventi / eventiAnno.length,
      houseOfMentore: homAnno.length,
      iscrizioniHom: ph.length,
      presenzeHom: presenzeHom,
      mediaPresenzeHom: homAnno.isEmpty ? 0 : presenzeHom / homAnno.length,
    );
  }

  Future<void> _esportaAnno(BuildContext context, String anno) async {
    try {
      final tabelle = await _datiGrezziAnno(anno);
      if (!context.mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('CSV · $anno'),
          content: SizedBox(
            width: 650,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Ogni esportazione contiene i valori grezzi letti direttamente dalla tabella DB. '
                    'Il pulsante copia il CSV negli appunti; il salvataggio file multipiattaforma verra collegato al progetto completo/pubspec.',
                  ),
                  const SizedBox(height: 12),
                  for (final voce in tabelle.entries)
                    ListTile(
                      title: Text('${voce.key}.csv'),
                      subtitle: Text('${voce.value.length} righe'),
                      trailing: IconButton(
                        tooltip: 'Copia CSV',
                        onPressed: () async {
                          await Clipboard.setData(
                            ClipboardData(text: _csv(voce.value)),
                          );
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('${voce.key}.csv copiato negli appunti.')),
                          );
                        },
                        icon: const Icon(Icons.copy_outlined),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Chiudi'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      _messaggio(context, 'Impossibile esportare i dati: $e');
    }
  }

  Future<Map<String, List<Map<String, dynamic>>>> _datiGrezziAnno(
    String anno,
  ) async {
    final db = SupabaseConfig.client;
    final rigaAnno = mappeDa(
      await db.from('anni_accademici').select().eq('codice', anno),
    );

    // Tutte le relazioni annuali partono da mentoraggi.anno_accademico.
    // Non viene mai interrogato insegnamenti.anno_accademico, colonna che
    // nella nuova struttura non esiste piu.
    final dati = await controller.caricaDatiAnno(anno);

    return dati.esportazione(rigaAnno: rigaAnno);
  }

  Future<void> _impostaStatoAnno(
    BuildContext context,
    String codice,
    String stato,
  ) async {
    final errore = await controller.impostaStatoAnno(codice, stato);
    if (!context.mounted) return;
    if (errore == null) {
      await _caricaSintesi();
      if (!context.mounted) return;
    }
    _messaggio(context, errore);
  }

  Future<void> _generaRichieste(
    BuildContext context,
    String annoDestinazione,
  ) async {
    final annoSorgente = controller.annoAttivo;
    final conferma = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Generare le richieste di partecipazione?'),
            content: Text(
              'Verranno predisposte le richieste per $annoDestinazione '
              'partendo dai partecipanti dell’anno '
              '${annoSorgente ?? 'attivo'}. Le righe già presenti non verranno duplicate.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annulla'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Genera'),
              ),
            ],
          ),
        ) ??
        false;
    if (!conferma) return;

    final errore = await controller.generaRichiestePartecipazione(
      annoDestinazione,
      annoSorgente: annoSorgente,
    );
    if (!context.mounted) return;
    _messaggio(context, errore);
  }

  Future<void> _nuovoAnno(BuildContext context) async {
    final codice = TextEditingController();
    DateTime? inizio;
    DateTime? fine;
    final salva = await showDialog<bool>(
          context: context,
          builder: (context) => StatefulBuilder(
            builder: (context, setDialogState) => AlertDialog(
              title: const Text('Nuovo anno accademico'),
              content: SizedBox(
                width: 480,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: codice,
                      decoration: const InputDecoration(labelText: 'Codice (es. 2026-27)'),
                    ),
                    _rigaData(context, etichetta: 'Data inizio', valore: inizio,
                        onChanged: (v) => setDialogState(() => inizio = v)),
                    _rigaData(context, etichetta: 'Data fine', valore: fine,
                        onChanged: (v) => setDialogState(() => fine = v)),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annulla')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Crea')),
              ],
            ),
          ),
        ) ??
        false;
    if (salva) {
      final errore = await controller.aggiungiAnno(
        codice.text,
        dataIso(inizio),
        dataIso(fine),
      );
      await _caricaSintesi();
      if (!context.mounted) {
        codice.dispose();
        return;
      }
      _messaggio(context, errore);
    }
    codice.dispose();
  }

  Widget _rigaData(
    BuildContext context, {
    required String etichetta,
    required DateTime? valore,
    required ValueChanged<DateTime?> onChanged,
  }) => ListTile(
        contentPadding: EdgeInsets.zero,
        title: Text(
          valore == null ? etichetta : '$etichetta: ${formattaData(valore)}',
        ),
        trailing: IconButton(
          tooltip: 'Scegli data',
          onPressed: () async {
            final scelta = await showDatePicker(
              context: context,
              initialDate: valore ?? DateTime.now(),
              firstDate: DateTime(2000),
              lastDate: DateTime(2200),
            );
            if (scelta != null) onChanged(scelta);
          },
          icon: const Icon(Icons.calendar_month_outlined),
        ),
      );
}

class _RiepilogoAnno {
  const _RiepilogoAnno({
    required this.anno,
    required this.partecipanti,
    required this.daConfermare,
    required this.confermati,
    required this.rinunce,
    required this.insegnamenti,
    required this.insegnamentiMentorati,
    required this.mentoraggiConclusi,
    required this.eventi,
    required this.iscrizioniEventi,
    required this.presenzeEventi,
    required this.mediaPresenzeEventi,
    required this.houseOfMentore,
    required this.iscrizioniHom,
    required this.presenzeHom,
    required this.mediaPresenzeHom,
  });

  factory _RiepilogoAnno.vuoto(String anno) => _RiepilogoAnno(
        anno: anno,
        partecipanti: 0,
        daConfermare: 0,
        confermati: 0,
        rinunce: 0,
        insegnamenti: 0,
        insegnamentiMentorati: 0,
        mentoraggiConclusi: 0,
        eventi: 0,
        iscrizioniEventi: 0,
        presenzeEventi: 0,
        mediaPresenzeEventi: 0,
        houseOfMentore: 0,
        iscrizioniHom: 0,
        presenzeHom: 0,
        mediaPresenzeHom: 0,
      );

  final String anno;
  final int partecipanti;
  final int daConfermare;
  final int confermati;
  final int rinunce;
  final int insegnamenti;
  final int insegnamentiMentorati;
  final int mentoraggiConclusi;
  final int eventi;
  final int iscrizioniEventi;
  final int presenzeEventi;
  final double mediaPresenzeEventi;
  final int houseOfMentore;
  final int iscrizioniHom;
  final int presenzeHom;
  final double mediaPresenzeHom;
}

String _statoAnno(Map<String, dynamic> anno) {
  final stato = anno['stato']?.toString();
  if (stato != null && stato.isNotEmpty) return stato;
  return _annoCorrente(anno) ? 'attivo' : 'chiuso';
}

Widget _chipStatoAnno(Map<String, dynamic> anno) {
  final stato = _statoAnno(anno);
  final etichetta = switch (stato) {
    'preparazione' => 'Preparazione',
    'attivo' => 'Attivo',
    'chiuso' => 'Chiuso',
    _ => stato,
  };
  return Chip(label: Text(etichetta));
}

bool _annoCorrente(Map<String, dynamic> anno) {
  final valore = anno['corrente'];

  if (valore == true) return true;
  if (valore == false || valore == null) return false;

  final testo = valore.toString().trim().toLowerCase();

  return testo == 'true' ||
      testo == 't' ||
      testo == '1' ||
      testo == 'yes';
}

bool _mentoraggioConcluso(Map<String, dynamic> riga) {
  final invio = riga['data_invio_scheda'];
  if (invio != null && invio.toString().trim().isNotEmpty) return true;
  final stato = riga['stato']?.toString().toLowerCase() ?? '';
  return stato.contains('conclus') || stato.contains('complet') || stato.contains('termin');
}

String _csv(List<Map<String, dynamic>> righe) {
  if (righe.isEmpty) return '';
  final intestazioni = <String>[];
  for (final riga in righe) {
    for (final chiave in riga.keys) {
      if (!intestazioni.contains(chiave)) intestazioni.add(chiave);
    }
  }
  final buffer = StringBuffer()..writeln(intestazioni.map(campoCsv).join(','));
  for (final riga in righe) {
    buffer.writeln(intestazioni.map((c) => campoCsv(riga[c])).join(','));
  }
  return buffer.toString();
}

void _messaggio(BuildContext context, String? messaggio) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(messaggio ?? 'Operazione completata.')),
  );
}
