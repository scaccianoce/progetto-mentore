import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';

import '../../../app/app_core.dart';
import 'package:prog_mentore/ui/schema_dinamico.dart';
import 'package:prog_mentore/ui/maschera_dinamica.dart';
import '../../../app/app_session_controller.dart';
import '../../../ui/questionario_mentoraggio_card.dart';
import '../../../supporto/questionario_mentoraggio_controller.dart';
import '../../../ui/componenti_pagina_dinamica.dart';
import '../../../ui/template_elenco_dettaglio_page.dart';
import 'mentore_controller.dart';

class MentorePage extends StatefulWidget {
  const MentorePage({super.key, required this.sessione});

  final SessioneController sessione;

  @override
  State<MentorePage> createState() => _MentorePageState();
}

class _MentorePageState extends State<MentorePage> {
  static const configurazione = ConfigurazionePaginaDinamica(
    tabella: 'mentoraggi',
    campi: <String, PersonalizzazioneCampo>{
      'insegnamento_id': PersonalizzazioneCampo(nascosto: true),
      'anno_accademico': PersonalizzazioneCampo(
        modificabilePartecipante: false,
      ),
      'data_inizio': PersonalizzazioneCampo(modificabilePartecipante: false),
      'data_fine': PersonalizzazioneCampo(modificabilePartecipante: false),
      'numero_studenti': PersonalizzazioneCampo(
        modificabilePartecipante: false,
      ),
      'sede': PersonalizzazioneCampo(modificabilePartecipante: false),
      'note': PersonalizzazioneCampo(modificabilePartecipante: false),
      'azioni_miglioramento': PersonalizzazioneCampo(
        etichetta: 'Azioni di miglioramento',
      ),
      'svolgimento': PersonalizzazioneCampo(modificabilePartecipante: false),
      'giorni_orari_lezioni': PersonalizzazioneCampo(
        modificabilePartecipante: false,
      ),
      'scheda_sintesi_pdf_url': PersonalizzazioneCampo(nascosto: true),
    },
  );

  late final MentoreController controller;
  late final QuestionarioMentoraggioController questionariController;

  @override
  void initState() {
    super.initState();
    controller = MentoreController()..carica();
    questionariController = QuestionarioMentoraggioController(widget.sessione)
      ..carica();
  }

  @override
  void dispose() {
    controller.dispose();
    questionariController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) => TemplatePaginaElencoDettaglio(
      caricamento: controller.caricamento && controller.percorsi.isEmpty,
      errore: controller.errore,
      vuoto: controller.percorsi.isEmpty,
      messaggioVuoto: 'Nessun mentoraggio assegnato.',
      larghezzaElenco: 390,
      elenco: ElencoRecordDinamico<PercorsoMentore>(
        elementi: controller.percorsi,
        idSelezionato: controller.selezionato?.mentoraggio['id']?.toString(),
        id: (p) => p.mentoraggio['id']?.toString() ?? '',
        titolo: (p) => p.insegnamento['insegnamento']?.toString() ?? '',
        sottotitolo: (p) {
          final docente =
              '${p.docente['nome'] ?? ''} ${p.docente['cognome'] ?? ''}'.trim();
          final anno = p.mentoraggio['anno_accademico']?.toString() ?? '';
          return '$docente · $anno · ${p.mioRuolo}';
        },
        onSeleziona: controller.seleziona,
      ),
      dettaglio: Card(margin: EdgeInsets.zero, child: _dettaglio()),
    ),
  );

  Widget _dettaglio() {
    final percorso = controller.selezionato;
    if (percorso == null) {
      return const Center(child: Text('Seleziona un mentoraggio.'));
    }

    return DettaglioRecordDinamico(
      configurazione: configurazione,
      valori: percorso.mentoraggio,
      partecipante: true,
      prima: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Ruolo mentore · ${percorso.mentoraggio['anno_accademico'] ?? ''}',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            if (percorso.annoCorrente)
              FilledButton.icon(
                onPressed: controller.salvataggio ? null : _modifica,
                icon: const Icon(Icons.edit),
                label: const Text('Modifica'),
              ),
          ],
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Insegnamento',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
            percorso.insegnamento['insegnamento']?.toString() ?? '',
          ),
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Semestre',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(percorso.insegnamento['semestre']?.toString() ?? ''),
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Mentee',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
            '${percorso.docente['nome'] ?? ''} ${percorso.docente['cognome'] ?? ''}'
                .trim(),
          ),
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Ruolo svolto',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(percorso.mioRuolo.isEmpty ? '—' : percorso.mioRuolo),
        ),
        if (!percorso.annoCorrente)
          const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.lock_outline),
            title: Text(
              'Mentoraggio storico',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              'I mentoraggi degli anni precedenti sono consultabili ma non modificabili.',
            ),
          ),
        const Divider(),
        Text('Team', style: Theme.of(context).textTheme.titleMedium),
        ...percorso.team.map(
          (mentore) => ListTile(
            title: Text(
              '${mentore['nome'] ?? ''} ${mentore['cognome'] ?? ''}'.trim(),
            ),
            subtitle: Text(mentore['tipo']?.toString() ?? ''),
          ),
        ),
        const Divider(),
      ],
      dopo: <Widget>[
        const Divider(height: 28),
        _SchedaSintesiFileCard(
          mentoraggio: percorso.mentoraggio,
          onAggiornato: controller.carica,
        ),
      ],
    );
  }

  Future<void> _modifica() async {
    final percorso = controller.selezionato;
    if (percorso == null || !percorso.annoCorrente) return;
    await questionariController.carica();
    if (!mounted) return;
    final valori = await mostraMascheraDinamica(
      context: context,
      configurazione: configurazione,
      valoriIniziali: percorso.mentoraggio,
      partecipante: true,
      titolo:
          'Aggiorna ${percorso.insegnamento['insegnamento'] ?? ''} · ${percorso.mentoraggio['anno_accademico'] ?? ''}',
      contenutoExtra: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          QuestionarioMentoraggioCard(
            controller: questionariController,
            mentoraggioId: percorso.mentoraggio['id'].toString(),
          ),
          const SizedBox(height: 12),
          _SchedaSintesiFileCard(
            mentoraggio: percorso.mentoraggio,
            onAggiornato: controller.carica,
          ),
        ],
      ),
    );
    if (valori == null) return;
    try {
      await controller.salvaMentoraggio(valori);
    } on AppException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.messaggio)));
    }
  }
}

// ============================================================================
// WIDGET PRIVATO: SCHEDA DI SINTESI SU STORAGE
// ============================================================================

class _SchedaSintesiFileCard extends StatefulWidget {
  const _SchedaSintesiFileCard({required this.mentoraggio, this.onAggiornato});

  final Map<String, dynamic> mentoraggio;
  final Future<void> Function()? onAggiornato;

  @override
  State<_SchedaSintesiFileCard> createState() => _SchedaSintesiFileCardState();
}

class _SchedaSintesiFileCardState extends State<_SchedaSintesiFileCard> {
  static const _bucket = 'schede-sintesi';
  bool _operazione = false;

  String get _stato =>
      widget.mentoraggio['stato']?.toString().trim().toLowerCase() ?? '';

  String get _valoreFile =>
      widget.mentoraggio['scheda_sintesi_pdf_url']?.toString().trim() ?? '';

  bool get _completato => _stato == 'completato';

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Scheda di sintesi · documento',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 6),
            Text(
              _completato
                  ? 'Puoi caricare o sostituire la scheda definitiva in PDF o DOCX.'
                  : 'Il caricamento è disponibile quando il mentoraggio è in stato Completato.',
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (_valoreFile.isNotEmpty)
                  OutlinedButton.icon(
                    onPressed: _operazione ? null : _apri,
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('Apri / scarica'),
                  ),
                FilledButton.tonalIcon(
                  onPressed: !_completato || _operazione ? null : _carica,
                  icon: const Icon(Icons.upload_file_outlined),
                  label: Text(
                    _valoreFile.isEmpty
                        ? 'Carica scheda di sintesi'
                        : 'Sostituisci scheda',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _carica() async {
    final file = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['pdf', 'docx'],
    );
    if (file == null) return;

    final estensione = file.name.split('.').last.toLowerCase();
    if (!const {'pdf', 'docx'}.contains(estensione)) {
      _messaggio('Sono ammessi soltanto file PDF e DOCX.');
      return;
    }

    setState(() => _operazione = true);
    try {
      final bytes = await file.readAsBytes();
      final id = widget.mentoraggio['id'].toString();
      final anno =
          widget.mentoraggio['anno_accademico']?.toString() ?? 'senza-anno';
      final path = '$anno/$id/scheda_sintesi.$estensione';
      final contentType = estensione == 'pdf'
          ? 'application/pdf'
          : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

      await SupabaseConfig.client.storage
          .from(_bucket)
          .uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(upsert: true, contentType: contentType),
          );

      await SupabaseConfig.client.rpc(
        'mentoraggio_scheda_sintesi_imposta',
        params: {'p_mentoraggio_id': id, 'p_storage_path': path},
      );

      final precedente = _valoreFile;
      if (precedente.isNotEmpty &&
          precedente != path &&
          !precedente.startsWith('http://') &&
          !precedente.startsWith('https://')) {
        try {
          await SupabaseConfig.client.storage.from(_bucket).remove([
            precedente,
          ]);
        } catch (_) {
          // Il nuovo documento e gia valido: un residuo del vecchio file
          // non deve annullare l'operazione.
        }
      }

      widget.mentoraggio['scheda_sintesi_pdf_url'] = path;
      if (widget.onAggiornato != null) {
        await widget.onAggiornato!();
      }
      if (!mounted) return;
      setState(() {});
      _messaggio('Scheda di sintesi caricata.');
    } catch (e) {
      _messaggio(
        AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile caricare la scheda di sintesi.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _operazione = false);
    }
  }

  Future<void> _apri() async {
    setState(() => _operazione = true);
    try {
      final valore = _valoreFile;
      final url = valore.startsWith('http://') || valore.startsWith('https://')
          ? valore
          : await SupabaseConfig.client.storage
                .from(_bucket)
                .createSignedUrl(valore, 3600);

      final uri = Uri.tryParse(url);
      if (uri == null ||
          !await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw const AppException('Impossibile aprire il documento.');
      }
    } catch (e) {
      _messaggio(
        AppErrorMapper.converti(
          e,
          messaggioGenerico: 'Impossibile aprire la scheda di sintesi.',
        ).messaggio,
      );
    } finally {
      if (mounted) setState(() => _operazione = false);
    }
  }

  void _messaggio(String testo) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(testo)));
  }
}
