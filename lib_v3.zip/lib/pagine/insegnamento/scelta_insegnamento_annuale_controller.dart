import '../../supabase_config.dart';

class StatoInsegnamentoAnnuale {
  const StatoInsegnamentoAnnuale({
    required this.annoAccademico,
    required this.annoCorrente,
    required this.nonRichiesto,
    required this.puoSelezionare,
    required this.puoCreare,
    required this.puoModificare,
    this.mentoraggioId,
    this.insegnamentoId,
  });

  factory StatoInsegnamentoAnnuale.daMap(
    Map<String, dynamic> map,
  ) {
    return StatoInsegnamentoAnnuale(
      annoAccademico:
          map['anno_accademico']?.toString() ?? '',
      annoCorrente:
          map['anno_corrente'] == true,
      nonRichiesto:
          map['non_richiesto'] == true,
      puoSelezionare:
          map['puo_selezionare'] == true,
      puoCreare:
          map['puo_creare'] == true,
      puoModificare:
          map['puo_modificare'] == true,
      mentoraggioId:
          map['mentoraggio_id']?.toString(),
      insegnamentoId:
          map['insegnamento_id']?.toString(),
    );
  }

  final String annoAccademico;
  final bool annoCorrente;

  final bool nonRichiesto;
  final bool puoSelezionare;
  final bool puoCreare;
  final bool puoModificare;

  final String? mentoraggioId;
  final String? insegnamentoId;

  bool get haMentoraggio =>
      mentoraggioId != null;
}


class SceltaInsegnamentoAnnualeController {
  Future<StatoInsegnamentoAnnuale>
      caricaStato() async {
    final raw =
        await SupabaseConfig.client.rpc(
      'insegnamento_stato_annuale',
    );

    return StatoInsegnamentoAnnuale.daMap(
      Map<String, dynamic>.from(
        raw as Map,
      ),
    );
  }


  Future<List<Map<String, dynamic>>>
      caricaInsegnamenti() async {
    final raw =
        await SupabaseConfig.client.rpc(
      'insegnamenti_miei',
    );

    return (raw as List)
        .map(
          (e) => Map<String, dynamic>.from(
            e as Map,
          ),
        )
        .toList(growable: false);
  }


  Future<void> seleziona(
    String insegnamentoId,
  ) async {
    await SupabaseConfig.client.rpc(
      'insegnamento_seleziona_per_anno',
      params: {
        'p_insegnamento_id':
            insegnamentoId,
      },
    );
  }


  Future<void> crea(
    Map<String, dynamic> valori,
  ) async {
    await SupabaseConfig.client.rpc(
      'insegnamento_crea_per_anno',
      params: {
        'p_valori': valori,
      },
    );
  }


  Future<void> modifica(
    String insegnamentoId,
    Map<String, dynamic> valori,
  ) async {
    await SupabaseConfig.client.rpc(
      'insegnamento_modifica_autorizzata',
      params: {
        'p_insegnamento_id':
            insegnamentoId,
        'p_valori': valori,
      },
    );
  }
}