import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app/app_core.dart';
import '../ui/schema_dinamico.dart';
import '../supporto/conversioni_dati.dart';


// ============================================================================
// SUPABASE
// ============================================================================

/// Configurazione unica della connessione a Supabase.
///
/// Questa classe si occupa esclusivamente dell'inizializzazione del client.
/// Le operazioni remote (query, RPC, Storage ed Edge Functions) sono
/// centralizzate in `lib/dati/repository.dart`.
abstract final class SupabaseConfig {
  static const String url = AppConfig.supabaseUrl;
  static const String publishableKey = AppConfig.supabasePublishableKey;

  /// Inizializza Supabase prima dell'avvio dell'app.
  static Future<void> inizializza() async {
    if (url.trim().isEmpty || publishableKey.trim().isEmpty) {
      throw StateError(
        'Configurazione Supabase mancante. Avvia l’app passando '
        'SUPABASE_URL e SUPABASE_PUBLISHABLE_KEY con --dart-define.',
      );
    }

    final Uri? indirizzo = Uri.tryParse(url);
    if (indirizzo == null || !indirizzo.hasScheme || !indirizzo.hasAuthority) {
      throw StateError('SUPABASE_URL non contiene un indirizzo valido.');
    }

    await Supabase.initialize(
      url: url,
      publishableKey: publishableKey,
      authOptions: const FlutterAuthClientOptions(
        authFlowType: AuthFlowType.pkce,
      ),
    );
  }
  /// Client condiviso usato esclusivamente dal livello dati.
  static SupabaseClient get client => Supabase.instance.client;
}

/// Filtro di uguaglianza usato nelle letture standard.
class FiltroDb {
  const FiltroDb(this.campo, this.valore);

  final String campo;
  final Object valore;
}

/// Filtro `IN (...)` usato nelle letture standard.
class FiltroInDb {
  const FiltroInDb(this.campo, this.valori);

  final String campo;
  final List<Object> valori;
}

/// Ordinamento di una query standard.
class OrdineDb {
  const OrdineDb(
    this.campo, {
    this.crescente = true,
    this.nullPrima = false,
  });

  final String campo;
  final bool crescente;
  final bool nullPrima;
}

/// Contratto minimo usato dai repository di backoffice per le autorizzazioni.
///
/// Evita che il livello dati dipenda dal controller di sessione e mantiene la
/// dipendenza nella sola direzione UI/controller -> repository.
abstract interface class AutorizzazioniBackoffice {
  bool get repositorySoloOwner;
  bool get repositoryPuoAmministrare;

  String? get repositoryUserId;
}

/// Unico punto di accesso alle operazioni Supabase comuni dell'applicazione.
///
/// Non contiene regole di business: espone soltanto primitive uniformi per
/// lettura, scrittura, RPC e autenticazione. I controller non dovrebbero
/// costruire query Supabase direttamente quando l'operazione è esprimibile qui.
class RepositoryComune {
  RepositoryComune({SupabaseClient? client})
      : client = client ?? SupabaseConfig.client;

  final SupabaseClient client;

  static SchemaDatabase? _schemaDatabase;
  static Future<SchemaDatabase>? _caricamentoSchema;

  String? get userIdCorrente => client.auth.currentUser?.id;

  /// Carica e mantiene in cache la descrizione dello schema `public`.
  ///
  /// Anche questa RPC passa dal repository, così [SupabaseConfig] resta
  /// limitato alla sola inizializzazione del client.
  Future<SchemaDatabase> schemaDatabase({bool forzaAggiornamento = false}) {
    if (!forzaAggiornamento && _schemaDatabase != null) {
      return Future<SchemaDatabase>.value(_schemaDatabase);
    }
    if (!forzaAggiornamento && _caricamentoSchema != null) {
      return _caricamentoSchema!;
    }

    final caricamento = _leggiSchemaDatabase();
    _caricamentoSchema = caricamento;
    return caricamento.whenComplete(() {
      if (identical(_caricamentoSchema, caricamento)) {
        _caricamentoSchema = null;
      }
    });
  }

  Future<SchemaDatabase> _leggiSchemaDatabase() async {
    final dynamic risposta = await client.rpc('app_database_schema');
    if (risposta is! Map) {
      throw const FormatException(
        'La funzione app_database_schema ha restituito dati non validi.',
      );
    }
    final schema = SchemaDatabase.fromJson(
      Map<String, dynamic>.from(risposta),
    );
    _schemaDatabase = schema;
    return schema;
  }

  Future<List<Map<String, dynamic>>> elenco({
    required String tabella,
    String colonne = '*',
    List<FiltroDb> filtri = const <FiltroDb>[],
    List<FiltroInDb> filtriIn = const <FiltroInDb>[],
    List<OrdineDb> ordinamenti = const <OrdineDb>[],
    int? limite,
  }) async {
    dynamic query = client.from(tabella).select(colonne);

    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }
    for (final filtro in filtriIn) {
      query = query.inFilter(filtro.campo, filtro.valori);
    }
    for (final ordine in ordinamenti) {
      query = query.order(
        ordine.campo,
        ascending: ordine.crescente,
        nullsFirst: ordine.nullPrima,
      );
    }
    if (limite != null) query = query.limit(limite);

    final List<dynamic> righe = await query;
    return righe
        .map((riga) => Map<String, dynamic>.from(riga as Map))
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> singolo({
    required String tabella,
    String colonne = '*',
    List<FiltroDb> filtri = const <FiltroDb>[],
  }) async {
    dynamic query = client.from(tabella).select(colonne);
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }

    final dynamic riga = await query.maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> inserisci({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) async {
    final dynamic riga = await client
        .from(tabella)
        .insert(valori)
        .select(colonne)
        .maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> aggiorna({
    required String tabella,
    required Map<String, dynamic> valori,
    required List<FiltroDb> filtri,
    String colonne = '*',
  }) async {
    dynamic query = client.from(tabella).update(valori);
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }

    final dynamic riga = await query.select(colonne).maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<Map<String, dynamic>?> upsert({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
    String? onConflict,
  }) async {
    dynamic query = client.from(tabella).upsert(
          valori,
          onConflict: onConflict,
        );
    final dynamic riga = await query.select(colonne).maybeSingle();
    if (riga == null) return null;
    return Map<String, dynamic>.from(riga as Map);
  }

  Future<void> elimina({
    required String tabella,
    required List<FiltroDb> filtri,
  }) async {
    dynamic query = client.from(tabella).delete();
    for (final filtro in filtri) {
      query = query.eq(filtro.campo, filtro.valore);
    }
    await query;
  }

  /// Esegue una RPC e restituisce la risposta grezza quando il chiamante ha
  /// bisogno di distinguere Map, List, valore scalare o null.
  Future<dynamic> rpc(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) => client.rpc(nome, params: parametri);

  Future<List<Map<String, dynamic>>> rpcElenco(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) async {
    final dynamic raw = await rpc(nome, parametri: parametri);
    if (raw == null) return const <Map<String, dynamic>>[];
    return (raw as List<dynamic>)
        .map((riga) => Map<String, dynamic>.from(riga as Map))
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> rpcMappa(
    String nome, {
    Map<String, dynamic> parametri = const <String, dynamic>{},
  }) async {
    final dynamic raw = await rpc(nome, parametri: parametri);
    if (raw == null) return null;
    return Map<String, dynamic>.from(raw as Map);
  }

  /// Invoca una Edge Function e restituisce una mappa JSON validata.
  Future<Map<String, dynamic>> invocaFunzioneMappa(
    String nome, {
    Map<String, dynamic> body = const <String, dynamic>{},
  }) async {
    final risposta = await client.functions.invoke(nome, body: body);
    final data = risposta.data;
    if (risposta.status < 200 || risposta.status >= 300) {
      throw StateError('Edge Function (${risposta.status}): $data');
    }
    if (data is Map) return Map<String, dynamic>.from(data);
    throw StateError('Risposta non JSON dalla Edge Function $nome: $data');
  }
}

/// Accesso uniforme a Supabase Storage.
///
/// È separato da [RepositoryComune] perché Storage ha una semantica diversa
/// dalle tabelle PostgreSQL, ma usa lo stesso client Supabase condiviso.
class StorageRepository {
  StorageRepository({SupabaseClient? client})
      : client = client ?? SupabaseConfig.client;

  final SupabaseClient client;

  Future<void> caricaBytes({
    required String bucket,
    required String percorso,
    required Uint8List bytes,
    FileOptions opzioni = const FileOptions(upsert: true),
  }) async {
    await client.storage.from(bucket).uploadBinary(
          percorso,
          bytes,
          fileOptions: opzioni,
        );
  }

  Future<void> elimina({
    required String bucket,
    required List<String> percorsi,
  }) async {
    if (percorsi.isEmpty) return;
    await client.storage.from(bucket).remove(percorsi);
  }

  Future<String> urlFirmato({
    required String bucket,
    required String percorso,
    int durataSecondi = 3600,
  }) => client.storage
      .from(bucket)
      .createSignedUrl(percorso, durataSecondi);

  String urlPubblico({
    required String bucket,
    required String percorso,
  }) => client.storage.from(bucket).getPublicUrl(percorso);
}


// ============================================================================
// COMPATIBILITA CRUD DINAMICO
// ============================================================================

/// Alias storico mantenuto per i componenti dinamici esistenti.
typedef FiltroDinamico = FiltroDb;

/// Componente `OrdinamentoDinamico`: incapsula responsabilità specifiche del relativo modulo.
class OrdinamentoDinamico extends OrdineDb {
  const OrdinamentoDinamico(
    super.campo, {
    super.crescente = true,
    super.nullPrima = false,
  });
}

/// Adattatore compatibile con l'API CRUD dinamica esistente.
class RepositoryDinamico {
  RepositoryDinamico({SupabaseClient? client})
      : _db = RepositoryComune(client: client);

  final RepositoryComune _db;

  Future<List<Map<String, dynamic>>> elenco({
    required String tabella,
    String colonne = '*',
    List<FiltroDinamico> filtri = const <FiltroDinamico>[],
    List<OrdinamentoDinamico> ordinamenti = const <OrdinamentoDinamico>[],
  }) => _db.elenco(
        tabella: tabella,
        colonne: colonne,
        filtri: filtri,
        ordinamenti: ordinamenti,
      );

  Future<Map<String, dynamic>?> singolo({
    required String tabella,
    String colonne = '*',
    List<FiltroDinamico> filtri = const <FiltroDinamico>[],
  }) => _db.singolo(tabella: tabella, colonne: colonne, filtri: filtri);

  Future<Map<String, dynamic>?> inserisci({
    required String tabella,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) => _db.inserisci(tabella: tabella, valori: valori, colonne: colonne);

  Future<Map<String, dynamic>?> aggiorna({
    required String tabella,
    required String campoFiltro,
    required Object valoreFiltro,
    required Map<String, dynamic> valori,
    String colonne = '*',
  }) => _db.aggiorna(
        tabella: tabella,
        valori: valori,
        filtri: <FiltroDb>[FiltroDb(campoFiltro, valoreFiltro)],
        colonne: colonne,
      );

  Future<void> elimina({
    required String tabella,
    required String campoFiltro,
    required Object valoreFiltro,
  }) => _db.elimina(
        tabella: tabella,
        filtri: <FiltroDb>[FiltroDb(campoFiltro, valoreFiltro)],
      );
}

/// Query e RPC condivise dall'intera area Mentoraggio.
///
/// Questa classe non gestisce stato UI e non chiama notifyListeners: restituisce
/// soltanto dati al controller che li trasforma nel modello richiesto dalla
/// pagina.
class MentoraggiRepository {
  MentoraggiRepository(this.db);

  final RepositoryComune db;

  String? get userIdCorrente => db.userIdCorrente;

  /// Schema DB usato dalle pagine per costruire localmente la sola visualizzazione.
  Future<SchemaDatabase> schemaDatabase() => db.schemaDatabase();

  Future<String?> annoAccademicoCorrente() async {
    final riga = await db.singolo(
      tabella: 'anni_accademici',
      colonne: 'codice',
      filtri: const <FiltroDb>[
        FiltroDb('corrente', true),
      ],
    );
    return riga?['codice']?.toString();
  }

  Future<List<Map<String, dynamic>>> insegnamentiDelDocente(
    String docenteId,
  ) => db.elenco(
        tabella: 'insegnamenti',
        filtri: <FiltroDb>[
          FiltroDb('docente_id', docenteId),
        ],
      );

  Future<List<Map<String, dynamic>>> insegnamentiPerId(
    List<String> ids,
  ) {
    if (ids.isEmpty) return Future.value(const <Map<String, dynamic>>[]);
    return db.elenco(
      tabella: 'insegnamenti',
      filtriIn: <FiltroInDb>[
        FiltroInDb('id', ids),
      ],
    );
  }

  Future<List<Map<String, dynamic>>> mentoraggiDelMentee() =>
      db.rpcElenco('mentoraggi_del_mentee');

  Future<List<Map<String, dynamic>>> mentoraggiDelMentore() =>
      db.rpcElenco('mentoraggi_del_mentore');

  Future<List<Map<String, dynamic>>> assegnazioniDelMentore(
    String mentoreId,
  ) => db.elenco(
        tabella: 'mentoraggio_mentori',
        colonne: 'mentoraggio_id, mentore_id, tipo',
        filtri: <FiltroDb>[
          FiltroDb('mentore_id', mentoreId),
        ],
      );

  Future<List<Map<String, dynamic>>> assegnazioniPerMentoraggi(
    List<String> mentoraggioIds,
  ) {
    if (mentoraggioIds.isEmpty) {
      return Future.value(const <Map<String, dynamic>>[]);
    }
    return db.elenco(
      tabella: 'mentoraggio_mentori',
      colonne: 'mentoraggio_id, mentore_id, tipo',
      filtriIn: <FiltroInDb>[
        FiltroInDb('mentoraggio_id', mentoraggioIds),
      ],
    );
  }

  Future<List<Map<String, dynamic>>> anagrafiche(
    List<String> userIds, {
    bool includiCellulare = false,
  }) {
    if (userIds.isEmpty) {
      return Future.value(const <Map<String, dynamic>>[]);
    }
    return db.elenco(
      tabella: 'anagrafica',
      colonne: includiCellulare
          ? 'user_id, nome, cognome, email_unipa, cellulare'
          : 'user_id, nome, cognome, email_unipa',
      filtriIn: <FiltroInDb>[
        FiltroInDb('user_id', userIds),
      ],
    );
  }

  Future<Map<String, dynamic>?> sintesiQuestionario(
    String mentoraggioId,
  ) => db.rpcMappa(
        'questionario_sintesi_mentoraggio',
        parametri: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
        },
      );

  Future<Map<String, dynamic>?> risultatiQuestionario(
    String mentoraggioId,
  ) => db.rpcMappa(
        'questionario_risultati_mentoraggio',
        parametri: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
        },
      );

  Future<void> aggiornaComeMentee(
    String mentoraggioId,
    Map<String, dynamic> valori,
  ) async {
    await db.rpc(
      'mentoraggio_aggiorna_mentee',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_valori': valori,
      },
    );
  }

  /// Restituisce un URL apribile per una scheda di sintesi salvata nello Storage.
  Future<String> urlSchedaSintesi(
    String valore, {
    int durataSecondi = 3600,
  }) async {
    if (valore.startsWith('http://') || valore.startsWith('https://')) {
      return valore;
    }
    return db.client.storage
        .from('schede-sintesi')
        .createSignedUrl(valore, durataSecondi);
  }

  /// Carica/sostituisce la scheda di sintesi e aggiorna il mentoraggio.
  ///
  /// L'eventuale vecchio file viene rimosso solo dopo che il nuovo documento
  /// è stato caricato e registrato correttamente nel database.
  Future<String> salvaSchedaSintesi({
    required String mentoraggioId,
    required String annoAccademico,
    required String estensione,
    required Uint8List bytes,
    required String contentType,
    String? percorsoPrecedente,
  }) async {
    const bucket = 'schede-sintesi';
    final path = '$annoAccademico/$mentoraggioId/scheda_sintesi.$estensione';

    await db.client.storage.from(bucket).uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(upsert: true, contentType: contentType),
    );

    await db.rpc(
      'mentoraggio_scheda_sintesi_imposta',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_storage_path': path,
      },
    );

    final precedente = percorsoPrecedente?.trim() ?? '';
    if (precedente.isNotEmpty &&
        precedente != path &&
        !precedente.startsWith('http://') &&
        !precedente.startsWith('https://')) {
      try {
        await db.client.storage.from(bucket).remove(<String>[precedente]);
      } catch (_) {
        // Il nuovo documento è valido; un residuo del file precedente non
        // deve annullare l'operazione conclusa correttamente.
      }
    }
    return path;
  }

  Future<void> aggiornaComeMentore(
    String mentoraggioId,
    Map<String, dynamic> valori,
  ) async {
    await db.rpc(
      'mentoraggio_aggiorna_mentore',
      parametri: <String, dynamic>{
        'p_mentoraggio_id': mentoraggioId,
        'p_valori': valori,
      },
    );
  }
}

/// Query e RPC relative alla scelta e gestione annuale degli insegnamenti.
class InsegnamentiRepository {
  InsegnamentiRepository(this.db);

  final RepositoryComune db;

  String? get userIdCorrente => db.userIdCorrente;

  Future<String?> annoGestione() async {
    final raw = await db.rpc('anno_accademico_gestione_insegnamenti');
    return raw?.toString();
  }

  Future<Map<String, dynamic>?> statoAnnuale(String? anno) => db.rpcMappa(
        'insegnamento_stato_annuale',
        parametri: <String, dynamic>{
          'p_anno_accademico': anno,
        },
      );

  Future<Map<String, dynamic>?> partecipazioneAnnuale({
    required String userId,
    required String annoAccademico,
  }) => db.singolo(
        tabella: 'partecipazioni_annuali',
        colonne: 'stato, solo_mentore',
        filtri: <FiltroDb>[
          FiltroDb('user_id', userId),
          FiltroDb('anno_accademico', annoAccademico),
        ],
      );

  Future<List<Map<String, dynamic>>> miei() =>
      db.rpcElenco('insegnamenti_miei');

  Future<void> selezionaPerAnno({
    required String insegnamentoId,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_seleziona_per_anno',
      parametri: <String, dynamic>{
        'p_insegnamento_id': insegnamentoId,
        'p_anno_accademico': annoAccademico,
      },
    );
  }

  Future<void> creaPerAnno({
    required Map<String, dynamic> valori,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_crea_per_anno',
      parametri: <String, dynamic>{
        'p_valori': valori,
        'p_anno_accademico': annoAccademico,
      },
    );
  }

  Future<void> modificaAutorizzata({
    required String insegnamentoId,
    required Map<String, dynamic> valori,
    required String? annoAccademico,
  }) async {
    await db.rpc(
      'insegnamento_modifica_autorizzata',
      parametri: <String, dynamic>{
        'p_insegnamento_id': insegnamentoId,
        'p_valori': valori,
        'p_anno_accademico': annoAccademico,
      },
    );
  }
}

// ============================================================================
// BACKOFFICE - REPOSITORY CONDIVISO TRANSITORIO
// ============================================================================
// Mantiene invariata la logica esistente mentre ogni pagina usa un proprio
// controller. Nei passaggi successivi i metodi verranno progressivamente
// distribuiti nelle classi di dominio sopra senza cambiare l'interfaccia.

/// Componente `BackofficeRepository`: incapsula responsabilità specifiche del relativo modulo.
class BackofficeRepository extends ChangeNotifier {
  BackofficeRepository(this.sessione);

  final AutorizzazioniBackoffice sessione;

  final partecipanti = <Map<String, dynamic>>[];
  final riservati = <String, Map<String, dynamic>>{};
  final ruoli = <String, String>{};
  final abilitazioni = <Map<String, dynamic>>[];
  final partecipazioniAnnuali = <Map<String, dynamic>>[];
  final anni = <Map<String, dynamic>>[];
  final insegnamenti = <Map<String, dynamic>>[];
  final mentoraggi = <Map<String, dynamic>>[];
  final assegnazioni = <Map<String, dynamic>>[];

  List<String> ruoliDisponibili = const <String>[];
  List<String> tipiMentoreDisponibili = const <String>[];

  bool caricamento = false;
  String? errore;

  bool get soloOwner => sessione.repositorySoloOwner;
  bool get puoAmministrare => sessione.repositoryPuoAmministrare;

  static const List<String> ambitiInsegnamento = <String>[
    'insegnamento_selezione',
    'insegnamento_creazione',
    'insegnamento_modifica',
    'insegnamento_non_richiesto',
  ];

  String? get annoAttivo {
    for (final anno in anni) {
      if (anno['stato']?.toString() == 'attivo' || _vero(anno['corrente'])) {
        final codice = anno['codice']?.toString();
        if (codice != null && codice.isNotEmpty) return codice;
      }
    }
    return null;
  }

  String? get annoPreparazione {
    for (final anno in anni) {
      if (anno['stato']?.toString() == 'preparazione') {
        final codice = anno['codice']?.toString();
        if (codice != null && codice.isNotEmpty) return codice;
      }
    }
    return null;
  }

  /// Anno usato per conferma/creazione/modifica dell'insegnamento.
  /// Se esiste un anno in preparazione viene usato quello; altrimenti
  /// l'anno operativo attivo.
  String? get annoGestioneInsegnamenti => annoPreparazione ?? annoAttivo;

  /// Compatibilità con il codice precedente: "corrente" = anno operativo.
  String? get annoCorrente => annoAttivo;

  bool abilitazioneAttiva(
    String userId,
    String ambito,
    String annoAccademico,
  ) {
    final adesso = DateTime.now();
    for (final riga in abilitazioni) {
      if (riga['user_id']?.toString() != userId ||
          riga['ambito']?.toString() != ambito ||
          riga['anno_accademico']?.toString() != annoAccademico) {
        continue;
      }
      if (riga['abilitata'] != true || riga['revocata_at'] != null) {
        return false;
      }
      final scadenza = DateTime.tryParse(riga['scade_at']?.toString() ?? '');
      return scadenza == null || scadenza.isAfter(adesso);
    }
    return false;
  }

  Map<String, dynamic>? partecipazioneAnnuale(
    String userId,
    String annoAccademico,
  ) {
    for (final riga in partecipazioniAnnuali) {
      if (riga['user_id']?.toString() == userId &&
          riga['anno_accademico']?.toString() == annoAccademico) {
        return riga;
      }
    }
    return null;
  }

  String statoPartecipazione(String userId, String annoAccademico) =>
      partecipazioneAnnuale(userId, annoAccademico)?['stato']?.toString() ??
      'non_presente';

  bool gestioneInsegnamentiAttiva(String userId) {
    final anno = annoGestioneInsegnamenti;
    if (anno == null) return false;
    return abilitazioneAttiva(userId, 'insegnamento_creazione', anno) &&
        abilitazioneAttiva(userId, 'insegnamento_modifica', anno);
  }

  Future<String?> impostaGestioneInsegnamentiCorrente(
    String userId,
    bool abilita,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }

        final anno = annoGestioneInsegnamenti;
        if (anno == null) {
          throw const AppException(
            'Nessun anno accademico attivo o in preparazione configurato.',
          );
        }

        if (abilita) {
          final stato = statoPartecipazione(userId, anno);
          if (annoPreparazione == anno &&
              stato != 'confermato' &&
              stato != 'nuovo') {
            throw const AppException(
              'Per l’anno in preparazione il partecipante deve prima '
              'confermare la partecipazione.',
            );
          }

          await SupabaseConfig.client.rpc(
            'abilitazione_modifica_imposta',
            params: <String, dynamic>{
              'p_user_id': userId,
              'p_ambito': 'insegnamento_non_richiesto',
              'p_anno_accademico': anno,
              'p_abilitata': false,
              'p_scade_at': null,
            },
          );
        }

        for (final ambito in const <String>[
          'insegnamento_creazione',
          'insegnamento_modifica',
          'insegnamento_selezione',
        ]) {
          await SupabaseConfig.client.rpc(
            'abilitazione_modifica_imposta',
            params: <String, dynamic>{
              'p_user_id': userId,
              'p_ambito': ambito,
              'p_anno_accademico': anno,
              'p_abilitata': abilita,
              'p_scade_at': null,
            },
          );
        }
      });

  String nomeUtente(Object? id) {
    final persona = personaPerId(id?.toString());
    if (persona == null) return id?.toString() ?? '';
    final nome = '${persona['cognome'] ?? ''} ${persona['nome'] ?? ''}'.trim();
    return nome.isEmpty ? persona['email_unipa']?.toString() ?? '' : nome;
  }

  Map<String, dynamic>? personaPerId(String? userId) {
    if (userId == null) return null;
    for (final persona in partecipanti) {
      if (persona['user_id']?.toString() == userId) return persona;
    }
    return null;
  }

  String etichettaPersona(String? userId) {
    final persona = personaPerId(userId);
    if (persona == null) return userId ?? '—';
    final nome = '${persona['cognome'] ?? ''} ${persona['nome'] ?? ''}'.trim();
    final email = persona['email_unipa']?.toString().trim() ?? '';
    if (nome.isEmpty) return email.isEmpty ? userId ?? '—' : email;
    return email.isEmpty ? nome : '$nome — $email';
  }

  Map<String, dynamic>? insegnamentoPerId(String? id) {
    if (id == null) return null;
    for (final riga in insegnamenti) {
      if (riga['id']?.toString() == id) return riga;
    }
    return null;
  }

  Future<void> carica() async {
    caricamento = true;
    errore = null;
    notifyListeners();

    try {
      final db = SupabaseConfig.client;
      final risultati = await Future.wait<dynamic>([
        db.from('anagrafica').select(),
        db.from('anagrafica_riservata').select(),
        db
            .from('abilitazioni_modifica')
            .select()
            .order('richiesta_at', ascending: false),
        db.from('partecipazioni_annuali').select(),
        db.from('anni_accademici').select().order('codice', ascending: false),
        db.from('insegnamenti').select(),
        db.from('mentoraggi').select(),
        db.from('mentoraggio_mentori').select(),
      ]);

      final elencoPartecipanti = (risultati[0] as List)
          .cast<Map<String, dynamic>>()
          .toList(growable: true)
        ..sort((a, b) {
          final cognomeA = a['cognome']?.toString().trim().toLowerCase() ?? '';
          final cognomeB = b['cognome']?.toString().trim().toLowerCase() ?? '';
          final c = cognomeA.compareTo(cognomeB);
          if (c != 0) return c;
          final nomeA = a['nome']?.toString().trim().toLowerCase() ?? '';
          final nomeB = b['nome']?.toString().trim().toLowerCase() ?? '';
          return nomeA.compareTo(nomeB);
        });

      partecipanti
        ..clear()
        ..addAll(elencoPartecipanti);

      riservati.clear();
      for (final r in (risultati[1] as List).cast<Map<String, dynamic>>()) {
        riservati[r['user_id'].toString()] = r;
      }

      abilitazioni
        ..clear()
        ..addAll((risultati[2] as List).cast<Map<String, dynamic>>());
      partecipazioniAnnuali
        ..clear()
        ..addAll((risultati[3] as List).cast<Map<String, dynamic>>());
      anni
        ..clear()
        ..addAll((risultati[4] as List).cast<Map<String, dynamic>>());
      insegnamenti
        ..clear()
        ..addAll((risultati[5] as List).cast<Map<String, dynamic>>());
      mentoraggi
        ..clear()
        ..addAll((risultati[6] as List).cast<Map<String, dynamic>>());
      assegnazioni
        ..clear()
        ..addAll((risultati[7] as List).cast<Map<String, dynamic>>());

      final schema = await RepositoryComune().schemaDatabase();
      ruoliDisponibili =
          schema.tabella('user_roles')?.campo('role')?.valoriScelta ??
          const <String>[];
      tipiMentoreDisponibili =
          schema.tabella('mentoraggio_mentori')?.campo('tipo')?.valoriScelta ??
          const <String>[];

      ruoli.clear();
      if (puoAmministrare) {
        final righe = await db.from('user_roles').select('user_id, role');
        for (final r in righe) {
          ruoli[r['user_id'].toString()] = r['role'].toString();
        }
      }
    } catch (e) {
      errore = AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Impossibile caricare i dati amministrativi.',
      ).messaggio;
    } finally {
      caricamento = false;
      notifyListeners();
    }
  }

  Future<String?> salvaAnagrafica(
    String userId,
    Map<String, dynamic> valori, {
    Map<String, dynamic>? originali,
  }) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }

        final schema = await RepositoryComune().schemaDatabase();
        final tabella = schema.tabella('anagrafica');
        final dati = <String, dynamic>{};
        for (final voce in valori.entries) {
          if (voce.key == 'user_id') continue;
          final campo = tabella?.campo(voce.key);
          if (campo != null &&
              (campo.chiavePrimaria ||
                  campo.identita ||
                  campo.generato ||
                  campo.solaLettura)) {
            continue;
          }
          if (originali != null && originali[voce.key] == voce.value) continue;
          dati[voce.key] = voce.value;
        }
        if (dati.isEmpty) return;

        final nuovaEmail = dati.remove('email_unipa')?.toString().trim();
        if (nuovaEmail != null && nuovaEmail.isNotEmpty) {
          await _invocaUserAdmin(<String, dynamic>{
            'action': 'update_email',
            'user_id': userId,
            'email': nuovaEmail,
          });
        }
        if (dati.isNotEmpty) {
          await SupabaseConfig.client
              .from('anagrafica')
              .update(dati)
              .eq('user_id', userId);
        }
      });

  Future<Map<String, dynamic>> _invocaUserAdmin(
    Map<String, dynamic> body,
  ) async {
    final risposta = await SupabaseConfig.client.functions.invoke(
      'backoffice-user-admin',
      body: body,
    );
    final data = risposta.data;
    if (data is String &&
        data.trimLeft().toLowerCase().startsWith('<!doctype html')) {
      throw const AppException(
        'La chiamata a backoffice-user-admin ha ricevuto la pagina HTML di Flutter. '
        'Deploya la Edge Function su Supabase e verifica SUPABASE_URL.',
      );
    }
    if (risposta.status < 200 || risposta.status >= 300) {
      throw AppException('Edge Function (${risposta.status}): $data');
    }
    if (data is Map) return Map<String, dynamic>.from(data);
    throw AppException('Risposta non JSON dalla Edge Function: $data');
  }

  Future<String?> creaPartecipante(
    Map<String, dynamic> valori,
    String passwordTemporanea,
  ) async {
    try {
      if (!puoAmministrare) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      final email =
          valori['email_unipa']?.toString().trim() ?? '';

      if (email.isEmpty) {
        throw const AppException(
          'Email UNIPA obbligatoria per creare l’utente.',
        );
      }

      if (passwordTemporanea.length < 8) {
        throw const AppException(
          'La password temporanea deve avere almeno 8 caratteri.',
        );
      }

      final risposta =
          await SupabaseConfig.client.functions.invoke(
        'backoffice-user-admin',
        body: <String, dynamic>{
          'action': 'create_user',
          'email': email,
          'password': passwordTemporanea,
          'anagrafica': valori,
          'anagrafica_riservata': <String, dynamic>{
            'attivo': true,
          },
        },
      );

      final data = risposta.data;

      if (risposta.status < 200 ||
          risposta.status >= 300) {
        return 'Edge Function ${risposta.status}: $data';
      }

      await carica();

      return null;
    } catch (e) {
      return 'Creazione partecipante non riuscita: $e';
    }
  }
  
    Future<String?> reimpostaPassword(
    String userId,
    String nuovaPassword,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        if (nuovaPassword.length < 8) {
          throw const AppException(
            'La nuova password deve avere almeno 8 caratteri.',
          );
        }
        await _invocaUserAdmin(<String, dynamic>{
          'action': 'reset_password',
          'user_id': userId,
          'password': nuovaPassword,
        });
      });

  Future<String?> eliminaPartecipante(String userId) =>
      _esegui(() async {
        if (!soloOwner) {
          throw const AppException('Operazione riservata al proprietario.');
        }
        await _invocaUserAdmin(<String, dynamic>{
          'action': 'delete_user',
          'user_id': userId,
        });
      });

  Future<String?> salvaRiservati(
    String userId,
    bool attivo,
    String note, {
    bool? attivoOriginale,
  }) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }

        if (attivoOriginale == null || attivoOriginale != attivo) {
          await _invocaUserAdmin(<String, dynamic>{
            'action': 'set_banned',
            'user_id': userId,
            'banned': !attivo,
          });
        }

        await SupabaseConfig.client.from('anagrafica_riservata').upsert({
          'user_id': userId,
          'attivo': attivo,
          'note_storiche': note.trim().isEmpty ? null : note.trim(),
        });
      });

  Future<String?> cambiaRuolo(String userId, String ruolo) =>
      _esegui(() async {
        if (!soloOwner) {
          throw const AppException('Operazione riservata al proprietario.');
        }
        await SupabaseConfig.client
            .from('user_roles')
            .update({'role': ruolo})
            .eq('user_id', userId);
      });

  Future<String?> cambiaAbilitazione(
    Map<String, dynamic> riga,
    bool abilita,
  ) =>
      _esegui(() async {
        final adesso = DateTime.now().toIso8601String();
        await SupabaseConfig.client
            .from('abilitazioni_modifica')
            .update(
              abilita
                  ? {
                      'abilitata': true,
                      'abilitata_da': sessione.repositoryUserId,
                      'abilitata_at': adesso,
                      'revocata_at': null,
                    }
                  : {'abilitata': false, 'revocata_at': adesso},
            )
            .eq('user_id', riga['user_id'])
            .eq('ambito', riga['ambito'])
            .eq('anno_accademico', riga['anno_accademico']);
      });

  Future<String?> impostaAbilitazioniInsegnamento(
    String userId,
    String annoAccademico,
    Map<String, bool> valori,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }

        final normalizzati = <String, bool>{
          for (final ambito in ambitiInsegnamento)
            ambito: valori[ambito] == true,
        };
        if (normalizzati['insegnamento_non_richiesto'] == true) {
          normalizzati['insegnamento_selezione'] = false;
          normalizzati['insegnamento_creazione'] = false;
        }

        for (final entry in normalizzati.entries) {
          await SupabaseConfig.client.rpc(
            'abilitazione_modifica_imposta',
            params: <String, dynamic>{
              'p_user_id': userId,
              'p_ambito': entry.key,
              'p_anno_accademico': annoAccademico,
              'p_abilitata': entry.value,
              'p_scade_at': null,
            },
          );
        }
      });

  Future<String?> impostaPartecipazioneAnnuale(
    String userId,
    String annoAccademico,
    String stato,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        await SupabaseConfig.client.rpc(
          'partecipazione_annuale_imposta',
          params: <String, dynamic>{
            'p_user_id': userId,
            'p_anno_accademico': annoAccademico,
            'p_stato': stato,
            'p_note': null,
          },
        );
      });

  Future<String?> generaRichiestePartecipazione(
    String annoDestinazione, {
    String? annoSorgente,
  }) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        await SupabaseConfig.client.rpc(
          'partecipazioni_annuali_genera',
          params: <String, dynamic>{
            'p_anno_destinazione': annoDestinazione,
            'p_anno_sorgente': annoSorgente,
          },
        );
      });

  Future<String?> aggiungiAnno(String codice, String? inizio, String? fine) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione riservata al backoffice.');
        }
        await SupabaseConfig.client.from('anni_accademici').insert({
          'codice': codice.trim(),
          'data_inizio': _vuotoNull(inizio),
          'data_fine': _vuotoNull(fine),
          'corrente': false,
          'stato': 'chiuso',
        });
      });

  Future<String?> impostaStatoAnno(String codice, String stato) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione riservata al backoffice.');
        }
        await SupabaseConfig.client.rpc(
          'imposta_stato_anno_accademico',
          params: <String, dynamic>{'p_codice': codice, 'p_stato': stato},
        );
      });

  Future<String?> impostaAnnoCorrente(String codice) =>
      impostaStatoAnno(codice, 'attivo');


Future<String?> salvaInsegnamentoBackoffice(
  Map<String, dynamic> valori, {
  String? insegnamentoId,
  String? docenteIdForzato,
}) =>
    _esegui(() async {
      if (!puoAmministrare) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      final dati =
          Map<String, dynamic>.from(valori)
            ..remove('id')
            ..remove('created_at')
            ..remove('updated_at');

      if (docenteIdForzato != null) {
        dati['docente_id'] = docenteIdForzato;
      }

      final docenteId =
          dati['docente_id']?.toString().trim() ?? '';

      final nomeInsegnamento =
          dati['insegnamento']?.toString().trim() ?? '';

      if (docenteId.isEmpty) {
        throw const AppException(
          'Devi selezionare il docente.',
        );
      }

      if (nomeInsegnamento.isEmpty) {
        throw const AppException(
          'Il nome dell’insegnamento è obbligatorio.',
        );
      }

      if (insegnamentoId == null) {
        await SupabaseConfig.client
            .from('insegnamenti')
            .insert(dati);

        return;
      }

      await SupabaseConfig.client
          .from('insegnamenti')
          .update(dati)
          .eq(
            'id',
            insegnamentoId,
          );
    });


Future<String?> eliminaInsegnamentoBackoffice(
  String insegnamentoId,
) =>
    _esegui(() async {
      if (!puoAmministrare) {
        throw const AppException('Operazione non autorizzata.');
      }

      final righe = await SupabaseConfig.client
          .from('mentoraggi')
          .select('id, anno_accademico, stato')
          .eq('insegnamento_id', insegnamentoId);

      final completati = (righe as List)
          .map((riga) => Map<String, dynamic>.from(riga as Map))
          .where(
            (riga) =>
                riga['stato']?.toString().trim().toLowerCase() ==
                'completato',
          )
          .toList(growable: false);

      if (completati.isNotEmpty) {
        final anni = completati
            .map((riga) => riga['anno_accademico']?.toString())
            .whereType<String>()
            .where((anno) => anno.isNotEmpty)
            .toSet()
            .join(', ');

        throw AppException(
          'Impossibile eliminare l’insegnamento: '
          'esistono mentoraggi completati'
          '${anni.isEmpty ? '.' : ' negli anni $anni.'}',
        );
      }

      await SupabaseConfig.client
          .from('insegnamenti')
          .delete()
          .eq('id', insegnamentoId);
    });


Future<String?> creaMentoraggioBackoffice(
  String insegnamentoId,
  String annoAccademico,
) =>
    _esegui(() async {
      if (!puoAmministrare) {
        throw const AppException(
          'Operazione non autorizzata.',
        );
      }

      final anno = annoAccademico.trim();

      if (anno.isEmpty) {
        throw const AppException(
          'Anno accademico obbligatorio.',
        );
      }

      // Verifica direttamente sul database.
      final esistenti =
          await SupabaseConfig.client
              .from('mentoraggi')
              .select('id')
              .eq(
                'insegnamento_id',
                insegnamentoId,
              )
              .eq(
                'anno_accademico',
                anno,
              )
              .limit(1);

      if (esistenti.isNotEmpty) {
        throw AppException(
          'Esiste già un mentoraggio per questo '
          'insegnamento nell’anno accademico $anno.',
        );
      }

      await SupabaseConfig.client
          .from('mentoraggi')
          .insert({
        'insegnamento_id':
            insegnamentoId,
        'anno_accademico':
            anno,
      });
    });

  Future<String?> salvaMentoraggioBackoffice(
    String mentoraggioId,
    Map<String, dynamic> valori,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        final dati = Map<String, dynamic>.from(valori)
          ..remove('id')
          ..remove('created_at')
          ..remove('updated_at');
        await SupabaseConfig.client
            .from('mentoraggi')
            .update(dati)
            .eq('id', mentoraggioId);
      });


  Future<String?> eliminaMentoraggioBackoffice(
    String mentoraggioId,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }

        final riga = await SupabaseConfig.client
            .from('mentoraggi')
            .select('id, stato, anno_accademico')
            .eq('id', mentoraggioId)
            .maybeSingle();

        if (riga == null) {
          throw const AppException('Mentoraggio non trovato.');
        }

        final stato =
            riga['stato']?.toString().trim().toLowerCase() ?? '';

        if (stato == 'completato') {
          throw const AppException(
            'Un mentoraggio completato non può essere eliminato.',
          );
        }

        await SupabaseConfig.client
            .from('mentoraggi')
            .delete()
            .eq('id', mentoraggioId);
      });

  Future<String?> aggiungiAssegnazione(
    String mentoraggioId,
    String mentoreId,
    String tipo,
  ) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        final duplicato = assegnazioni.any(
          (riga) =>
              riga['mentoraggio_id']?.toString() == mentoraggioId &&
              riga['mentore_id']?.toString() == mentoreId &&
              riga['tipo']?.toString() == tipo,
        );
        if (duplicato) {
          throw const AppException(
            'Questa persona è già assegnata al mentoraggio con lo stesso ruolo.',
          );
        }
        await SupabaseConfig.client.from('mentoraggio_mentori').insert({
          'mentoraggio_id': mentoraggioId,
          'mentore_id': mentoreId,
          'tipo': tipo,
          'assegnato_il': DateTime.now().toIso8601String().split('T').first,
        });
      });

  Future<String?> eliminaAssegnazione(Map<String, dynamic> riga) =>
      _esegui(() async {
        if (!puoAmministrare) {
          throw const AppException('Operazione non autorizzata.');
        }
        await SupabaseConfig.client
            .from('mentoraggio_mentori')
            .delete()
            .eq('mentoraggio_id', riga['mentoraggio_id'])
            .eq('mentore_id', riga['mentore_id'])
            .eq('tipo', riga['tipo']);
      });

  Future<String?> _esegui(Future<void> Function() azione) async {
    try {
      await azione();
      await carica();
      return null;
    } catch (e) {
      return AppErrorMapper.converti(
        e,
        messaggioGenerico: 'Operazione amministrativa non riuscita.',
      ).messaggio;
    }
  }

  Future<String?> importaPartecipanti(
    String annoAccademico,
  ) async {
    try {
      if (!soloOwner) {
        throw const AppException(
          'Operazione riservata al proprietario.',
        );
      }

      final risposta =
          await SupabaseConfig.client.functions.invoke(
        'backoffice-user-admin',
        body: <String, dynamic>{
          'action': 'import_participants',
          'anno_accademico': annoAccademico,
        },
      );

      final data = risposta.data;

      if (risposta.status < 200 ||
          risposta.status >= 300) {
        return 'Edge Function ${risposta.status}: $data';
      }

      return null;
    } catch (e) {
      return 'Importazione non riuscita: $e';
    }
  }

  Future<String?> importaInsegnamenti(
    String annoAccademico,
  ) async {
    try {
      if (!soloOwner) {
        throw const AppException(
          'Operazione riservata al proprietario.',
        );
      }

      final risposta =
          await SupabaseConfig.client.functions.invoke(
        'backoffice-user-admin',
        body: <String, dynamic>{
          'action': 'import_insegnamenti',
          'anno_accademico': annoAccademico,
        },
      );

      final data = risposta.data;

      if (risposta.status < 200 ||
          risposta.status >= 300) {
        return 'Edge Function ${risposta.status}: $data';
      }

      if (data is Map) {
        final risultato =
            Map<String, dynamic>.from(data);

        final totale = risultato['totale'] ?? 0;
        final creati = risultato['creati'] ?? 0;
        final errori = risultato['errori'] ?? 0;

        await carica();

        if (errori != 0) {
          return 'Importazione completata: '
              '$creati di $totale creati, '
              '$errori errori. '
              'Controlla import_insegnamenti.errore.';
        }
      }

      return null;
    } catch (e) {
      return 'Importazione insegnamenti non riuscita: $e';
    }
  }

}

bool _vero(Object? valore) {
  if (valore == true) return true;
  if (valore == false || valore == null) return false;
  final testo = valore.toString().trim().toLowerCase();
  return testo == 'true' || testo == 't' || testo == '1' || testo == 'yes';
}

String? _vuotoNull(String? valore) =>
    valore == null || valore.trim().isEmpty ? null : valore.trim();

// ============================================================================
// NOTIFICHE
// ============================================================================

/// Accesso centralizzato ai dati e alle funzioni Supabase dell'area notifiche.
///
/// Tutte le operazioni remote della pagina notifiche passano da questa classe:
/// le pagine e i controller non costruiscono query Supabase direttamente.
class NotificheRepository {
  NotificheRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  /// Flusso di autenticazione usato dal servizio push per sincronizzare il device.
  Stream<AuthState> get cambiAutenticazione => _client.auth.onAuthStateChange;

  bool get utenteAutenticato => _client.auth.currentUser != null;

  /// Carica lo schema DB usato dai dialog dinamici delle notifiche.
  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();


  /// Conta le notifiche consegnate all'utente corrente usate per il badge.
  Future<int> contaNotificheNonLette() async {
    final userId = userIdCorrente;
    if (userId == null) return 0;
    final List<dynamic> raw = await _client
        .from('notifiche_destinatari')
        .select('id')
        .eq('user_id', userId)
        .eq('stato', 'inviato');
    return raw.length;
  }

  Future<void> registraDispositivo({
    required String token,
    required String piattaforma,
  }) async {
    await _client.rpc(
      'notifiche_registra_dispositivo',
      params: <String, dynamic>{
        'p_token': token,
        'p_piattaforma': piattaforma,
      },
    );
  }

  Future<void> disattivaDispositivo(String token) async {
    await _client.rpc(
      'notifiche_disattiva_dispositivo',
      params: <String, dynamic>{'p_token': token},
    );
  }

  /// Restituisce gli ultimi messaggi creati, dal più recente al più vecchio.
  Future<List<Map<String, dynamic>>> messaggi({int limite = 200}) async {
    final List<dynamic> raw = await _client
        .from('notifiche_messaggi')
        .select()
        .order('created_at', ascending: false)
        .limit(limite);
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Restituisce il dettaglio dei destinatari generati per un messaggio.
  Future<List<Map<String, dynamic>>> destinatariMessaggio(
    String messaggioId,
  ) async {
    final dynamic raw = await _client.rpc(
      'notifiche_dettaglio_destinatari',
      params: <String, dynamic>{'p_messaggio_id': messaggioId},
    );
    if (raw == null) return const <Map<String, dynamic>>[];
    return (raw as List<dynamic>)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Carica le possibili scelte per un tipo di destinatario manuale.
  Future<List<Map<String, dynamic>>> opzioniDestinatari(String tipo) async {
    dynamic raw;
    switch (tipo) {
      case 'iscritti_evento':
        raw = await _client
            .from('eventi')
            .select()
            .order('created_at', ascending: false);
        break;
      case 'iscritti_house_of_mentore':
        raw = await _client
            .from('house_of_mentore')
            .select()
            .order('created_at', ascending: false);
        break;
      case 'anno_accademico':
        raw = await _client
            .from('anni_accademici')
            .select('codice, corrente')
            .order('codice', ascending: false);
        break;
      case 'manuale':
        raw = await _client.rpc('notifiche_elenco_utenti_attivi');
        break;
      default:
        raw = const <dynamic>[];
    }
    return (raw as List<dynamic>)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Crea un messaggio e restituisce l'identificativo assegnato dal database.
  Future<String> creaMessaggio(Map<String, dynamic> valori) async {
    final dynamic raw = await _client
        .from('notifiche_messaggi')
        .insert(valori)
        .select('id')
        .single();
    final id = (raw as Map)['id']?.toString() ?? '';
    if (id.isEmpty) {
      throw StateError('Il database non ha restituito l’ID della notifica.');
    }
    return id;
  }

  Future<void> aggiornaMessaggio(
    String messaggioId,
    Map<String, dynamic> valori,
  ) async {
    await _client
        .from('notifiche_messaggi')
        .update(valori)
        .eq('id', messaggioId);
  }

  Future<void> eliminaMessaggio(String messaggioId) async {
    await _client.from('notifiche_messaggi').delete().eq('id', messaggioId);
  }

  Future<void> eliminaDestinatari(String messaggioId) async {
    await _client
        .from('notifiche_destinatari')
        .delete()
        .eq('messaggio_id', messaggioId);
  }

  /// Genera i destinatari e restituisce il numero calcolato dalla RPC.
  Future<int> generaDestinatari(String messaggioId) async {
    final dynamic raw = await _client
        .rpc(
          'notifiche_genera_destinatari',
          params: <String, dynamic>{'p_messaggio_id': messaggioId},
        )
        .timeout(const Duration(seconds: 30));
    if (raw is num) return raw.toInt();
    return int.tryParse(raw?.toString() ?? '') ?? 0;
  }

  /// Invoca la Edge Function che effettua l'invio push.
  ///
  /// Se l'invocazione fallisce, il messaggio viene portato nello stato
  /// `errore`, evitando che resti indefinitamente in `da_inviare`.
  Future<void> inviaMessaggio(String messaggioId) async {
    try {
      final risposta = await _client.functions
          .invoke(
            'notifiche-invia',
            body: <String, dynamic>{'messaggio_id': messaggioId},
          )
          .timeout(const Duration(seconds: 30));
      if (risposta.status < 200 || risposta.status >= 300) {
        throw StateError(
          'Invio push non riuscito (HTTP ${risposta.status}): ${risposta.data}',
        );
      }
    } catch (e) {
      try {
        await aggiornaMessaggio(
          messaggioId,
          <String, dynamic>{'stato': 'errore'},
        );
      } catch (_) {
        // Conserva l'errore originale dell'invio: è il dato più utile alla UI.
      }
      rethrow;
    }
  }

  /// Carica i destinatari consegnati all'utente corrente per la pagina notifiche.
  Future<List<Map<String, dynamic>>> notificheRicevute({int limite = 20}) async {
    final userId = userIdCorrente;
    if (userId == null) return const <Map<String, dynamic>>[];
    final raw = await _client
        .from('notifiche_destinatari')
        .select('id, messaggio_id, stato, inviato_at, letto_at, created_at')
        .eq('user_id', userId)
        .inFilter('stato', const <String>['inviato', 'letto'])
        .order('created_at', ascending: false)
        .limit(limite);
    return (raw as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Carica i messaggi indicati, indicizzabili poi per ID dal controller.
  Future<List<Map<String, dynamic>>> messaggiPerIds(List<String> ids) async {
    if (ids.isEmpty) return const <Map<String, dynamic>>[];
    final raw = await _client
        .from('notifiche_messaggi')
        .select('id, titolo, messaggio, anno_accademico, origine_tabella, origine_id, inviata_at, created_at')
        .inFilter('id', ids);
    return (raw as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  /// Segna come letto un destinatario tramite la RPC applicativa.
  Future<void> segnaDestinatarioLetto(String destinatarioId) => _client.rpc(
        'notifiche_segna_letta',
        params: <String, dynamic>{'p_destinatario_id': destinatarioId},
      );

  Future<List<Map<String, dynamic>>> regole() async {
    final List<dynamic> raw = await _client
        .from('notifiche_regole')
        .select()
        .order('codice');
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  Future<void> impostaRegolaAttiva(String id, bool attiva) async {
    await _client.from('notifiche_regole').update(
      <String, dynamic>{'attiva': attiva},
    ).eq('id', id);
  }

  Future<void> eliminaRegola(Object id) async {
    await _client.from('notifiche_regole').delete().eq('id', id);
  }

  Future<void> salvaRegola({
    Object? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('notifiche_regole').insert(valori);
    } else {
      await _client.from('notifiche_regole').update(valori).eq('id', id);
    }
  }
}

// ============================================================================
// PROFILO
// ============================================================================

/// Operazioni Supabase dell'area Profilo.
class ProfiloRepository {
  ProfiloRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();

  Future<Map<String, dynamic>?> profiloCorrente() async {
    final userId = userIdCorrente;
    if (userId == null) return null;
    final raw = await _client
        .from('anagrafica')
        .select()
        .eq('user_id', userId)
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<List<Map<String, dynamic>>> ssd() async {
    final List<dynamic> raw = await _client
        .from('ssd')
        .select('cod_ssd, gsd, area')
        .order('cod_ssd');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw
        .map((e) => (e as Map)['codice']?.toString())
        .whereType<String>()
        .toSet()
        .toList(growable: false);
  }

  Future<Map<String, dynamic>?> statoPartecipazioneAnnuale() async {
    final raw = await _client.rpc('partecipazione_annuale_stato');
    return raw is Map ? Map<String, dynamic>.from(raw) : null;
  }

  Future<Map<String, dynamic>?> partecipazioneAnnuale(String anno) async {
    final userId = userIdCorrente;
    if (userId == null) return null;
    final raw = await _client
        .from('partecipazioni_annuali')
        .select()
        .eq('user_id', userId)
        .eq('anno_accademico', anno)
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<bool> puoModificareCorrente() async {
    final raw = await _client.rpc(
      'puo_modificare_corrente',
      params: const <String, dynamic>{'p_ambito': 'anagrafica'},
    );
    return raw == true;
  }

  Future<Map<String, dynamic>> rispondiPartecipazione(bool partecipa) async {
    final raw = await _client.rpc(
      'partecipazione_annuale_rispondi',
      params: <String, dynamic>{'p_partecipa': partecipa},
    );
    return Map<String, dynamic>.from(raw as Map);
  }

  Future<void> aggiornaPartecipazioneAnnuale({
    required String anno,
    required Map<String, dynamic> valori,
  }) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione assente.');
    await _client
        .from('partecipazioni_annuali')
        .update(valori)
        .eq('user_id', userId)
        .eq('anno_accademico', anno);
  }

  Future<void> cambiaPassword(String nuovaPassword) async {
    await _client.auth.updateUser(UserAttributes(password: nuovaPassword));
  }

  Future<void> richiediModifica() async {
    await _client.rpc(
      'richiedi_abilitazione',
      params: const <String, dynamic>{'p_ambito': 'anagrafica'},
    );
  }

  Future<Map<String, dynamic>?> aggiornaProfilo(
    Map<String, dynamic> valori,
  ) async {
    final userId = userIdCorrente;
    if (userId == null) return null;
    final raw = await _client
        .from('anagrafica')
        .update(valori)
        .eq('user_id', userId)
        .select()
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }
}

// ============================================================================
// CONTATTI
// ============================================================================

/// Operazioni Supabase della pagina Contatti.
class ContattiRepository {
  ContattiRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  Future<List<Map<String, dynamic>>> contattiPubblici({
    required String colonne,
  }) async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select(colonne)
        .order('cognome', ascending: true)
        .order('nome', ascending: true);
    return raw
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList(growable: false);
  }

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();
}

// ============================================================================
// EVENTI
// ============================================================================

/// Operazioni Supabase della pagina Eventi.
class EventiRepository {
  EventiRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();

  Future<List<Map<String, dynamic>>> eventi({required bool includiNonAttivi}) async {
    dynamic query = _client.from('eventi').select(
      'id, titolo, anno_accademico, luogo, data_evento, tipologia, '
      'descrizione, modalita, relatori, moderatori, note_organizzative, '
      'locandina_url, data_apertura_iscrizioni, data_chiusura_iscrizioni, '
      'attiva, created_at',
    );
    if (!includiNonAttivi) query = query.eq('attiva', true);
    final List<dynamic> raw = await query.order('data_evento', ascending: false);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> partecipazioni({String? userId}) async {
    dynamic query = _client.from('partecipazioni_eventi').select(
      'evento_id, partecipante_id, data_iscrizione, presente',
    );
    if (userId != null) query = query.eq('partecipante_id', userId);
    if (userId == null) query = query.order('data_iscrizione', ascending: true);
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw.map((e) => (e as Map)['codice'].toString()).toList();
  }

  Future<List<Map<String, dynamic>>> questionariApertiInterni() async {
    final List<dynamic> raw = await _client
        .from('questionari')
        .select('id, evento_id')
        .eq('provider', 'interno')
        .eq('aperto', true);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> compilazioni({String? userId}) async {
    dynamic query = _client
        .from('questionari_compilazioni')
        .select('questionario_id, user_id, inviato_at');
    if (userId != null) query = query.eq('user_id', userId);
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> anagraficheEssenziali() async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select('user_id, nome, cognome');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> iscrivi({required String eventoId, required String userId}) async {
    await _client.from('partecipazioni_eventi').insert(<String, dynamic>{
      'evento_id': eventoId,
      'partecipante_id': userId,
    });
  }

  Future<void> annullaIscrizione({
    required String eventoId,
    required String userId,
  }) async {
    await _client
        .from('partecipazioni_eventi')
        .delete()
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId);
  }

  Future<void> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) async {
    await _client
        .from('partecipazioni_eventi')
        .update(<String, dynamic>{'presente': presente})
        .eq('evento_id', eventoId)
        .eq('partecipante_id', partecipanteId);
  }

  Future<Map<String, dynamic>?> evento(String id, {String colonne = '*'}) async {
    final raw = await _client.from('eventi').select(colonne).eq('id', id).maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<String> creaEvento(Map<String, dynamic> valori) async {
    final raw = await _client
        .from('eventi')
        .insert(valori)
        .select('id')
        .single();
    return (raw as Map)['id'].toString();
  }

  Future<void> aggiornaEvento(String id, Map<String, dynamic> valori) async {
    await _client.from('eventi').update(valori).eq('id', id);
  }

  Future<bool> eliminaEvento(String id) async {
    final raw = await _client
        .from('eventi')
        .delete()
        .eq('id', id)
        .select('id')
        .maybeSingle();
    return raw != null;
  }

  Future<Map<String, dynamic>?> questionarioEvento(String eventoId) async {
    final raw = await _client
        .from('questionari')
        .select('id, template_id')
        .eq('provider', 'interno')
        .eq('evento_id', eventoId)
        .maybeSingle();
    return raw == null ? null : Map<String, dynamic>.from(raw);
  }

  Future<bool> questionarioHaCompilazioni(String questionarioId) async {
    final List<dynamic> raw = await _client
        .from('questionari_compilazioni')
        .select('id')
        .eq('questionario_id', questionarioId)
        .limit(1);
    return raw.isNotEmpty;
  }

  Future<void> creaQuestionarioEvento({
    required String eventoId,
    required String templateId,
    required String titoloEvento,
  }) async {
    await _client.from('questionari').insert(<String, dynamic>{
      'template_id': templateId,
      'titolo': 'Gradimento - $titoloEvento',
      'provider': 'interno',
      'evento_id': eventoId,
      'aperto': true,
      'created_by': userIdCorrente,
    });
  }

  Future<void> eliminaQuestionario(String id) async {
    await _client.from('questionari').delete().eq('id', id);
  }

  Future<void> aggiornaQuestionario(
    String id, {
    required String titoloEvento,
    String? templateId,
  }) async {
    await _client.from('questionari').update(<String, dynamic>{
      'template_id': ?templateId,
      'titolo': 'Gradimento - $titoloEvento',
    }).eq('id', id);
  }

  Future<void> rimuoviFileStorage({
    required String bucket,
    required String percorso,
  }) async {
    await _client.storage.from(bucket).remove(<String>[percorso]);
  }

  Future<String> caricaFilePubblico({
    required String bucket,
    required String percorso,
    required Uint8List bytes,
    required String contentType,
  }) async {
    await _client.storage.from(bucket).uploadBinary(
      percorso,
      bytes,
      fileOptions: FileOptions(
        cacheControl: '3600',
        upsert: true,
        contentType: contentType,
      ),
    );
    return _client.storage.from(bucket).getPublicUrl(percorso);
  }
}

// ============================================================================
// HOUSE OF MENTORE
// ============================================================================

/// Operazioni Supabase della pagina House of Mentore.
class HouseOfMentoreRepository {
  HouseOfMentoreRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  String? get userIdCorrente => _client.auth.currentUser?.id;

  Future<SchemaDatabase> schemaDatabase() => RepositoryComune(client: _client).schemaDatabase();

  Future<List<Map<String, dynamic>>> eventi() async {
    final List<dynamic> raw = await _client
        .from('house_of_mentore')
        .select(
          'id, titolo, descrizione, anno_accademico, data_evento, luogo, '
          'locandina_url, iscrizioni_aperte, created_at, updated_at',
        )
        .order('data_evento', ascending: false, nullsFirst: false);
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> opzioni() async {
    final List<dynamic> raw = await _client
        .from('house_of_mentore_opzioni')
        .select('id, evento_id, descrizione, ordine_visualizzazione')
        .order('ordine_visualizzazione');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> partecipazioni({String? userId}) async {
    dynamic query = _client.from('partecipazioni_house_of_mentore').select(
      userId == null
          ? 'evento_id, partecipante_id, opzione_id, data_iscrizione, presente'
          : 'evento_id, partecipante_id, opzione_id, data_iscrizione',
    );
    if (userId != null) {
      query = query.eq('partecipante_id', userId);
    } else {
      query = query.order('data_iscrizione', ascending: true);
    }
    final List<dynamic> raw = await query;
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<String>> anniAccademici() async {
    final List<dynamic> raw = await _client
        .from('anni_accademici')
        .select('codice')
        .order('codice', ascending: false);
    return raw.map((e) => (e as Map)['codice'].toString()).toList();
  }

  Future<List<Map<String, dynamic>>> anagraficheEssenziali() async {
    final List<dynamic> raw = await _client
        .from('anagrafica')
        .select('user_id, nome, cognome');
    return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> aggiornaPresenza({
    required String eventoId,
    required String partecipanteId,
    required bool presente,
  }) async {
    await _client
        .from('partecipazioni_house_of_mentore')
        .update(<String, dynamic>{'presente': presente})
        .eq('evento_id', eventoId)
        .eq('partecipante_id', partecipanteId);
  }

  Future<void> salvaEvento({
    String? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('house_of_mentore').insert(valori);
    } else {
      await _client.from('house_of_mentore').update(valori).eq('id', id);
    }
  }

  Future<void> eliminaEvento(String id) async {
    await _client.from('house_of_mentore').delete().eq('id', id);
  }

  Future<void> salvaOpzione({
    String? id,
    required Map<String, dynamic> valori,
  }) async {
    if (id == null) {
      await _client.from('house_of_mentore_opzioni').insert(valori);
    } else {
      await _client.from('house_of_mentore_opzioni').update(valori).eq('id', id);
    }
  }

  Future<void> eliminaOpzione(String id) async {
    await _client.from('house_of_mentore_opzioni').delete().eq('id', id);
  }

  Future<void> scegliOpzione({
    required String eventoId,
    required String opzioneId,
  }) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione non valida.');
    final esistente = await _client
        .from('partecipazioni_house_of_mentore')
        .select('evento_id')
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId)
        .maybeSingle();
    if (esistente == null) {
      await _client.from('partecipazioni_house_of_mentore').insert(
        <String, dynamic>{
          'evento_id': eventoId,
          'partecipante_id': userId,
          'opzione_id': opzioneId,
        },
      );
    } else {
      await _client
          .from('partecipazioni_house_of_mentore')
          .update(<String, dynamic>{'opzione_id': opzioneId})
          .eq('evento_id', eventoId)
          .eq('partecipante_id', userId);
    }
  }

  Future<void> cancellaIscrizione(String eventoId) async {
    final userId = userIdCorrente;
    if (userId == null) throw StateError('Sessione non valida.');
    await _client
        .from('partecipazioni_house_of_mentore')
        .delete()
        .eq('evento_id', eventoId)
        .eq('partecipante_id', userId);
  }
}

// ============================================================================
// RISORSE PER IL MENTORING
// ============================================================================

/// Operazioni Supabase per la libreria delle risorse di mentoring.
class RisorseMentoringRepository {
  RisorseMentoringRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;
  static const String bucket = 'risorse-mentoring';

  String? get userIdCorrente => _client.auth.currentUser?.id;

  /// Carica risorse attive e anni accademici disponibili.
  Future<List<dynamic>> caricaDati() => Future.wait<dynamic>([
        _client
            .from('risorse_mentoring')
            .select()
            .eq('attivo', true)
            .order('categoria')
            .order('ordine')
            .order('titolo'),
        _client
            .from('anni_accademici')
            .select('codice')
            .order('codice', ascending: false),
      ]);

  /// Carica un file nello Storage e crea il relativo record.
  Future<void> creaRisorsa({
    required Uint8List bytes,
    required String path,
    required String nomeFile,
    required String titolo,
    required String categoria,
    String? descrizione,
    String? annoAccademico,
    required String userId,
  }) async {
    await _client.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: false),
        );
    try {
      await _client.from('risorse_mentoring').insert({
        'titolo': titolo.trim(),
        'descrizione': descrizione == null || descrizione.trim().isEmpty
            ? null
            : descrizione.trim(),
        'categoria': categoria,
        'anno_accademico': annoAccademico == null || annoAccademico.isEmpty
            ? null
            : annoAccademico,
        'storage_path': path,
        'nome_file': nomeFile,
        'dimensione_bytes': bytes.lengthInBytes,
        'uploaded_by': userId,
        'attivo': true,
      });
    } catch (_) {
      try {
        await _client.storage.from(bucket).remove([path]);
      } catch (_) {}
      rethrow;
    }
  }

  /// Crea un URL temporaneo per il download della risorsa.
  Future<String> creaUrlDownload(String path) =>
      _client.storage.from(bucket).createSignedUrl(path, 60 * 30);

  /// Elimina record e, se presente, file associato.
  Future<void> eliminaRisorsa({required String id, String? path}) async {
    await _client.from('risorse_mentoring').delete().eq('id', id);
    if (path != null && path.isNotEmpty) {
      try {
        await _client.storage.from(bucket).remove([path]);
      } catch (_) {}
    }
  }
}


// ============================================================================
// QUESTIONARI
// ============================================================================

/// Componente `DatiCatalogoQuestionari`: incapsula responsabilità specifiche del relativo modulo.
class DatiCatalogoQuestionari {
  const DatiCatalogoQuestionari({
    required this.template,
    required this.domande,
    required this.questionari,
  });

  final List<Map<String, dynamic>> template;
  final List<Map<String, dynamic>> domande;
  final List<Map<String, dynamic>> questionari;
}

/// Accesso condiviso ai dati e alle RPC del modulo questionari.
class QuestionariRepository {
  QuestionariRepository({SupabaseClient? client})
      : client = client ?? SupabaseConfig.client;

  /// Repository anonimo per la compilazione dei questionari pubblici.
  ///
  /// La creazione del client senza sessione resta confinata nel livello dati,
  /// evitando che il controller conosca dettagli di connessione a Supabase.
  factory QuestionariRepository.pubblico() => QuestionariRepository(
        client: SupabaseClient(
          AppConfig.supabaseUrl,
          AppConfig.supabasePublishableKey,
          authOptions: const AuthClientOptions(autoRefreshToken: false),
        ),
      );

  final SupabaseClient client;

  String? get userIdCorrente => client.auth.currentUser?.id;

  Future<DatiCatalogoQuestionari> caricaCatalogo({
    bool includiQuestionari = true,
  }) async {
    final risultati = await Future.wait<dynamic>([
      client
          .from('questionari_template')
          .select()
          .order('destinatario')
          .order('titolo'),
      client
          .from('questionari_domande')
          .select()
          .order('template_id')
          .order('ordine'),
      if (includiQuestionari)
        client
            .from('questionari')
            .select()
            .order('created_at', ascending: false),
    ]);

    return DatiCatalogoQuestionari(
      template: mappeDa(risultati[0]),
      domande: mappeDa(risultati[1]),
      questionari: includiQuestionari
          ? mappeDa(risultati[2])
          : const <Map<String, dynamic>>[],
    );
  }

  Future<void> inserisciTemplate(Map<String, dynamic> valori) =>
      client.from('questionari_template').insert(valori);

  Future<void> aggiornaTemplate(String id, Map<String, dynamic> valori) =>
      client.from('questionari_template').update(valori).eq('id', id);

  Future<void> inserisciDomanda(Map<String, dynamic> valori) =>
      client.from('questionari_domande').insert(valori);

  Future<void> eliminaDomanda(String id) =>
      client.from('questionari_domande').delete().eq('id', id);

  Future<List<Map<String, dynamic>>> ordiniDomande(String templateId) async =>
      mappeDa(
        await client
            .from('questionari_domande')
            .select('id, ordine')
            .eq('template_id', templateId)
            .order('ordine'),
      );

  Future<void> aggiornaOrdineDomanda(String id, int ordine) => client
      .from('questionari_domande')
      .update(<String, dynamic>{'ordine': ordine})
      .eq('id', id);

  Future<void> creaQuestionarioEvento({
    required String eventoId,
    required String templateId,
    required String titolo,
  }) => client.from('questionari').insert(<String, dynamic>{
    'template_id': templateId,
    'titolo': titolo.trim(),
    'provider': 'interno',
    'evento_id': eventoId,
    'aperto': true,
    'created_by': userIdCorrente,
  });

  Future<Map<String, dynamic>?> caricaQuestionarioEvento(
    String eventoId,
  ) async {
    final questionario = await client
        .from('questionari')
        .select()
        .eq('provider', 'interno')
        .eq('evento_id', eventoId)
        .eq('aperto', true)
        .maybeSingle();
    if (questionario == null) return null;

    final domande = await client
        .from('questionari_domande')
        .select()
        .eq('template_id', questionario['template_id'])
        .order('ordine');
    return <String, dynamic>{
      'questionario': Map<String, dynamic>.from(questionario),
      'domande': mappeDa(domande),
    };
  }

  Future<bool> questionarioGiaCompilato(String questionarioId) async {
    final userId = userIdCorrente;
    if (userId == null) return false;
    final riga = await client
        .from('questionari_compilazioni')
        .select('id')
        .eq('questionario_id', questionarioId)
        .eq('user_id', userId)
        .maybeSingle();
    return riga != null;
  }

  Future<String> creaCompilazioneInterna(String questionarioId) async {
    final userId = userIdCorrente;
    if (userId == null) throw const AppException('Sessione non valida.');
    final compilazione = await client
        .from('questionari_compilazioni')
        .insert(<String, dynamic>{
          'questionario_id': questionarioId,
          'user_id': userId,
        })
        .select('id')
        .single();
    return compilazione['id'].toString();
  }

  Future<void> inserisciRisposte(
    String compilazioneId,
    Map<String, dynamic> risposte,
  ) async {
    final righe = risposte.entries
        .map(
          (entry) => <String, dynamic>{
            'compilazione_id': compilazioneId,
            'domanda_id': entry.key,
            'valore': entry.value,
          },
        )
        .toList(growable: false);
    if (righe.isNotEmpty) {
      await client.from('questionari_risposte').insert(righe);
    }
  }

  Future<void> eliminaCompilazione(String id) =>
      client.from('questionari_compilazioni').delete().eq('id', id);

  Future<Map<String, dynamic>> creaQuestionarioMentoraggio({
    required String mentoraggioId,
    required String templateId,
    required String titolo,
  }) async {
    final esistente = await client
        .from('questionari')
        .select('id')
        .eq('provider', 'pubblico')
        .eq('mentoraggio_id', mentoraggioId)
        .maybeSingle();
    if (esistente != null) {
      throw const AppException(
        'Il questionario per questo mentoraggio è già stato generato.',
      );
    }

    return Map<String, dynamic>.from(
      await client
          .from('questionari')
          .insert(<String, dynamic>{
            'template_id': templateId,
            'titolo': titolo.trim(),
            'provider': 'pubblico',
            'mentoraggio_id': mentoraggioId,
            'aperto': true,
            'created_by': userIdCorrente,
          })
          .select('id, token_pubblico')
          .single(),
    );
  }

  Future<void> impostaLinkMentoraggio(String mentoraggioId, String url) =>
      client.rpc(
        'questionario_mentoraggio_link_imposta',
        params: <String, dynamic>{
          'p_mentoraggio_id': mentoraggioId,
          'p_url': url,
        },
      );

  Future<int> contaCompilazioni(String questionarioId) async =>
      (await client
                  .from('questionari_compilazioni')
                  .select('id')
                  .eq('questionario_id', questionarioId)
              as List)
          .length;

  Future<String?> mentoraggioDelQuestionario(String questionarioId) async {
    final riga = await client
        .from('questionari')
        .select('mentoraggio_id')
        .eq('id', questionarioId)
        .maybeSingle();
    return riga?['mentoraggio_id']?.toString();
  }

  Future<void> eliminaQuestionario(String id) =>
      client.from('questionari').delete().eq('id', id);

  Future<Map<String, dynamic>> caricaRisultati(String questionarioId) async {
    final questionario = await client
        .from('questionari')
        .select('id, titolo, template_id, provider, evento_id, mentoraggio_id')
        .eq('id', questionarioId)
        .single();
    final domande = mappeDa(
      await client
          .from('questionari_domande')
          .select('id, ordine, testo, tipo, opzioni')
          .eq('template_id', questionario['template_id'])
          .order('ordine'),
    );
    final compilazioni = mappeDa(
      await client
          .from('questionari_compilazioni')
          .select('id, user_id, inviato_at')
          .eq('questionario_id', questionarioId)
          .order('inviato_at'),
    );
    final ids = compilazioni.map((riga) => riga['id'].toString()).toList();
    final risposte = ids.isEmpty
        ? <Map<String, dynamic>>[]
        : mappeDa(
            await client
                .from('questionari_risposte')
                .select('compilazione_id, domanda_id, valore')
                .inFilter('compilazione_id', ids),
          );

    return <String, dynamic>{
      'questionario': Map<String, dynamic>.from(questionario),
      'numero_compilazioni': compilazioni.length,
      'domande': domande,
      'compilazioni': compilazioni,
      'risposte': risposte,
    };
  }

  Future<Map<String, dynamic>?> caricaQuestionarioPubblico(String token) async {
    final raw = await client.rpc(
      'questionario_pubblico_carica',
      params: <String, dynamic>{'p_token': token},
    );
    return raw == null ? null : Map<String, dynamic>.from(raw as Map);
  }

  Future<void> inviaQuestionarioPubblico(
    String token,
    Map<String, dynamic> risposte,
  ) => client.rpc(
    'questionario_pubblico_invia',
    params: <String, dynamic>{'p_token': token, 'p_risposte': risposte},
  );
}

// ============================================================================
// SESSIONE / AUTENTICAZIONE
// ============================================================================

/// Accesso Supabase dedicato alla sessione applicativa.
///
/// Mantiene anche autenticazione e lettura del ruolo nello stesso file dati,
/// lasciando il controller di sessione responsabile esclusivamente dello stato UI.
class SessioneRepository {
  SessioneRepository({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  Stream<AuthState> get cambiAutenticazione => _client.auth.onAuthStateChange;
  User? get utenteCorrente => _client.auth.currentUser;

  Future<AuthResponse> accedi({
    required String email,
    required String password,
  }) => _client.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );

  Future<void> esci() => _client.auth.signOut();

  Future<Map<String, dynamic>?> ruoloUtente(String userId) =>
      RepositoryComune(client: _client).singolo(
        tabella: 'user_roles',
        colonne: 'role',
        filtri: <FiltroDb>[FiltroDb('user_id', userId)],
      );

  Future<SchemaDatabase> schemaDatabase() =>
      RepositoryComune(client: _client).schemaDatabase();
}
